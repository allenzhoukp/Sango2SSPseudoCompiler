void function Sol13LongSpcSmokeFade(smoke) {
    PlaySound(smoke, "S013SND01", 255);
    Delay(80);

    SetObjectFlags(smoke, 262144); //OF_MIXER
    SetObjectBrightness(smoke, 16);
    var brightness = 16;
    while(brightness > 0) {
        Delay(3);
        SetObjectBrightness(smoke, brightness);
        __asm {
            DECN brightness
        }
    }

    FreeObjectByHandle(smoke);
}

void function Sol13LongSpcAttack () callsign 29013 {
  var soldier = GetScriptLinkedObject();
  var soldierDir = GetObjectDir(soldier);
  if(soldierDir == 0)
    soldierDir = 1;
  else
    soldierDir = -1;

  var soldierScreenX = GetObjectScreenX(soldier);
  var soldierScreenY = GetObjectScreenY(soldier);

  var i = 1;
  while(i <= 5) {
    var target = GetSoldierHandle(ScreenXToBattleX(soldierScreenX) + soldierDir * i, ScreenYToBattleY(soldierScreenY));
    if(target == 0) {
        i += 1;
        continue;
    }

    var targetScreenX = GetObjectScreenX(target);
    var targetScreenY = GetObjectScreenY(target);
    var smoke = CreateObjectRaw(targetScreenX, targetScreenY, 0, 0, 504);
    asynccall Sol13LongSpcSmokeFade(smoke);

    if(IsSolAtkToSolValid_ByHandle(target, soldier))
      break;
    else
      return;
  }
  var targetDir = GetObjectDir(target);
  KillSoldier(target);
  var soldierSide = GetSoldierSide(soldier);
  if (!(GetSoldierCount(soldierSide) == 200 && (GetData(GetData(GetObjectByHandle(target)+0x84)+0x2C) & 4) == 0)) {
    var pSelfGeneral = GetData(GetData(GetData(GetObjectByHandle(soldier)+0x84)+0x40)+0x48);
    var pEnemyGeneral = GetData(GetData(GetData(GetObjectByHandle(target)+0x84)+0x40)+0x48);
    var selfSoldierType = GetData(pSelfGeneral + 0x8B);
    var enemySoldierType = GetData(pEnemyGeneral + 0x8B);

    SetINV(GetObjectSequence(target), 20);
    SetINV(1, 19);
    SetData(pSelfGeneral + 0x8B, enemySoldierType);

    var newSoldier = CreateSoldier(ScreenXToBattleX(targetScreenX), ScreenYToBattleY(targetScreenY));
    SetObjectCoordinate(newSoldier, targetScreenX, targetScreenY);
    SetObjectDir(newSoldier, targetDir);

    SetData(pSelfGeneral + 0x8B, selfSoldierType);
    SetINV(0, 20);
    SetINV(0, 19);

    FreeObjectByHandle(target);
  }
}
