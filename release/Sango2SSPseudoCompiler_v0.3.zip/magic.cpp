void function DelayAmbientSound (arg_0, arg_1, arg_2) {
__asm{
LOC_40:
	PUSH 1
	SETARG 1
	PUSHARG -4
	PUSHARG -3
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	DELAY
	PUSH 0
	SETARG 1
	RETN 3

}}

void function GetSoldierMaxX2 (arg_0) {
__asm{
LOC_90:
	STACK 5
	PUSHARG -2
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_234
	PUSHARG 1
	PUSH 2
	DIV
	PUSH 1
	ADD
	POPN 2
	PUSHARG -2
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 4
	PUSHARG 4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
LOC_148:
	PUSHARG -2
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 4
	PUSHARG 4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_1DC
	PUSHARG 3
	PUSHARG 5
	CMPG
	JZ LOC_1D4
	PUSHARG 5
	POPN 3
LOC_1D4:
	JMP LOC_208
LOC_1DC:
	PUSHARG 3
	PUSHARG 5
	CMPL
	JZ LOC_208
	PUSHARG 5
	POPN 3
LOC_208:
	DECN 2
	PUSHARG 2
	PUSH 0
	CMPG
	JNZ LOC_148
	JMP LOC_248
LOC_234:
	PUSH 1
	NEG
	INST_01 1
LOC_248:
	PUSHARG 3
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 3
	PUSHARG 3
	SYSCALL 0x103, (1 | (1 << 16)) ; BattleXToScreenX 
	POPN 3
	PUSHARG 3
	INST_01 1

}}

void function GetSoldierMaxX (arg_0) {
__asm{
LOC_290:
	STACK 5
	PUSHARG -2
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_434
	PUSHARG 1
	PUSH 2
	DIV
	PUSH 1
	ADD
	POPN 2
	PUSHARG -2
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 4
	PUSHARG 4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
LOC_348:
	PUSHARG -2
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 4
	PUSHARG 4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_3DC
	PUSHARG 3
	PUSHARG 5
	CMPG
	JZ LOC_3D4
	PUSHARG 5
	POPN 3
LOC_3D4:
	JMP LOC_408
LOC_3DC:
	PUSHARG 3
	PUSHARG 5
	CMPL
	JZ LOC_408
	PUSHARG 5
	POPN 3
LOC_408:
	DECN 2
	PUSHARG 2
	PUSH 0
	CMPG
	JNZ LOC_348
	JMP LOC_4C8
LOC_434:
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_490
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHARG 5
	PUSH 320
	SUB
	POPN 3
	JMP LOC_4C8
LOC_490:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHARG 5
	PUSH 320
	ADD
	POPN 3
LOC_4C8:
	PUSHARG 3
	INST_01 1

}}

void function HoldAllDelay (arg_0) {
__asm{
	SYSCALL 0x122, (0 | (0 << 16)) ; SetAttackCounterTo9999 or DisableAttack 
	PUSHARG -2
	DELAY
	SYSCALL 0x123, (0 | (0 << 16)) ; RestoreAttackCounter 
	RETN 1

}}

void function ProduceShadowTime (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -2
	POPN 1
LOC_51C:
	PUSHARG -3
	PUSH 12
	PUSH 1
	SYSCALL 0x23, (3 | (1 << 16)) ; CreateObject_Shadow 
	POP
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	ZERO
	JZ LOC_56C
	JMP LOC_59C
LOC_56C:
	PUSH 1
	DELAY
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_51C
LOC_59C:
	RETN 2

}}

void function MovingShadow (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSHARG -6
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSHARG -2
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSH 1
	POPN 1
LOC_628:
	PUSHARG 2
	PUSH 4
	PUSH 1
	PUSH 8192
	SYSCALL 0x24, (4 | (1 << 16)) ; CreateObject_Shadow1 
	POP
	PUSHARG 2
	PUSHARG -6
	PUSHARG -3
	PUSHARG 1
	PUSH 16
	MUL
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	INCN 1
	PUSHARG 1
	PUSHARG -5
	CMPLE
	JNZ LOC_628
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 5

}}

void function LockByCenter (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6) {
__asm{
LOC_6F4:
	STACK 2
	PUSHARG -8
	PUSHARG -7
	PUSHARG -6
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG -8
	PUSHARG -6
	PUSHARG -5
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 2
	PUSHARG -3
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSHARG -2
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG -4
	DELAY
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 7

}}

void function LockTargetXY (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7, arg_8) {
__asm{
	STACK 1
	PUSHARG -4
	PUSHARG -3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG -8
	PUSHARG -7
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -10
	PUSHARG -9
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSHARG -5
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG -6
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 9

}}

void function LockTargetTime2 (arg_0, arg_1, arg_2) {
__asm{
	STACK 4
	PUSHARG -4
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	PUSHARG -4
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	ORZ
	JZ LOC_95C
	PUSHARG -4
	SYSCALL 0x115, (1 | (1 << 16)) ; GetSoldierSide 
	SYSCALL 0x117, (1 | (1 << 16)) ; GetMajorHP 
	PUSH 0
	CMPZ
	JZ LOC_944
	PUSH 40
	POPN 4
	JMP LOC_954
LOC_944:
	PUSH 0
	POPN 4
LOC_954:
	JMP LOC_96C
LOC_95C:
	PUSH 0
	POPN 4
LOC_96C:
	PUSHARG -4
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 3
	PUSHARG -4
	PUSHARG -3
	PUSHARG 3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG -2
	POPN 1
LOC_9CC:
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	ZERO
	JZ LOC_9F4
	JMP LOC_A58
LOC_9F4:
	PUSHARG 2
	PUSHARG -4
	PUSH 0
	PUSH 0
	PUSHARG 4
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_9CC
LOC_A58:
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function Hurt (arg_0, arg_1, arg_2) {
__asm{
LOC_A84:
	PUSHARG -3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	PUSHARG -3
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	ORZ
	JZ LOC_B30
	PUSHARG -4
	PUSH 67108864
	PUSH 16777216
	ADD
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG -2
	PUSH 0
	CMPLE
	JZ LOC_B04
	RETN 3
LOC_B04:
	PUSHARG -3
	PUSH 0
	PUSHARG -2
	SYSCALL 0x125, (3 | (0 << 16)) ; 0x0125 
	JMP LOC_B54
LOC_B30:
	PUSHARG -3
	PUSHSTR "Hit01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
LOC_B54:
	RETN 3

}}

void function MoveCamera (arg_0, arg_1, arg_2) {
__asm{
LOC_B5C:
	STACK 5
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	PUSH 1000
	MUL
	POPN 2
	SYSCALL 0x112, (0 | (1 << 16)) ; 0x0112 
	PUSH 1000
	MUL
	POPN 3
	PUSHARG -4
	PUSH 1000
	MUL
	POPN -4
	PUSHARG -3
	PUSH 1000
	MUL
	POPN -3
	PUSHARG -4
	PUSHARG 2
	SUB
	POPN 4
	PUSHARG 4
	PUSHARG -2
	DIV
	POPN 4
	PUSHARG -3
	PUSHARG 3
	SUB
	POPN 5
	PUSHARG 5
	PUSHARG -2
	DIV
	POPN 5
	PUSHARG -2
	POPN 1
LOC_C5C:
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_D74
	PUSHARG 2
	PUSHARG 4
	ADD
	POPN 2
	PUSHARG 3
	PUSHARG 5
	ADD
	POPN 3
	PUSHARG 2
	PUSH 1000
	DIV
	PUSHARG 3
	PUSH 1000
	DIV
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 2
	PUSH 100
	DIV
	PUSHARG -4
	PUSH 100
	DIV
	CMP
	PUSHARG 3
	PUSH 100
	DIV
	PUSHARG -3
	PUSH 100
	DIV
	CMP
	ORNZ
	JZ LOC_D58
	PUSH 1
	POPN 1
LOC_D58:
	DECN 1
	PUSH 1
	DELAY
	JMP LOC_C5C
LOC_D74:
	RETN 3

}}

void function LockCameraSimple (arg_0, arg_1) {
__asm{
	STACK 2
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 2
LOC_D98:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_E78
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 1
	PUSHARG 2
	SUB
	PUSH 40
	CMPG
	PUSHARG 1
	PUSHARG 2
	SUB
	PUSH 40
	CMPL
	ORZ
	JZ LOC_E50
	PUSHARG 1
	PUSHARG -3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSHARG -2
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
LOC_E50:
	PUSH 1
	DELAY
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 2
	JMP LOC_D98
LOC_E78:
	RETN 2

}}

void function LockCameraSimple2 (arg_0, arg_1) {
__asm{
LOC_E80:
	STACK 2
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 2
LOC_E9C:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_F7C
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 1
	PUSHARG 2
	SUB
	PUSH 10
	CMPG
	PUSHARG 1
	PUSHARG 2
	SUB
	PUSH 10
	CMPL
	ORZ
	JZ LOC_F54
	PUSHARG 1
	PUSHARG -3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSHARG -2
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
LOC_F54:
	PUSH 1
	DELAY
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 2
	JMP LOC_E9C
LOC_F7C:
	RETN 2

}}

void function LockCameraLine (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 5
	PUSH 0
	POPN 5
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 2
	SYSCALL 0x112, (0 | (1 << 16)) ; 0x0112 
	POPN 3
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_FF8
	PUSH 100
	POPN 4
	JMP LOC_100C
LOC_FF8:
	PUSH 100
	NEG
	POPN 4
LOC_100C:
	PUSHARG -5
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
LOC_1028:
	PUSH 1
	JZ LOC_11C0
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_10AC
	PUSHARG 1
	PUSH 8
	ADD
	POPN 1
	PUSHARG 1
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	PUSH 270
	SUB
	CMPG
	JZ LOC_10A4
	JMP LOC_11C0
LOC_10A4:
	JMP LOC_10EC
LOC_10AC:
	PUSHARG 1
	PUSH 8
	SUB
	POPN 1
	PUSHARG 1
	PUSH 270
	CMPL
	JZ LOC_10EC
	JMP LOC_11C0
LOC_10EC:
	PUSHARG 1
	PUSHARG 2
	SUB
	PUSH 40
	CMPG
	PUSHARG 1
	PUSHARG 2
	SUB
	PUSH 40
	CMPL
	ORZ
	JZ LOC_116C
	PUSHARG 1
	PUSHARG 4
	ADD
	PUSHARG 3
	PUSHARG -4
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
LOC_116C:
	PUSH 1
	DELAY
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 2
	INCN 5
	PUSHARG 5
	PUSHARG -2
	CMPG
	JZ LOC_11B8
	JMP LOC_11C0
LOC_11B8:
	JMP LOC_1028
LOC_11C0:
	RETN 4

}}

void function LockCameraLineDelay (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 4
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 2
	SYSCALL 0x112, (0 | (1 << 16)) ; 0x0112 
	POPN 3
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_122C
	PUSH 100
	POPN 4
	JMP LOC_1240
LOC_122C:
	PUSH 100
	NEG
	POPN 4
LOC_1240:
	PUSHARG -5
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_13D0
	PUSHARG -5
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_12CC
	PUSHARG 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	CMPG
	JZ LOC_12C4
	JMP LOC_13D0
LOC_12C4:
	JMP LOC_12FC
LOC_12CC:
	PUSHARG 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	CMPL
	JZ LOC_12FC
	JMP LOC_13D0
LOC_12FC:
	PUSHARG 1
	PUSHARG 2
	SUB
	PUSH 40
	CMPG
	PUSHARG 1
	PUSHARG 2
	SUB
	PUSH 40
	CMPL
	ORZ
	JZ LOC_137C
	PUSHARG 1
	PUSHARG 4
	ADD
	PUSHARG 3
	PUSHARG -4
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
LOC_137C:
	PUSH 1
	DELAY
	DECN -2
	PUSHARG -2
	PUSH 0
	CMPLE
	JZ LOC_13B4
	JMP LOC_13D0
LOC_13B4:
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 2
	JMP LOC_1240
LOC_13D0:
	RETN 4

}}

void function LockCamera (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 6
	PUSH 0
	POPN 6
	PUSHARG -5
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSH 0
	POPN 1
	PUSHARG -5
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	POPN 3
LOC_1438:
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_16D0
	PUSHARG -5
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 4
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_1520
	PUSHARG 4
	PUSHARG 2
	SUB
	PUSHARG -4
	CMPGE
	JZ LOC_1508
	PUSHARG 2
	PUSHARG -4
	ADD
	POPN 5
	PUSHARG 6
	PUSH 1
	SUB
	POPN 6
	JMP LOC_1518
LOC_1508:
	PUSHARG 4
	POPN 5
LOC_1518:
	JMP LOC_1598
LOC_1520:
	PUSHARG 2
	PUSHARG 4
	SUB
	PUSHARG -4
	CMPGE
	JZ LOC_1588
	PUSHARG 2
	PUSHARG -4
	SUB
	POPN 5
	PUSHARG 6
	PUSH 1
	ADD
	POPN 6
	JMP LOC_1598
LOC_1588:
	PUSHARG 4
	POPN 5
LOC_1598:
	PUSHARG 5
	PUSHARG 6
	ADD
	PUSHARG -5
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSHARG -3
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSH 1
	DELAY
	PUSHARG -5
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	POPN 3
	PUSHARG 1
	PUSH 1
	CMP
	JZ LOC_1634
	PUSH 0
	POPN 3
	JMP LOC_16C8
LOC_1634:
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_1690
	PUSHARG 4
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	CMPLE
	JZ LOC_1688
	PUSH 0
	POPN 3
LOC_1688:
	JMP LOC_16C8
LOC_1690:
	PUSHARG 4
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	CMPGE
	JZ LOC_16C8
	PUSH 0
	POPN 3
LOC_16C8:
	JMP LOC_1438
LOC_16D0:
	PUSHARG 1
	PUSH 0
	CMP
	JZ LOC_1780
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_1720
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN -5
	JMP LOC_1730
LOC_1720:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN -5
LOC_1730:
	PUSHSTR "MoveCamera"
	PUSHARG -5
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSHARG -5
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSH 120
	SUB
	PUSH 30
	PUSH 0
	CALLBS
LOC_1780:
	RETN 4

}}

void function LockCamera2 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 8
	PUSH 0
	POPN 6
	PUSHARG -6
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSH 0
	POPN 1
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	POPN 3
LOC_17E8:
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_1A80
	PUSHARG -6
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 4
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_18D0
	PUSHARG 4
	PUSHARG 2
	SUB
	PUSHARG -5
	CMPGE
	JZ LOC_18B8
	PUSHARG 2
	PUSHARG -5
	ADD
	POPN 5
	PUSHARG 6
	PUSH 1
	SUB
	POPN 6
	JMP LOC_18C8
LOC_18B8:
	PUSHARG 4
	POPN 5
LOC_18C8:
	JMP LOC_1948
LOC_18D0:
	PUSHARG 2
	PUSHARG 4
	SUB
	PUSHARG -5
	CMPGE
	JZ LOC_1938
	PUSHARG 2
	PUSHARG -5
	SUB
	POPN 5
	PUSHARG 6
	PUSH 1
	ADD
	POPN 6
	JMP LOC_1948
LOC_1938:
	PUSHARG 4
	POPN 5
LOC_1948:
	PUSHARG 5
	PUSHARG 6
	ADD
	PUSHARG -6
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSHARG -4
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSH 1
	DELAY
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	POPN 3
	PUSHARG 1
	PUSH 1
	CMP
	JZ LOC_19E4
	PUSH 0
	POPN 3
	JMP LOC_1A78
LOC_19E4:
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_1A40
	PUSHARG 4
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	CMPLE
	JZ LOC_1A38
	PUSH 0
	POPN 3
LOC_1A38:
	JMP LOC_1A78
LOC_1A40:
	PUSHARG 4
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	CMPGE
	JZ LOC_1A78
	PUSH 0
	POPN 3
LOC_1A78:
	JMP LOC_17E8
LOC_1A80:
	SYSCALL 0x111, (0 | (1 << 16)) ; 0x0111 
	POPN 7
	SYSCALL 0x112, (0 | (1 << 16)) ; 0x0112 
	POPN 8
LOC_1AA8:
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1B78
	PUSHARG -2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_1B34
	PUSHARG 2
	PUSHARG 7
	PUSH 40
	SUB
	CMPGE
	JZ LOC_1B2C
	JMP LOC_1B78
LOC_1B2C:
	JMP LOC_1B64
LOC_1B34:
	PUSHARG 2
	PUSHARG 7
	PUSH 40
	ADD
	CMPLE
	JZ LOC_1B64
	JMP LOC_1B78
LOC_1B64:
	PUSH 2
	DELAY
	JMP LOC_1AA8
LOC_1B78:
	PUSHARG 8
	PUSHARG -2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	SUB
	POPN 8
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1BD4
	PUSHARG -2
	PUSHARG 8
	CALL LockCameraSimple2
LOC_1BD4:
	RETN 5

}}

void function FireMan (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSHARG -4
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 2
	PUSHARG -4
	PUSHARG -3
	PUSHARG 2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSH 0
	POPN 1
LOC_1C44:
	PUSHARG 1
	PUSHARG -2
	CMPL
	JZ LOC_1CE0
	PUSHARG 3
	PUSHARG -4
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_1CD0
	JMP LOC_1CE0
LOC_1CD0:
	INCN 1
	JMP LOC_1C44
LOC_1CE0:
	PUSHARG 3
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function CreateBlood (arg_0, arg_1, arg_2) {
__asm{
	STACK 1
	PUSHARG -4
	PUSH 10012
	PUSH 0
	PUSHARG -3
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -2
	PUSH 24
	PUSH 40
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 7
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 2
	DELAY
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function Blood (arg_0, arg_1) {
__asm{
	STACK 2
	PUSH 128
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	POPN 2
	PUSH 0
	POPN 1
LOC_1E2C:
	PUSHARG 1
	PUSH 32
	CMPL
	JZ LOC_1EA4
	PUSHSTR "CreateBlood"
	PUSHARG -3
	PUSHARG -2
	PUSHARG 2
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 1
	JMP LOC_1E2C
LOC_1EA4:
	RETN 2

}}

void function SmallFireBall (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 2
	PUSHARG -4
	PUSHSTR "hit01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSH 0
	POPN 2
LOC_1EE8:
	PUSHARG 2
	PUSHARG -3
	CMPL
	JZ LOC_202C
	PUSHARG -4
	PUSH 10003
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -2
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 12288
	PUSH 12288
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 1
	PUSH 8192
	SYSCALL 0x21, (2 | (0 << 16)) ; 0x0021 
	PUSHARG 1
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 256
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	INCN 2
	JMP LOC_1EE8
LOC_202C:
	RETN 4

}}

void function SmallFireBall2 (arg_0, arg_1, arg_2, arg_3) {
__asm{
LOC_2034:
	STACK 3
	PUSHARG -4
	PUSHSTR "hit01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSH 0
	POPN 2
LOC_2070:
	PUSHARG 2
	PUSHARG -3
	CMPL
	JZ LOC_21D8
	PUSHARG -4
	PUSH 10003
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -2
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSH 8192
	PUSH 12288
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
	PUSHARG 1
	PUSHARG 3
	PUSHARG 3
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 3
	PUSH 7
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	NEG
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 1
	PUSH 8192
	SYSCALL 0x21, (2 | (0 << 16)) ; 0x0021 
	PUSHARG 1
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 256
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	INCN 2
	JMP LOC_2070
LOC_21D8:
	RETN 4

}}

void function SmallFireBall3 (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 2
	PUSHARG -4
	PUSHSTR "hit01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSH 0
	POPN 2
LOC_221C:
	PUSHARG 2
	PUSHARG -3
	CMPL
	JZ LOC_2360
	PUSHARG -4
	PUSH 10013
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -2
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 12288
	PUSH 12288
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 1
	PUSH 8192
	SYSCALL 0x21, (2 | (0 << 16)) ; 0x0021 
	PUSHARG 1
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 256
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	INCN 2
	JMP LOC_221C
LOC_2360:
	RETN 4

}}

void function SmallFireBall4 (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 2
	PUSHARG -4
	PUSHSTR "hit01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSH 0
	POPN 2
LOC_23A4:
	PUSHARG 2
	PUSHARG -3
	CMPL
	JZ LOC_24E8
	PUSHARG -4
	PUSH 10014
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -2
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 12288
	PUSH 12288
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 1
	PUSH 8192
	SYSCALL 0x21, (2 | (0 << 16)) ; 0x0021 
	PUSHARG 1
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 256
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	INCN 2
	JMP LOC_23A4
LOC_24E8:
	RETN 4

}}

void function DownBrightness (arg_0, arg_1) {
__asm{
LOC_24F0:
	STACK 1
	SYSCALL 0x130, (0 | (1 << 16)) ; GetBackgroundBrightness 
	POPN 1
LOC_250C:
	PUSHARG 1
	PUSHARG -3
	CMPG
	JZ LOC_2558
	PUSHARG -2
	DELAY
	DECN 1
	PUSHARG 1
	SYSCALL 0x12F, (1 | (0 << 16)) ; SetBackgroundBrightness 
	JMP LOC_250C
LOC_2558:
	PUSH 16
	SYSCALL 0x12F, (1 | (0 << 16)) ; SetBackgroundBrightness 
	PUSHARG -3
	SYSCALL 0x135, (1 | (0 << 16)) ; 0x0135 
	PUSHARG -3
	SETARG 2
	RETN 2

}}

void function RaiseBrightness (arg_0, arg_1) {
__asm{
LOC_2598:
	STACK 1
	SYSCALL 0x136, (0 | (0 << 16)) ; 0x0136 
	INST_09 2
	POPN 1
	PUSHARG 1
	SYSCALL 0x12F, (1 | (0 << 16)) ; SetBackgroundBrightness 
LOC_25D0:
	PUSHARG 1
	PUSHARG -3
	CMPL
	JZ LOC_261C
	PUSHARG -2
	DELAY
	INCN 1
	PUSHARG 1
	SYSCALL 0x12F, (1 | (0 << 16)) ; SetBackgroundBrightness 
	JMP LOC_25D0
LOC_261C:
	PUSHARG -3
	SYSCALL 0x12F, (1 | (0 << 16)) ; SetBackgroundBrightness 
	RETN 2

}}

void function CreateDot (arg_0) {
__asm{
	STACK 4
	PUSHARG -2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 3
	PUSHARG -2
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 4
	PUSH 2
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -2
	PUSH 10004
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG 2
	PUSH 60
	NEG
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 3
	PUSH 60
	NEG
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 4
	PUSH 60
	NEG
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSHARG -2
	PUSH 3
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 1

}}

void function CreateDots (arg_0) {
__asm{
	STACK 2
	PUSH 0
	POPN 2
LOC_27FC:
	PUSHARG 2
	PUSH 10
	CMPL
	JZ LOC_28B0
	PUSH 0
	POPN 1
LOC_2828:
	PUSHARG 1
	PUSH 4
	CMPL
	JZ LOC_28A0
	PUSHSTR "CreateDot"
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 1
	JMP LOC_2828
LOC_28A0:
	INCN 2
	JMP LOC_27FC
LOC_28B0:
	RETN 1

}}

void function CreateLines (arg_0) {
__asm{
	STACK 21
	PUSH 0
	POPN 1
LOC_28D0:
	PUSHARG 1
	PUSH 20
	CMPL
	JZ LOC_2990
	PUSH 0
	PUSH 1023
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 7
	AND
	PUSHARG 1
	SETNR 2
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_2980
	PUSHARG 1
	PUSHNR 2
	PUSHARG 1
	PUSH 1
	SUB
	PUSHNR 2
	CMP
	JZ LOC_2980
	DECN 1
LOC_2980:
	INCN 1
	JMP LOC_28D0
LOC_2990:
	PUSH 0
	POPN 1
LOC_29A0:
	PUSHARG 1
	PUSH 20
	CMPL
	JZ LOC_2A20
	PUSHSTR "CreateLine"
	PUSHARG -2
	PUSHARG 1
	PUSHNR 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 6
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 1
	JMP LOC_29A0
LOC_2A20:
	RETN 1

}}

void function CreateLine (arg_0, arg_1) {
__asm{
	STACK 6
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 3
	PUSHARG -3
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 4
	PUSH 2
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -2
	JCOND 0, LOC_2B18
	JCOND 1, LOC_2B80
	JCOND 2, LOC_2C04
	JCOND 3, LOC_2C6C
	JCOND 4, LOC_2CF0
	JCOND 5, LOC_2D58
	JCOND 6, LOC_2DDC
	JCOND 7, LOC_2E44
	POP
	JMP LOC_2EC8
LOC_2B18:
	PUSH 10005
	POPN 6
	PUSH 128
	POPN -2
	PUSH 51
	PUSH 72
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHARG 2
	PUSHARG 5
	ADD
	POPN 2
	JMP LOC_2EC8
LOC_2B80:
	PUSH 10006
	POPN 6
	PUSH 128
	POPN -2
	PUSH 52
	PUSH 77
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHARG 2
	PUSHARG 5
	ADD
	POPN 2
	PUSHARG 4
	PUSHARG 5
	ADD
	POPN 4
	JMP LOC_2EC8
LOC_2C04:
	PUSH 10007
	POPN 6
	PUSH 0
	POPN -2
	PUSH 50
	PUSH 71
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	ADD
	POPN 4
	JMP LOC_2EC8
LOC_2C6C:
	PUSH 10006
	POPN 6
	PUSH 0
	POPN -2
	PUSH 50
	PUSH 70
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHARG 2
	PUSHARG 5
	SUB
	POPN 2
	PUSHARG 4
	PUSHARG 5
	ADD
	POPN 4
	JMP LOC_2EC8
LOC_2CF0:
	PUSH 10005
	POPN 6
	PUSH 0
	POPN -2
	PUSH 52
	PUSH 70
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHARG 2
	PUSHARG 5
	SUB
	POPN 2
	JMP LOC_2EC8
LOC_2D58:
	PUSH 10009
	POPN 6
	PUSH 0
	POPN -2
	PUSH 52
	PUSH 73
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHARG 2
	PUSHARG 5
	SUB
	POPN 2
	PUSHARG 4
	PUSHARG 5
	SUB
	POPN 4
	JMP LOC_2EC8
LOC_2DDC:
	PUSH 10008
	POPN 6
	PUSH 0
	POPN -2
	PUSH 51
	PUSH 77
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	SUB
	POPN 4
	JMP LOC_2EC8
LOC_2E44:
	PUSH 10009
	POPN 6
	PUSH 128
	POPN -2
	PUSH 50
	PUSH 70
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHARG 2
	PUSHARG 5
	ADD
	POPN 2
	PUSHARG 4
	PUSHARG 5
	SUB
	POPN 4
	JMP LOC_2EC8
LOC_2EC8:
	PUSHARG -3
	PUSHARG 6
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG 2
	PUSHARG 3
	PUSHARG 4
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSHARG -3
	PUSH 3
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function PowerExplode (arg_0, arg_1) {
__asm{
	STACK 3
	PUSHARG -3
	PUSH 10011
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 0
	PUSHARG -2
	PUSH 32
	MUL
	PUSH 2
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 4
	PUSH 2
	SYSCALL 0x23, (3 | (1 << 16)) ; CreateObject_Shadow 
	POP
	PUSH 5
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function KeepPower (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_309C
	PUSH 1
	POPN -2
	JMP LOC_30B0
LOC_309C:
	PUSH 1
	NEG
	POPN -2
LOC_30B0:
	PUSHARG -3
	PUSH 10010
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -2
	PUSH 47
	MUL
	POPN -2
	PUSHARG 1
	PUSHARG -3
	PUSH 0
	PUSHARG -2
	PUSH 110
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 12
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHSTR "CreateDots"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 10
	DELAY
	PUSHSTR "CreateLines"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 160
	DELAY
	PUSH 11
	POPN 2
LOC_31D0:
	PUSHARG 2
	PUSH 0
	CMPGE
	JZ LOC_3224
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	DECN 2
	JMP LOC_31D0
LOC_3224:
	RETN 2

}}

void function StepShow (arg_0, arg_1) {
__asm{
	STACK 1
	PUSHARG -3
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -3
	PUSH 0
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 20
	DELAY
	PUSH 1
	POPN 1
LOC_3288:
	PUSHARG 1
	PUSH 16
	CMPLE
	JZ LOC_32DC
	PUSHARG -2
	DELAY
	PUSHARG -3
	PUSHARG 1
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	INCN 1
	JMP LOC_3288
LOC_32DC:
	PUSHARG -3
	PUSH 262144
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	RETN 2

}}

void function HitGeneral (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5) {
__asm{
LOC_3300:
	STACK 5
	INST_09 3
	JZ LOC_3320
	RETN 6
LOC_3320:
	PUSH 1
	SETARG 3
	PUSHARG -6
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG -6
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG -6
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 2
	PUSHARG 3
	PUSHARG 4
	PUSHARG -3
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSH 0
	POPN 1
LOC_33D8:
	PUSHARG 1
	PUSH 7
	CMPL
	JZ LOC_35AC
	PUSHARG 2
	PUSHARG -5
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 5
	PUSHARG 5
	PUSH 49152
	PUSH 49152
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 5
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG -4
	JCOND 1, LOC_34E0
	JCOND 2, LOC_3514
	JCOND 3, LOC_3548
	POP
	JMP LOC_357C
LOC_34E0:
	PUSHSTR "SmallFireBall"
	PUSHARG -7
	PUSHARG -6
	PUSH 8
	PUSHARG -3
	CALLBS
	JMP LOC_357C
LOC_3514:
	PUSHSTR "SmallFireBall3"
	PUSHARG -7
	PUSHARG -6
	PUSH 8
	PUSHARG -3
	CALLBS
	JMP LOC_357C
LOC_3548:
	PUSHSTR "SmallFireBall4"
	PUSHARG -7
	PUSHARG -6
	PUSH 8
	PUSHARG -3
	CALLBS
	JMP LOC_357C
LOC_357C:
	PUSH 3
	PUSH 7
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 1
	JMP LOC_33D8
LOC_35AC:
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG -2
	DELAY
	PUSH 0
	SETARG 3
	RETN 6

}}

void function DisableAttack (arg_0, arg_1, arg_2) {
__asm{
	PUSHARG -4
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG -2
	DELAY
	PUSHARG -4
	PUSHARG -3
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	RETN 3

}}

void function NoMoreSoldierCallback (arg_0, arg_1) callsign 1000 {
__asm{
	STACK 2
	PUSHSTR "m000snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -3
	PUSH 67108864
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG -2
	PUSH 16
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG -3
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 2
	PUSHARG -3
	PUSH 10018
	PUSHARG 2
	PUSH 16
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 10752
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_372C
	PUSH 45
	POPN 2
	JMP LOC_373C
LOC_372C:
	PUSH 83
	POPN 2
LOC_373C:
	PUSHARG 1
	PUSH 0
	PUSHARG 2
	PUSH 5
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 16
	PUSH 3
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function CastFail (arg_0, arg_1) {
__asm{
LOC_37A8:
	STACK 1
	PUSHARG -3
	PUSH 10017
	PUSHARG -2
	PUSH 256
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 67108864
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 1000
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG -3
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG -3
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 60
	DELAY
	RETN 2

}}

void function HalfMoonAll (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSHARG -6
	PUSH 11001
	PUSHARG -5
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSHARG -3
	PUSHARG -2
	PUSH 1
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSHARG -5
	PUSH 0
	PUSHARG -4
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 1001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHSTR "ShowHalfMoonSmoke"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 600
	POPN 2
LOC_3978:
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	ZERO
	JZ LOC_39A8
	PUSH 0
	POPN 2
LOC_39A8:
	PUSH 1
	DELAY
	DECN 2
	PUSHARG 2
	PUSH 0
	CMPGE
	JNZ LOC_3978
	PUSH 120
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 5

}}

void function HalfMoonCallback (arg_0, arg_1) callsign 1001 {
__asm{
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CALL Hurt
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_3AB0
	PUSHARG -3
	PUSH 2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -3
	PUSHARG -2
	PUSH 11002
	PUSH 1
	PUSH 48
	PUSH 0
	CALL HitGeneral
	JMP LOC_3B08
LOC_3AB0:
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 8
	PUSH 0
	CALLBS
LOC_3B08:
	RETN 2

}}

void function ShowHalfMoonSmoke (arg_0) {
__asm{
	STACK 1
	PUSH 0
	POPN 1
LOC_3B28:
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_3D08
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_3C14
	PUSHSTR "CreateHalfMoonSmoke"
	PUSHARG -2
	PUSH 7
	PUSH 8
	NEG
	PUSH 6
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSHARG 1
	PUSH 2
	MUL
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	SUB
	PUSH 0
	PUSH 2
	NEG
	PUSH 256
	PUSHARG 1
	MUL
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_3CB8
LOC_3C14:
	PUSHSTR "CreateHalfMoonSmoke"
	PUSHARG -2
	PUSH 7
	PUSH 8
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSHARG 1
	PUSH 2
	MUL
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	ADD
	PUSH 0
	PUSH 2
	NEG
	PUSH 256
	PUSHARG 1
	MUL
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_3CB8:
	PUSH 1
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 1
	PUSH 1
	ADD
	PUSH 12
	MOD
	POPN 1
	JMP LOC_3B28
LOC_3D08:
	RETN 1

}}

void function CreateHalfMoonSmoke (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_3D70
	PUSHARG -6
	PUSH 11003
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	JMP LOC_3DA4
LOC_3D70:
	PUSHARG -6
	PUSH 11003
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
LOC_3DA4:
	PUSHARG 1
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 32768
	PUSH 20480
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 14
	PUSH 1
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSH 1
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 2048
	NEG
	PUSHARG -2
	SUB
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
LOC_3E88:
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_3EFC
	PUSH 1
	DELAY
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_3EF4
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	JMP LOC_3EFC
LOC_3EF4:
	JMP LOC_3E88
LOC_3EFC:
	RETN 5

}}

void function HalfMoon (arg_0) {
__asm{
LOC_3F04:
	STACK 12
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\001\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 3
	PUSH 0
	POPN 11
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	CMP
	JZ LOC_3FEC
	PUSH 0
	PUSH 90
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 11
LOC_3FEC:
	PUSH 18
	POPN 6
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_4044
	PUSH 0
	POPN 5
	PUSH 1
	NEG
	POPN 12
	JMP LOC_4064
LOC_4044:
	PUSH 128
	POPN 5
	PUSH 1
	POPN 12
LOC_4064:
	PUSHARG -2
	JCOND 0, LOC_409C
	JCOND 1, LOC_40C0
	JCOND 2, LOC_40E4
	POP
	JMP LOC_4108
LOC_409C:
	PUSH 120
	PUSHARG 11
	SUB
	POPN 9
	JMP LOC_4108
LOC_40C0:
	PUSH 210
	PUSHARG 11
	SUB
	POPN 9
	JMP LOC_4108
LOC_40E4:
	PUSH 330
	PUSHARG 11
	SUB
	POPN 9
	JMP LOC_4108
LOC_4108:
	PUSHARG 1
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 7
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 8
	PUSHARG 7
	PUSHARG 12
	PUSH 180
	MUL
	SUB
	PUSHARG 8
	PUSHARG 9
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 1
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHARG 1
	PUSH 4096
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	PUSHSTR "m001snd01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHARG 1
	PUSH 11001
	PUSHARG 5
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 4
	PUSHARG 4
	PUSHARG 1
	PUSHARG 5
	PUSH 64
	PUSH 1
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 4
	PUSHARG 5
	PUSH 0
	PUSHARG 6
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 4
	PUSH 16777216
	PUSH 33554432
	OR
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 4
	PUSH 1001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHSTR "ShowHalfMoonSmoke"
	PUSHARG 4
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG -2
	JCOND 0, LOC_4368
	JCOND 1, LOC_43A0
	JCOND 2, LOC_4468
	POP
	JMP LOC_45C0
LOC_4368:
	PUSHSTR "LockCamera"
	PUSHARG 4
	PUSH 180
	PUSHARG 9
	NEG
	PUSHARG 3
	CALLBS
	JMP LOC_45C0
LOC_43A0:
	PUSHSTR "HalfMoonAll"
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	PUSH 48
	PUSHARG 12
	PUSH 140
	MUL
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "HalfMoonAll"
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	PUSH 208
	PUSHARG 12
	PUSH 140
	MUL
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "LockCamera"
	PUSHARG 4
	PUSH 180
	PUSHARG 9
	NEG
	PUSHARG 3
	CALLBS
	JMP LOC_45C0
LOC_4468:
	PUSHSTR "HalfMoonAll"
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	PUSH 48
	PUSH 140
	PUSHARG 12
	MUL
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "HalfMoonAll"
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	PUSH 48
	PUSH 280
	PUSHARG 12
	MUL
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "HalfMoonAll"
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	PUSH 208
	PUSH 140
	PUSHARG 12
	MUL
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "HalfMoonAll"
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	PUSH 208
	PUSH 280
	PUSHARG 12
	MUL
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "LockCamera"
	PUSHARG 4
	PUSH 180
	PUSHARG 9
	NEG
	PUSHARG 3
	CALLBS
	JMP LOC_45C0
LOC_45C0:
	PUSHARG 4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	POPN 10
	PUSHARG 10
	PUSH 1
	CMP
	JZ LOC_4660
	PUSHARG 4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 7
	PUSHARG 7
	PUSH 0
	CMPLE
	PUSHARG 7
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	CMPGE
	ORZ
	JZ LOC_4660
	PUSHARG 4
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_4660:
	PUSH 1
	DELAY
	PUSHARG 10
	PUSH 0
	CMPZ
	JNZ LOC_45C0
	PUSH 70
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function ProduceSoldier (arg_0, arg_1) {
__asm{
	STACK 7
	PUSH 0
	POPN 4
	PUSH 0
	POPN 1
	SYSCALL 0x12D, (0 | (1 << 16)) ; GetBattleWidth 
	POPN 6
	SYSCALL 0x12E, (0 | (1 << 16)) ; GetBattleHeight 
	POPN 7
LOC_4710:
	PUSHARG 7
	PUSH 2
	DIV
	POPN 2
LOC_472C:
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_4774
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
	JMP LOC_47B0
LOC_4774:
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
LOC_47B0:
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_48E4
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_4848
	PUSHARG -3
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
	JMP LOC_48B8
LOC_4848:
	PUSHARG -3
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 2
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
LOC_48B8:
	INCN 4
	PUSHARG 4
	PUSHARG -2
	CMPGE
	JZ LOC_48E4
	RETN 2
LOC_48E4:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_4944
	PUSHARG 1
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
	JMP LOC_4998
LOC_4944:
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
LOC_4998:
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_4AFC
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_4A48
	PUSHARG -3
	PUSHARG 1
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
	JMP LOC_4AD0
LOC_4A48:
	PUSHARG -3
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
LOC_4AD0:
	INCN 4
	PUSHARG 4
	PUSHARG -2
	CMPGE
	JZ LOC_4AFC
	RETN 2
LOC_4AFC:
	DECN 2
	PUSHARG 2
	PUSH 0
	CMPG
	JNZ LOC_472C
	INCN 1
	PUSHARG 1
	PUSHARG 6
	CMPLE
	JNZ LOC_4710
	RETN 2

}}

void function MoreSoldier (arg_0, arg_1) {
__asm{
LOC_4B4C:
	STACK 8
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\002\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 1
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 1
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_4C98
	PUSH 0
	POPN 2
	JMP LOC_4CA8
LOC_4C98:
	PUSH 128
	POPN 2
LOC_4CA8:
	PUSHARG 3
	SYSCALL 0x116, (1 | (1 << 16)) ; GetMajorLevel 
	POPN 6
	PUSHARG 6
	PUSH 40
	CMPG
	JZ LOC_4CF0
	PUSH 40
	POPN 6
LOC_4CF0:
	PUSHARG 6
	PUSH 5
	MUL
	PUSHARG 3
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	SUB
	POPN 7
	PUSHARG 7
	PUSH 0
	CMPL
	JZ LOC_4D50
	PUSH 0
	POPN 7
LOC_4D50:
	PUSHARG 7
	PUSHARG -3
	CMPG
	JZ LOC_4D7C
	PUSHARG -3
	POPN 7
LOC_4D7C:
	PUSHARG 7
	PUSH 0
	CMPZ
	JZ LOC_4F44
	PUSHSTR "ProduceSoldier"
	PUSHARG 3
	PUSHARG 7
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG 1
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 24
	DELAY
	PUSHARG 1
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 6
	DELAY
	PUSHSTR "m002snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "m002snd03"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMP
	JZ LOC_4EAC
	PUSH 6576
	PUSH 0
	PUSH 40
	CALL MoveCamera
	JMP LOC_4ECC
LOC_4EAC:
	PUSH 240
	PUSH 0
	PUSH 40
	CALL MoveCamera
LOC_4ECC:
	PUSH 100
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	PUSH 20
	CALL MoveCamera
	JMP LOC_4F5C
LOC_4F44:
	PUSHARG 1
	PUSHARG 2
	CALL CastFail
LOC_4F5C:
	PUSH 8
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 2

}}

void function BombLight (arg_0, arg_1) {
__asm{
	STACK 5
	PUSHARG -3
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 2
	PUSHARG -2
	JCOND 0, LOC_4FFC
	JCOND 1, LOC_50A8
	JCOND 2, LOC_5138
	JCOND 3, LOC_51C8
	POP
	JMP LOC_5468
LOC_4FFC:
	PUSHARG -3
	PUSH 7019
	PUSHARG 2
	PUSH 50
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 6
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHARG 1
	PUSH 131072
	PUSH 131072
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 10
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_5468
LOC_50A8:
	PUSHARG -3
	PUSH 13012
	PUSHARG 2
	PUSH 50
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 40960
	PUSH 40960
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 20
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_5468
LOC_5138:
	PUSHARG -3
	PUSH 7021
	PUSHARG 2
	PUSH 50
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 131072
	PUSH 131072
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 20
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_5468
LOC_51C8:
	PUSHARG -3
	PUSH 7046
	PUSHARG 2
	PUSH 80
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 4
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 4
	DELAY
	PUSHARG -3
	PUSH 7047
	PUSHARG 2
	PUSH 80
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 2
	PUSH 0
	CMP
	JZ LOC_52E0
	PUSHARG 1
	PUSH 16
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	JMP LOC_5310
LOC_52E0:
	PUSHARG 1
	PUSH 16
	NEG
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_5310:
	PUSH 32768
	POPN 4
	PUSH 65536
	POPN 5
	PUSHARG 1
	PUSHARG 4
	PUSHARG 5
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 0
	POPN 3
LOC_5388:
	PUSHARG 3
	PUSH 16
	CMPL
	JZ LOC_5460
	PUSHARG 1
	PUSHARG 4
	PUSHARG 5
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	PUSHARG 4
	PUSH 3072
	ADD
	POPN 4
	PUSHARG 5
	PUSH 3840
	SUB
	POPN 5
	PUSHARG 3
	PUSH 4
	CMP
	JZ LOC_5450
	PUSHARG 1
	PUSH 1
	NEG
	PUSH 0
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
LOC_5450:
	INCN 3
	JMP LOC_5388
LOC_5460:
	JMP LOC_5468
LOC_5468:
	RETN 2

}}

void function ShootObjectCallback (arg_0, arg_1) callsign 3001 {
__asm{
	STACK 10
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_578C
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 8
	PUSHARG -3
	PUSH 1
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 9
	PUSHARG -3
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 10
	PUSHARG 8
	PUSH 1
	CMP
	JZ LOC_5530
	PUSHARG -2
	PUSH 50
	SYSCALL 0x127, (2 | (0 << 16)) ; 0x0127 
LOC_5530:
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CALL Hurt
	PUSHARG 8
	PUSH 2
	CMP
	JZ LOC_5598
	PUSHARG -3
	PUSH 16
	PUSH 8
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_55BC
LOC_5598:
	PUSHARG -3
	PUSH 2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_55BC:
	PUSHARG 8
	PUSH 0
	CMP
	PUSHARG 9
	PUSH 0
	CMP
	ORNZ
	JZ LOC_5630
	PUSHARG -3
	PUSHARG -2
	PUSH 13009
	PUSH 1
	PUSH 60
	PUSH 0
	CALL HitGeneral
	JMP LOC_5784
LOC_5630:
	PUSHARG 8
	PUSH 1
	CMP
	PUSHARG 9
	PUSH 0
	CMP
	ORNZ
	JZ LOC_56A4
	PUSHARG -3
	PUSHARG -2
	PUSH 13009
	PUSH 1
	PUSH 60
	PUSH 0
	CALL HitGeneral
	JMP LOC_5784
LOC_56A4:
	PUSHARG 8
	PUSH 2
	CMP
	PUSHARG 9
	PUSH 0
	CMP
	ORNZ
	JZ LOC_5718
	PUSHARG -3
	PUSHARG -2
	PUSH 13009
	PUSH 1
	PUSH 60
	PUSH 0
	CALL HitGeneral
	JMP LOC_5784
LOC_5718:
	PUSHARG 8
	PUSH 0
	CMP
	PUSHARG 9
	PUSH 1
	CMP
	ORNZ
	JZ LOC_5784
	PUSHARG -3
	PUSHARG -2
	PUSH 13008
	PUSH 2
	PUSH 60
	PUSH 0
	CALL HitGeneral
LOC_5784:
	JMP LOC_57D8
LOC_578C:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "Blood"
	PUSHARG -2
	PUSH 16
	PUSH 0
	PUSH 0
	CALLBS
LOC_57D8:
	RETN 2

}}

void function ZoomFreq (arg_0, arg_1) {
__asm{
	STACK 1
	PUSH 0
	POPN 1
LOC_57F8:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_58B4
	PUSHARG 1
	PUSH 0
	CMP
	JZ LOC_586C
	PUSHARG -3
	PUSH 40960
	PUSH 40960
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	POPN 1
	JMP LOC_58A0
LOC_586C:
	PUSHARG -3
	PUSH 61440
	PUSH 61440
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 0
	POPN 1
LOC_58A0:
	PUSHARG -2
	DELAY
	JMP LOC_57F8
LOC_58B4:
	RETN 2

}}

void function CosZoomY (arg_0, arg_1) {
__asm{
	STACK 2
	PUSH 0
	POPN 2
LOC_58D4:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_5984
	PUSHARG 2
	PUSHARG -2
	SYSCALL 0x202, (2 | (1 << 16)) ; 0x0202 
	POPN 1
	PUSHARG -3
	PUSH 32768
	PUSHARG 1
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	PUSHARG 2
	PUSH 16
	ADD
	POPN 2
	PUSHARG 2
	PUSH 255
	AND
	POPN 2
	JMP LOC_58D4
LOC_5984:
	RETN 2

}}

void function ScaleShadow (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5) {
__asm{
	STACK 2
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_59B8
	RETN 6
LOC_59B8:
	PUSHARG -7
	PUSHARG -6
	PUSHARG -5
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -5
	PUSH 0
	CMP
	JZ LOC_5A40
	PUSHARG 1
	PUSH 8
	NEG
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	JMP LOC_5A6C
LOC_5A40:
	PUSHARG 1
	PUSH 8
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_5A6C:
	PUSHARG 1
	PUSHARG -5
	PUSH 0
	PUSHARG -4
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHARG 1
	PUSHARG -3
	PUSHARG -3
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 2
	DELAY
	PUSHARG 1
	PUSH 60
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 8192
	PUSH 12
	DIV
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
LOC_5B50:
	PUSHARG -7
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_5BB0
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_5B9C
	RETN 6
LOC_5B9C:
	PUSH 4
	DELAY
	JMP LOC_5B50
LOC_5BB0:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 6

}}

void function FireTail (arg_0, arg_1, arg_2) {
__asm{
	STACK 1
	PUSHARG -4
	PUSH 2501
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_5C5C
	PUSHARG 1
	PUSH 16
	NEG
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	JMP LOC_5C88
LOC_5C5C:
	PUSHARG 1
	PUSH 16
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_5C88:
	PUSHARG 1
	PUSHARG -3
	PUSH 0
	PUSHARG -2
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
LOC_5CB4:
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_5D34
	PUSHSTR "ScaleShadow"
	PUSHARG 1
	PUSH 13010
	PUSHARG -3
	PUSHARG -2
	PUSH 2
	SUB
	PUSH 20480
	PUSH 14
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSH 10
	DELAY
	JMP LOC_5CB4
LOC_5D34:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 3

}}

void function FlyLight (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 5
	PUSH 0
	POPN 5
	PUSHARG -6
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 3
	PUSHARG -6
	PUSHARG -5
	PUSHARG 3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG -6
	PUSHARG 3
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 2
	PUSHARG 3
	PUSH 0
	PUSH 16
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_5ECC
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_5EA8
	PUSHARG 2
	PUSH 49152
	PUSH 49152
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "FireTail"
	PUSHARG 2
	PUSHARG 3
	PUSH 16
	PUSH 0
	CALLBS
	JMP LOC_5EC4
LOC_5EA8:
	PUSHARG -2
	PUSH 2
	CMP
	JZ LOC_5EC4
LOC_5EC4:
	JMP LOC_6028
LOC_5ECC:
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_6028
	PUSHARG 2
	PUSH 13011
	PUSHARG 3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 5
	PUSHARG 5
	PUSHARG 2
	PUSHARG 3
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 5
	PUSHARG 3
	PUSH 0
	PUSH 16
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_5FCC
	PUSHARG 5
	PUSH 9
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	JMP LOC_5FFC
LOC_5FCC:
	PUSHARG 5
	PUSH 9
	NEG
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_5FFC:
	PUSHSTR "CosZoomY"
	PUSHARG 2
	PUSH 81920
	PUSH 0
	PUSH 0
	CALLBS
LOC_6028:
	PUSHARG -4
	POPN 1
LOC_6038:
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	POPN 4
	PUSHARG 4
	ZERO
	JZ LOC_6078
	PUSH 0
	POPN 1
LOC_6078:
	PUSH 1
	DELAY
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_6038
	PUSHARG -2
	PUSH 2
	CMP
	JZ LOC_6124
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 5
	JZ LOC_611C
	PUSHARG 5
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_611C:
	JMP LOC_615C
LOC_6124:
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 5
	JZ LOC_615C
	PUSHARG 5
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_615C:
	RETN 5

}}

void function ShootObject (arg_0, arg_1) {
__asm{
LOC_6164:
	STACK 10
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\003\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 3
	PUSH 0
	POPN 10
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	CMP
	JZ LOC_624C
	PUSH 0
	PUSH 90
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 10
LOC_624C:
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_6294
	PUSH 0
	POPN 5
	PUSH 1
	NEG
	POPN 9
	JMP LOC_62B4
LOC_6294:
	PUSH 128
	POPN 5
	PUSH 1
	POPN 9
LOC_62B4:
	PUSHARG 1
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 7
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 8
	PUSHARG 7
	PUSH 180
	PUSHARG 9
	MUL
	SUB
	PUSHARG 8
	PUSH 120
	SUB
	PUSHARG 10
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSH 15
	DELAY
	PUSHARG -3
	JCOND 0, LOC_638C
	JCOND 1, LOC_63FC
	POP
	JMP LOC_646C
LOC_638C:
	PUSHARG 1
	PUSH 131072
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 15
	DELAY
	PUSHARG 1
	PUSHSTR "m003snd01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	JMP LOC_64D4
LOC_63FC:
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 15
	DELAY
	PUSHARG 1
	PUSHSTR "m003snd02"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	JMP LOC_64D4
LOC_646C:
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 15
	DELAY
	PUSHARG 1
	PUSHSTR "m003snd03"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
LOC_64D4:
	PUSHARG 1
	PUSH 13001
	PUSHARG -3
	PUSH 2
	MUL
	ADD
	PUSHARG 5
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 4
	PUSHARG 4
	PUSH 0
	PUSHARG -3
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 4
	PUSH 1
	PUSHARG -2
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG -3
	PUSH 2
	CMPZ
	JZ LOC_65C0
	PUSHARG 4
	PUSHARG 1
	PUSHARG 5
	PUSH 80
	PUSH 80
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	JMP LOC_6600
LOC_65C0:
	PUSHARG 4
	PUSHARG 1
	PUSHARG 5
	PUSH 36
	PUSH 80
	PUSH 11
	SUB
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
LOC_6600:
	PUSHARG 4
	PUSHARG 5
	PUSH 0
	PUSH 16
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 4
	PUSH 16777216
	PUSH 33554432
	PUSHARG -3
	PUSH 2
	CMP
	MUL
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 4
	PUSH 3001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_6700
	PUSHSTR "FlyLight"
	PUSHARG 4
	PUSH 13002
	PUSHARG -3
	PUSH 2
	MUL
	ADD
	PUSH 9999
	PUSHARG -2
	PUSHARG -3
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_673C
LOC_6700:
	PUSHSTR "FlyLight"
	PUSHARG 4
	PUSH 13007
	PUSH 9999
	PUSHARG -2
	PUSHARG -3
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_673C:
	PUSHSTR "LockCamera"
	PUSHARG 4
	PUSH 180
	PUSH 120
	NEG
	PUSHARG 10
	ADD
	PUSHARG 3
	CALLBS
LOC_6778:
	PUSHARG 4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	POPN 6
	PUSHARG 4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 7
	PUSHARG 7
	PUSH 0
	CMPLE
	PUSHARG 7
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	CMPGE
	ORZ
	JZ LOC_6804
	PUSHARG 4
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	JMP LOC_682C
LOC_6804:
	PUSH 1
	DELAY
	PUSHARG 6
	PUSH 1
	CMP
	JNZ LOC_6778
LOC_682C:
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 2

}}

void function RushcartCallback (arg_0, arg_1) callsign 4001 {
__asm{
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CALL Hurt
	PUSHSTR "Blood"
	PUSHARG -2
	PUSH 16
	PUSH 0
	PUSH 0
	CALLBS
	RETN 2

}}

void function CreateRushCart (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 1
	PUSH 0
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSHARG -5
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 4001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSHARG -3
	PUSH 0
	PUSH 8
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -2
	JZ LOC_6A1C
	PUSHSTR "LockCameraLineDelay"
	PUSHARG 1
	PUSH 2
	PUSHARG -2
	SUB
	PUSH 80
	MUL
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 280
	CALLBS
LOC_6A1C:
	PUSH 400
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 5

}}

void function RushCart (arg_0) {
__asm{
LOC_6A54:
	STACK 17
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\004\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 3
	PUSHARG 1
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 7
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 8
	PUSHARG 7
	PUSHARG 8
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 1
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHARG 1
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 30
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_6C08
	PUSH 1
	NEG
	POPN 11
	PUSH 0
	POPN 4
	JMP LOC_6C28
LOC_6C08:
	PUSH 1
	POPN 11
	PUSH 128
	POPN 4
LOC_6C28:
	PUSHINV 5 ; INTV_IS_RIGHT
	CALL GetSoldierMaxX
	POPN 9
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_6C8C
	PUSHARG 9
	PUSH 320
	SUB
	PUSH 0
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	JMP LOC_6CB4
LOC_6C8C:
	PUSHARG 9
	PUSH 320
	ADD
	PUSH 0
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
LOC_6CB4:
	PUSH 15
	DELAY
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_6E58
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 252
	PUSH 72
	SUB
	PUSH 2501
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 252
	PUSH 14001
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 828
	PUSH 72
	SUB
	PUSH 2501
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 828
	PUSH 14001
	PUSHARG 4
	PUSHARG -2
	PUSH 1
	ADD
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_7134
LOC_6E58:
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 108
	PUSH 72
	SUB
	PUSH 2501
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 108
	PUSH 14001
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 252
	PUSH 72
	SUB
	PUSH 2501
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 252
	PUSH 14001
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 828
	PUSH 72
	SUB
	PUSH 2501
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 828
	PUSH 14001
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 972
	PUSH 72
	SUB
	PUSH 2501
	PUSHARG 4
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateRushCart"
	PUSHARG 9
	PUSH 1200
	PUSHARG 11
	MUL
	ADD
	PUSH 972
	PUSH 14001
	PUSHARG 4
	PUSHARG -2
	PUSH 1
	ADD
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_7134:
	PUSHSTR "CreateRushCart"
	INST_45
	PUSH 40
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function LockTargetTime3 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 3
	PUSHARG -6
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 3
	PUSHARG -6
	PUSHARG -5
	PUSHARG 3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG -3
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSHARG -2
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG -4
	POPN 1
LOC_7218:
	PUSHARG 2
	PUSHARG -6
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_7218
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 5

}}

void function LockGeneral (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -3
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG -2
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	ORZ
	JZ LOC_73D8
	PUSHARG -2
	SYSCALL 0x115, (1 | (1 << 16)) ; GetSoldierSide 
	POPN 2
	PUSHARG 2
	SYSCALL 0x117, (1 | (1 << 16)) ; GetMajorHP 
	PUSH 0
	CMP
	JZ LOC_73AC
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	JMP LOC_73D8
LOC_73AC:
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 48
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_73D8:
	PUSHSTR "LockTargetTime2"
	PUSHARG 1
	PUSH 15007
	PUSH 8
	PUSH 0
	CALLBS
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG 1
	PUSH 20
	PUSH 0
	CALLBS
	PUSH 8
	DELAY
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function BigThunderCallback (arg_0, arg_1) callsign 5002 {
__asm{
	STACK 2
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	PUSH 2
	DIV
	CALL Hurt
	PUSHARG -3
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG -2
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	ORZ
	JZ LOC_75B4
	PUSHARG -2
	SYSCALL 0x115, (1 | (1 << 16)) ; GetSoldierSide 
	POPN 2
	PUSHARG 2
	SYSCALL 0x117, (1 | (1 << 16)) ; GetMajorHP 
	PUSH 0
	CMP
	JZ LOC_7588
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	JMP LOC_75B4
LOC_7588:
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 48
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_75B4:
	PUSHSTR "LockTargetTime2"
	PUSHARG 1
	PUSH 15007
	PUSH 8
	PUSH 0
	CALLBS
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 16
	PUSH 0
	CALLBS
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSH 8
	DELAY
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 14
	PUSH 0
	CALLBS
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 10
	PUSH 0
	CALLBS
	PUSH 8
	DELAY
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 8
	PUSH 0
	CALLBS
	PUSH 8
	DELAY
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function ThunderAttachAttack (arg_0, arg_1, arg_2) {
__asm{
	STACK 4
	PUSHARG -4
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSHARG -4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG -4
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG -3
	PUSHARG 1
	ADD
	PUSH 2
	DIV
	PUSHARG -2
	PUSHARG 2
	ADD
	PUSH 2
	DIV
	PUSH 20
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 128
	MUL
	PUSH 15005
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 3
	PUSHARG 3
	PUSH 131072
	PUSH 81920
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 3
	PUSH 16
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -3
	PUSHARG 1
	ADD
	PUSH 2
	DIV
	PUSHARG -2
	PUSHARG 2
	ADD
	PUSH 2
	DIV
	PUSH 15
	PUSH 44
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 128
	MUL
	PUSH 15005
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 3
	PUSHARG 3
	PUSH 131072
	PUSH 81920
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 3
	PUSH 16
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -3
	PUSHARG 1
	ADD
	PUSH 2
	DIV
	PUSHARG -2
	PUSHARG 2
	ADD
	PUSH 2
	DIV
	PUSH 25
	PUSH 50
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 128
	MUL
	PUSH 15005
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 3
	PUSHARG 3
	PUSH 131072
	PUSH 81920
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 3
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 24
	DELAY
	PUSH 0
	POPN 4
LOC_7A80:
	PUSHARG 4
	PUSH 12
	CMPL
	JZ LOC_7BE8
	PUSHARG -4
	PUSH 15006
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 128
	MUL
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSHARG 3
	PUSH 12
	NEG
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	PUSH 16
	PUSH 42
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 3
	PUSH 131072
	PUSH 196608
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 3
	PUSH 16
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 1
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 4
	JMP LOC_7A80
LOC_7BE8:
	PUSH 20
	DELAY
	PUSHARG -4
	PUSH 2501
	PUSH 0
	PUSH 0
	PUSH 2
	PUSH 33554432
	PUSH 0
	CALL LockByCenter
	RETN 3

}}

void function ThunderAttach (arg_0) {
__asm{
	STACK 6
	PUSHARG -2
	SYSCALL 0x101, (1 | (1 << 16)) ; GetObjectXY 
	POPN 1
	PUSHARG -2
	SYSCALL 0x102, (1 | (1 << 16)) ; 0x0102 
	POPN 2
	PUSHARG -2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHARG -2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 6
	PUSHARG 1
	PUSH 1
	ADD
	PUSHARG 2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
	PUSHARG 1
	PUSH 1
	SUB
	PUSHARG 2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 4
	PUSHARG 3
	JZ LOC_7DA4
	PUSHARG 3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	PUSH 14409
	CMPZ
	JZ LOC_7DA4
	PUSHARG 3
	PUSH 0
	PUSH 14409
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHSTR "ThunderAttachAttack"
	PUSHARG 3
	PUSHARG 5
	PUSHARG 6
	PUSH 0
	CALLBS
LOC_7DA4:
	PUSHARG 4
	JZ LOC_7E34
	PUSHARG 4
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	PUSH 14409
	CMPZ
	JZ LOC_7E34
	PUSHARG 4
	PUSH 0
	PUSH 14409
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHSTR "ThunderAttachAttack"
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	PUSH 0
	CALLBS
LOC_7E34:
	RETN 1

}}

void function ThunderCallback (arg_0, arg_1) callsign 5001 {
__asm{
	PUSHARG -3
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	INST_09 4
	PUSH 1
	CMP
	JZ LOC_7EA0
	PUSHSTR "ThunderAttach"
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
LOC_7EA0:
	INST_09 5
	PUSH 0
	CMP
	JZ LOC_7EEC
	PUSH 1
	SETARG 5
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CALL Hurt
LOC_7EEC:
	PUSHARG -2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	ORZ
	JZ LOC_7F54
	PUSHSTR "LockGeneral"
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	CALLBS
	JMP LOC_7FAC
LOC_7F54:
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 15007
	PUSH 8
	PUSH 0
	CALLBS
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 15
	PUSH 0
	CALLBS
LOC_7FAC:
	RETN 2

}}

void function LockTargetTime (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSH 40
	PUSH 70
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -4
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 3
	PUSHARG -4
	PUSHARG -3
	PUSHARG 3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 5001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 2
	PUSH 98304
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -2
	POPN 1
LOC_8098:
	PUSHARG 2
	PUSHARG -4
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_8098
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function CreateThunderSparkle (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 3
	PUSH 8
	POPN 1
LOC_817C:
	PUSHARG 1
	JZ LOC_82B4
	PUSHARG 3
	PUSH 10013
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -2
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSH 12288
	PUSH 12288
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 2
	PUSH 8192
	SYSCALL 0x21, (2 | (0 << 16)) ; 0x0021 
	PUSHARG 2
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 2
	PUSH 256
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	DECN 1
	JMP LOC_817C
LOC_82B4:
	PUSHARG 3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 3

}}

void function CreateThunderSmoke (arg_0, arg_1) {
__asm{
	STACK 1
	PUSH 2
	DELAY
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 128
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSH 15004
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 2
	SYSCALL 0x31, (2 | (0 << 16)) ; 0x0031 
	PUSHARG 1
	PUSH 8192
	PUSH 8192
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "CreateThunderSparkle"
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG 1
	PUSH 2048
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG 1
	PUSH 30
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function LockThunder (arg_0, arg_1, arg_2) {
__asm{
	STACK 2
	PUSH 40
	PUSH 70
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSH 1
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	CMP
	JZ LOC_847C
	PUSHSTR "CreateThunderSmoke"
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	CALLBS
LOC_847C:
	INST_09 4
	JZ LOC_84A4
	PUSH 15010
	POPN 2
	JMP LOC_84C8
LOC_84A4:
	PUSH 15001
	PUSH 15003
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
LOC_84C8:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 2
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 5001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSH 4
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function Thunder (arg_0, arg_1) {
__asm{
LOC_8598:
	STACK 21
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\005\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHARG -2
	SETARG 4
	PUSH 0
	SETARG 5
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 3
	PUSHARG 1
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 9
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 10
	PUSHARG 9
	PUSHARG 10
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 1
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHARG 1
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 30
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_8758
	PUSH 0
	POPN 4
	JMP LOC_8768
LOC_8758:
	PUSH 128
	POPN 4
LOC_8768:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	POPN 17
	PUSH 0
	POPN 18
	PUSHARG 17
	PUSHARG -3
	CMPL
	JZ LOC_87D8
	PUSHARG -3
	PUSHARG 17
	SUB
	POPN 18
LOC_87D8:
	PUSHARG -3
	PUSHARG 18
	SUB
	PUSH 0
	CMPG
	JZ LOC_8C48
	PUSH 0
	POPN 8
	PUSHARG -3
	PUSHARG 18
	SUB
	POPN 7
LOC_882C:
	PUSHARG 8
	PUSH 0
	CMP
	JZ LOC_8924
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 6
	PUSHARG 6
	PUSH 0
	CMP
	JZ LOC_889C
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 6
LOC_889C:
	PUSHARG 6
	SYSCALL 0x101, (1 | (1 << 16)) ; GetObjectXY 
	POPN 12
	PUSHARG 6
	SYSCALL 0x102, (1 | (1 << 16)) ; 0x0102 
	POPN 13
	PUSHARG 6
	POPN 5
	PUSHARG 5
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 15
	PUSHARG 5
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 16
	JMP LOC_8A84
LOC_8924:
	PUSHARG 8
	PUSH 8
	CMPG
	JZ LOC_8970
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 5
	JMP LOC_8A84
LOC_8970:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 12
	PUSHARG 13
	PUSH 3
	PUSH 4
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 14
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 12
	PUSHARG 13
	PUSH 3
	PUSH 4
	PUSH 0
	PUSHARG 14
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 5
	PUSHARG 5
	PUSH 0
	CMP
	PUSHARG 5
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	ORZ
	JZ LOC_8A84
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 5
LOC_8A84:
	PUSHARG 5
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 9
	PUSHARG 5
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 10
	PUSHARG 8
	PUSH 0
	CMP
	JZ LOC_8B20
	PUSH 1
	POPN 8
	PUSHARG 9
	POPN 19
	PUSHARG 9
	POPN 20
	PUSHARG 10
	POPN 21
	JMP LOC_8BA4
LOC_8B20:
	PUSHARG 19
	PUSHARG 9
	CMPL
	JZ LOC_8B4C
	PUSHARG 9
	POPN 19
LOC_8B4C:
	PUSHARG 20
	PUSHARG 9
	CMPG
	JZ LOC_8B78
	PUSHARG 9
	POPN 20
LOC_8B78:
	PUSHARG 21
	PUSHARG 10
	CMPG
	JZ LOC_8BA4
	PUSHARG 10
	POPN 21
LOC_8BA4:
	INST_09 4
	JZ LOC_8BCC
	PUSH 15010
	POPN 11
	JMP LOC_8BF0
LOC_8BCC:
	PUSH 15001
	PUSH 15003
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 11
LOC_8BF0:
	PUSHSTR "LockTargetTime"
	PUSHARG 5
	PUSHARG 11
	PUSH 4
	PUSH 0
	CALLBS
	DECN 7
	PUSHARG 7
	PUSH 0
	CMPG
	JNZ LOC_882C
	JMP LOC_8C90
LOC_8C48:
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 19
	PUSHARG 19
	POPN 20
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 21
LOC_8C90:
	PUSHARG 19
	PUSHARG 20
	CMP
	JZ LOC_8CE4
	PUSHARG 19
	PUSH 320
	ADD
	POPN 19
	PUSHARG 20
	PUSH 320
	SUB
	POPN 20
LOC_8CE4:
	PUSHARG 18
	POPN 7
	PUSHARG 7
	PUSH 20
	CMPG
	JZ LOC_8D20
	PUSH 20
	POPN 7
LOC_8D20:
	PUSHARG 20
	PUSHARG 19
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 9
	PUSH 150
	PUSH 650
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 10
	PUSHSTR "LockThunder"
	PUSHARG 9
	PUSHARG 10
	PUSH 128
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSH 0
	CALLBS
	DECN 7
	PUSHARG 7
	PUSH 0
	CMPG
	JNZ LOC_8D20
	PUSHARG 21
	PUSH 120
	SUB
	POPN 21
	PUSHARG 17
	PUSH 0
	CMP
	JZ LOC_8E60
	PUSHARG 19
	PUSHARG 20
	ADD
	PUSH 2
	DIV
	POPN 9
	PUSHARG 9
	PUSHARG 21
	PUSH 40
	CALL MoveCamera
	JMP LOC_8E8C
LOC_8E60:
	PUSHARG 15
	PUSHARG 16
	PUSH 140
	SUB
	PUSH 40
	CALL MoveCamera
LOC_8E8C:
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 2

}}

void function BigThunder () {
__asm{
LOC_8EC4:
	STACK 7
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 3
	PUSHARG 1
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 6
	PUSHARG 5
	PUSHARG 6
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 1
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHARG 1
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 20
	DELAY
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_903C
	PUSH 0
	POPN 4
	JMP LOC_904C
LOC_903C:
	PUSH 128
	POPN 4
LOC_904C:
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHARG 2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 6
	PUSHSTR "m005snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG 5
	PUSHARG 6
	PUSH 120
	SUB
	PUSH 40
	CALL MoveCamera
	PUSHSTR "LockTargetTime3"
	PUSHARG 2
	PUSH 15008
	PUSH 4
	PUSH 16777216
	PUSH 5002
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 4
	DELAY
	PUSHSTR "LockTargetTime3"
	PUSHARG 2
	PUSH 15009
	PUSH 4
	PUSH 16777216
	PUSH 5002
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 0

}}

void function HideArrow (arg_0, arg_1) {
__asm{
	PUSH 30
	PUSH 40
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -2
	JZ LOC_91DC
	PUSHARG -2
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_91DC:
	PUSHARG -3
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function TraceArrow (arg_0, arg_1) {
__asm{
	STACK 7
	PUSH 0
	POPN 7
LOC_9220:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_94AC
	PUSHARG -3
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_9498
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG -3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG -3
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 5
	INST_09 7
	PUSH 0
	CMPG
	JZ LOC_9318
	PUSH 16012
	PUSH 16018
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 6
	DECARG 7
	JMP LOC_933C
LOC_9318:
	PUSH 16012
	PUSH 16013
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 6
LOC_933C:
	PUSHARG -3
	PUSHARG 6
	PUSHARG 5
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 4
	PUSHARG -2
	PUSH 1
	CMP
	PUSH 1
	PUSH 256
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	AND
	PUSH 0
	CMP
	ORNZ
	JZ LOC_9450
	PUSHARG 6
	PUSH 7027
	CMP
	PUSHARG 6
	PUSH 7028
	CMP
	ORZ
	JZ LOC_9450
	PUSHARG -3
	PUSH 7045
	PUSHARG 5
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 7
	PUSHARG 7
	PUSH 32768
	PUSH 49152
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_9450:
	PUSHSTR "HideArrow"
	PUSHARG 4
	PUSHARG 7
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	JMP LOC_94AC
LOC_9498:
	PUSH 1
	DELAY
	JMP LOC_9220
LOC_94AC:
	RETN 2

}}

void function ArrowCallback1 (arg_0, arg_1) callsign 6001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_9564
	INST_09 8
	JZ LOC_9504
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 8
	DIV
	POPN 1
LOC_9504:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_955C
	INST_09 8
	PUSH 2
	MUL
	SETARG 8
LOC_955C:
	JMP LOC_9584
LOC_9564:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_9584:
	RETN 2

}}

void function ArrowCallback2 (arg_0, arg_1) callsign 6002 {
__asm{
	STACK 3
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_9668
	INST_09 8
	JZ LOC_95DC
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 8
	DIV
	POPN 3
LOC_95DC:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 3
	CALL Hurt
	PUSHARG 3
	PUSH 0
	CMPG
	JZ LOC_9660
	INST_09 8
	PUSH 2
	MUL
	SETARG 8
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_9660:
	JMP LOC_96B4
LOC_9668:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_96B4:
	RETN 2

}}

void function FlyArrowLU () callsign 6003 {
__asm{
	STACK 2
	SYSCALL 0xB, (0 | (1 << 16)) ; 0x000B 
	POPN 2
	PUSHARG 2
	PUSH 16003
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG 2
	PUSH 128
	PUSH 64
	PUSH 104
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 128
	PUSH 32
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSHSTR "arrow"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	INST_09 6
	PUSH 1
	CMP
	JZ LOC_9840
	PUSHARG 2
	PUSH 16009
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG 2
	PUSH 128
	PUSH 64
	PUSH 104
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 128
	PUSH 32
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
LOC_9840:
	RETN 0

}}

void function FlyArrowRU () callsign 6004 {
__asm{
	STACK 2
	SYSCALL 0xB, (0 | (1 << 16)) ; 0x000B 
	POPN 2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16003
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 64
	PUSH 104
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 128
	PUSH 96
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSHSTR "arrow"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	INST_09 6
	PUSH 1
	CMP
	JZ LOC_99CC
	PUSHARG 2
	PUSH 16009
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 64
	PUSH 104
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 128
	PUSH 96
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
LOC_99CC:
	RETN 0

}}

void function FlyArrowLB2 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 1
	PUSHARG -4
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16004
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSH 260
	ADD
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG -2
	JZ LOC_9AB8
	PUSHARG 1
	PUSH 6001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	JMP LOC_9B00
LOC_9AB8:
	PUSHARG 1
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHSTR "TraceArrow"
	PUSHARG 1
	PUSHARG -3
	PUSH 0
	PUSH 0
	CALLBS
LOC_9B00:
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_9BE4
	PUSHARG -2
	JZ LOC_9B48
	PUSHARG 1
	PUSH 6002
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_9B48:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16010
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSH 260
	ADD
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
LOC_9BE4:
	RETN 5

}}

void function FlyArrowRB2 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 1
	PUSHARG -4
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16007
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSH 260
	SUB
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG -2
	JZ LOC_9CD0
	PUSHARG 1
	PUSH 6001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	JMP LOC_9D18
LOC_9CD0:
	PUSHARG 1
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHSTR "TraceArrow"
	PUSHARG 1
	PUSHARG -3
	PUSH 0
	PUSH 0
	CALLBS
LOC_9D18:
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_9DFC
	PUSHARG -2
	JZ LOC_9D60
	PUSHARG 1
	PUSH 6002
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_9D60:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16010
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSH 260
	SUB
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
LOC_9DFC:
	RETN 5

}}

void function FlyArrowLB1 (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
	PUSHARG -3
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16004
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	PUSH 24
	ADD
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 6001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_A00C
	PUSHARG 1
	PUSH 6002
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16010
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	PUSH 24
	ADD
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
LOC_A00C:
	RETN 4

}}

void function FlyArrowRB1 (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
	PUSHARG -3
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16007
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	NEG
	PUSH 24
	SUB
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 6001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_A224
	PUSHARG 1
	PUSH 6002
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16010
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	NEG
	PUSH 24
	SUB
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
LOC_A224:
	RETN 4

}}

void function ChangeRightFirePos (arg_0, arg_1) {
__asm{
	PUSH 38
	PUSHARG -2
	ADD
	DELAY
	PUSHARG -3
	PUSH 14
	NEG
	PUSH 0
	PUSH 31
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSH 8
	DELAY
	PUSHARG -3
	PUSH 10
	PUSH 0
	PUSH 30
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSH 8
	DELAY
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function ChangeLeftFirePos (arg_0, arg_1) {
__asm{
	PUSH 38
	PUSHARG -2
	ADD
	DELAY
	PUSHARG -3
	PUSH 14
	PUSH 0
	PUSH 31
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSH 8
	DELAY
	PUSHARG -3
	PUSH 10
	NEG
	PUSH 0
	PUSH 30
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSH 8
	DELAY
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function AddSoldierRight (arg_0, arg_1, arg_2) {
__asm{
	STACK 1
	PUSHARG -2
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16001
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	RETN 3

}}

void function AddSoldierLeft (arg_0, arg_1, arg_2) {
__asm{
	STACK 1
	PUSHARG -2
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16002
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	RETN 3

}}

void function ProduceArrowSoldier (arg_0, arg_1, arg_2) {
__asm{
LOC_A474:
	STACK 6
	PUSHARG -3
	POPN 2
	PUSH 0
	POPN 4
	SYSCALL 0x12D, (0 | (1 << 16)) ; GetBattleWidth 
	PUSH 96
	MUL
	PUSH 240
	SUB
	POPN 6
LOC_A4C8:
	PUSH 9
	POPN 1
LOC_A4D8:
	PUSHARG -4
	PUSH 1
	CMP
	JZ LOC_A738
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16006
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 5
	PUSHARG 5
	PUSH 240
	PUSH 96
	PUSH 7
	MUL
	SUB
	PUSHARG 4
	PUSH 96
	MUL
	SUB
	PUSH 180
	PUSHARG 1
	PUSH 72
	MUL
	ADD
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
	PUSHSTR "AddSoldierLeft"
	PUSH 240
	PUSH 96
	PUSH 7
	MUL
	SUB
	PUSHARG 4
	PUSH 96
	MUL
	SUB
	PUSH 180
	PUSHARG 1
	PUSH 72
	MUL
	ADD
	PUSHARG 3
	PUSH 0
	CALLBS
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_A730
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16008
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 5
	PUSHARG 5
	PUSH 240
	PUSH 96
	PUSH 7
	MUL
	SUB
	PUSH 27
	ADD
	PUSHARG 4
	PUSH 96
	MUL
	SUB
	PUSH 180
	PUSHARG 1
	PUSH 72
	MUL
	ADD
	PUSH 14
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHSTR "ChangeLeftFirePos"
	PUSHARG 5
	PUSHARG 3
	PUSH 0
	PUSH 0
	CALLBS
LOC_A730:
	JMP LOC_A974
LOC_A738:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16005
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 5
	PUSHARG 5
	PUSHARG 6
	PUSH 96
	PUSH 7
	MUL
	ADD
	PUSHARG 4
	PUSH 96
	MUL
	ADD
	PUSH 180
	PUSHARG 1
	PUSH 72
	MUL
	ADD
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
	PUSHSTR "AddSoldierRight"
	PUSHARG 6
	PUSH 96
	PUSH 7
	MUL
	ADD
	PUSHARG 4
	PUSH 96
	MUL
	ADD
	PUSH 180
	PUSHARG 1
	PUSH 72
	MUL
	ADD
	PUSHARG 3
	PUSH 0
	CALLBS
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_A974
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16008
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 5
	PUSHARG 5
	PUSHARG 6
	PUSH 96
	PUSH 7
	MUL
	ADD
	PUSH 27
	SUB
	PUSHARG 4
	PUSH 96
	MUL
	ADD
	PUSH 180
	PUSHARG 1
	PUSH 72
	MUL
	ADD
	PUSH 14
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHSTR "ChangeRightFirePos"
	PUSHARG 5
	PUSHARG 3
	PUSH 0
	PUSH 0
	CALLBS
LOC_A974:
	DECN 2
	PUSHARG 2
	PUSH 0
	CMPLE
	JZ LOC_A9A8
	PUSH 0
	POPN 1
LOC_A9A8:
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_A4D8
	INCN 4
	PUSHARG 2
	PUSH 0
	CMPG
	JNZ LOC_A4C8
	RETN 3

}}

void function ArrowSupport (arg_0, arg_1) {
__asm{
LOC_A9F8:
	STACK 12
	PUSH 1
	SETARG 8
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\006\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHARG -2
	SETARG 6
	SYSCALL 0x12D, (0 | (1 << 16)) ; GetBattleWidth 
	PUSH 96
	MUL
	PUSH 240
	SUB
	POPN 6
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 30
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSHARG -3
	PUSHARG -2
	CALL ProduceArrowSoldier
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_AC08
	PUSHSTR "MoveCamera"
	PUSH 240
	PUSH 96
	PUSH 4
	MUL
	SUB
	PUSH 0
	PUSH 40
	PUSH 0
	CALLBS
	JMP LOC_AC58
LOC_AC08:
	PUSHSTR "MoveCamera"
	PUSHARG 6
	PUSH 96
	PUSH 4
	MUL
	ADD
	PUSH 1
	SUB
	PUSH 0
	PUSH 40
	PUSH 0
	CALLBS
LOC_AC58:
	PUSHSTR "MoveCamera"
	INST_45
	PUSH 60
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	POPN 9
	PUSH 0
	POPN 10
	PUSHARG 9
	PUSHARG -3
	CMPL
	JZ LOC_ACE0
	PUSHARG -3
	PUSHARG 9
	SUB
	POPN 10
LOC_ACE0:
	PUSHARG -3
	PUSHARG 10
	SUB
	PUSH 0
	CMPG
	JZ LOC_AF30
	PUSH 0
	POPN 2
	PUSHARG -3
	PUSHARG 10
	SUB
	POPN 1
LOC_AD34:
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_AF28
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 3
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 2
	PUSH 0
	CMP
	JZ LOC_AE04
	PUSH 1
	POPN 2
	PUSHARG 4
	POPN 11
	PUSHARG 4
	POPN 12
	JMP LOC_AE5C
LOC_AE04:
	PUSHARG 11
	PUSHARG 4
	CMPL
	JZ LOC_AE30
	PUSHARG 4
	POPN 11
LOC_AE30:
	PUSHARG 12
	PUSHARG 4
	CMPG
	JZ LOC_AE5C
	PUSHARG 4
	POPN 12
LOC_AE5C:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_AECC
	PUSHSTR "FlyArrowRB1"
	PUSHARG 3
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	CALLBS
	JMP LOC_AF18
LOC_AECC:
	PUSHSTR "FlyArrowLB1"
	PUSHARG 3
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	CALLBS
LOC_AF18:
	DECN 1
	JMP LOC_AD34
LOC_AF28:
	JMP LOC_AF5C
LOC_AF30:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 11
	PUSHARG 11
	POPN 12
LOC_AF5C:
	PUSHARG 11
	PUSHARG 12
	SUB
	PUSH 650
	CMPGE
	JZ LOC_AFB8
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_AFB0
	PUSHARG 12
	POPN 11
LOC_AFB0:
	JMP LOC_AFE0
LOC_AFB8:
	PUSHARG 11
	PUSHARG 12
	ADD
	PUSH 2
	DIV
	POPN 11
LOC_AFE0:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_B034
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_B034:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 11
	PUSHARG 10
	POPN 1
LOC_B060:
	PUSHARG 11
	PUSH 400
	NEG
	PUSH 400
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 4
	PUSH 150
	PUSH 650
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_B138
	PUSHSTR "FlyArrowRB2"
	PUSHARG 4
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 1
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_B194
LOC_B138:
	PUSHSTR "FlyArrowLB2"
	PUSHARG 4
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 1
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_B194:
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_B060
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_B20C
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_B20C:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 11
	PUSHARG -3
	PUSH 10
	DIV
	PUSH 5
	MUL
	PUSH 32
	PUSH 50
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -3
	SUB
	PUSH 8
	DIV
	ADD
	POPN 1
	PUSHARG 1
	PUSH 4
	DIV
	SETARG 7
LOC_B2A4:
	PUSHARG 11
	PUSH 400
	NEG
	PUSH 400
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 4
	PUSH 200
	PUSH 600
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHARG 4
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 7
	PUSHARG 5
	SYSCALL 0x109, (1 | (1 << 16)) ; ScreenYToBattleY 
	POPN 8
	PUSHARG 7
	PUSHARG 8
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	JZ LOC_B418
	PUSHARG 8
	SYSCALL 0x103, (1 | (1 << 16)) ; BattleXToScreenX 
	POPN 8
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	JZ LOC_B3DC
	PUSHARG 8
	PUSH 8
	PUSH 1
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	SUB
	POPN 5
	JMP LOC_B418
LOC_B3DC:
	PUSHARG 8
	PUSH 8
	PUSH 1
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	ADD
	POPN 5
LOC_B418:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_B498
	PUSHSTR "FlyArrowRB2"
	PUSHARG 4
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_B4F4
LOC_B498:
	PUSHSTR "FlyArrowLB2"
	PUSHARG 4
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_B4F4:
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_B2A4
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_B56C
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_B56C:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSH 0
	PUSH 80
	CALL MoveCamera
	PUSHSTR "HideArrow"
	INST_45
	PUSHSTR "TraceArrow"
	INST_45
	PUSH 110
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 2

}}

void function StoneEmitterCallback1 (arg_0, arg_1) callsign 7001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_B6C4
	INST_09 10
	JZ LOC_B664
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 10
	DIV
	POPN 1
LOC_B664:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_B6BC
	INST_09 10
	PUSH 2
	MUL
	SETARG 10
LOC_B6BC:
	JMP LOC_B6E4
LOC_B6C4:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_B6E4:
	RETN 2

}}

void function StoneEmitterCallback2 (arg_0, arg_1) callsign 7002 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_B7C8
	INST_09 10
	JZ LOC_B73C
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 10
	DIV
	POPN 1
LOC_B73C:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_B7C0
	INST_09 10
	PUSH 2
	MUL
	SETARG 10
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_B7C0:
	JMP LOC_B814
LOC_B7C8:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_B814:
	RETN 2

}}

void function StoneEmitterCmd3 () callsign 7005 {
__asm{
	STACK 5
	SYSCALL 0xB, (0 | (1 << 16)) ; 0x000B 
	POPN 3
	PUSHARG 3
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 4
	PUSHARG 3
	PUSH 17003
	PUSHARG 4
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG 3
	PUSH 0
	PUSH 0
	PUSH 117
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 30
	PUSH 30
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 5
	PUSHARG 5
	JZ LOC_B980
	PUSHARG 5
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 1
	PUSH 17022
	PUSHARG 4
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 5
	PUSHARG 5
	PUSH 30
	PUSH 30
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
LOC_B980:
	PUSH 2
	DELAY
	PUSHARG 3
	PUSH 17004
	PUSHARG 4
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG 3
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 2
	PUSH 30
	PUSH 0
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 2
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 2
	PUSH 1024
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSH 32
	DELAY
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 5
	JZ LOC_BA9C
	PUSHARG 5
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_BA9C:
	RETN 0

}}

void function StoneExplode (arg_0) {
__asm{
	STACK 2
	PUSHSTR "m007snd03"
	PUSH 200
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 2
	PUSHARG -2
	PUSH 2501
	PUSHARG 2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	INST_09 9
	PUSH 0
	CMP
	JZ LOC_BB74
	PUSHARG 1
	PUSH 7001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	JMP LOC_BB90
LOC_BB74:
	PUSHARG 1
	PUSH 7002
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_BB90:
	PUSHARG 1
	PUSH 2
	SYSCALL 0x1F, (2 | (0 << 16)) ; 0x001F 
	RETN 1

}}

void function FallExplode1 () callsign 7003 {
__asm{
	STACK 3
	SYSCALL 0xB, (0 | (1 << 16)) ; 0x000B 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x8, (1 | (0 << 16)) ; 0x0008 
	PUSHSTR "StoneExplode"
	PUSHARG 3
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 0
	POPN 2
LOC_BC20:
	PUSHARG 2
	PUSH 6
	CMPL
	JZ LOC_BD54
	PUSHARG 3
	PUSH 17007
	PUSH 17011
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	INST_09 9
	PUSH 0
	CMP
	JZ LOC_BCD8
	PUSHARG 1
	PUSH 7001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	JMP LOC_BCF4
LOC_BCD8:
	PUSHARG 1
	PUSH 7002
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_BCF4:
	PUSHARG 1
	PUSH 65536
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "Func7005"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	INCN 2
	JMP LOC_BC20
LOC_BD54:
	RETN 0

}}

void function Func7005 (arg_0) {
__asm{
	STACK 2
	PUSH 65536
	POPN 1
	PUSHARG -2
	PUSH 4
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 8
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG -2
	PUSH 24576
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHARG -2
	PUSH 8192
	SYSCALL 0x21, (2 | (0 << 16)) ; 0x0021 
	PUSH 20
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
LOC_BE1C:
	PUSHARG 2
	DECN 2
	PUSH 0
	CMPG
	JZ LOC_BECC
	PUSHARG -2
	PUSHARG 1
	PUSHARG 1
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 256
	SUB
	POPN 1
	PUSHARG 2
	PUSH 15
	CMP
	JZ LOC_BEB8
	PUSHARG -2
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
LOC_BEB8:
	PUSH 1
	DELAY
	JMP LOC_BE1C
LOC_BECC:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 1

}}

void function FireStoneExplode (arg_0) {
__asm{
	STACK 2
	INST_09 11
	PUSH 0
	CMP
	JZ LOC_BF38
	PUSHSTR "m007snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 1
	SETARG 11
LOC_BF38:
	PUSHARG -2
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 2
	PUSHARG -2
	PUSH 17012
	PUSHARG 2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 57344
	PUSH 57344
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 16777216
	PUSH 67108864
	ADD
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	INST_09 9
	PUSH 0
	CMP
	JZ LOC_C030
	PUSHARG 1
	PUSH 7001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	JMP LOC_C04C
LOC_C030:
	PUSHARG 1
	PUSH 7002
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_C04C:
	RETN 1

}}

void function FallExplode2 () callsign 7004 {
__asm{
	STACK 3
	SYSCALL 0xB, (0 | (1 << 16)) ; 0x000B 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x8, (1 | (0 << 16)) ; 0x0008 
	PUSHSTR "FireStoneExplode"
	PUSHARG 3
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 0
	POPN 2
LOC_C0C0:
	PUSHARG 2
	PUSH 10
	CMPL
	JZ LOC_C260
	PUSHARG 3
	PUSH 17016
	PUSH 17020
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 2
	PUSH 3
	MOD
	PUSH 0
	CMP
	JZ LOC_C200
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 16777216
	PUSH 67108864
	ADD
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	INST_09 9
	PUSH 0
	CMP
	JZ LOC_C1E4
	PUSHARG 1
	PUSH 7001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	JMP LOC_C200
LOC_C1E4:
	PUSHARG 1
	PUSH 7002
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_C200:
	PUSHARG 1
	PUSH 65536
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "Func7006"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	INCN 2
	JMP LOC_C0C0
LOC_C260:
	RETN 0

}}

void function Func7006 (arg_0) {
__asm{
	STACK 2
	PUSH 65536
	POPN 1
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG -2
	PUSH 8192
	SYSCALL 0x21, (2 | (0 << 16)) ; 0x0021 
	PUSH 30
	PUSH 40
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
LOC_C310:
	PUSHARG 2
	DECN 2
	PUSH 0
	CMPG
	JZ LOC_C388
	PUSHARG -2
	PUSHARG 1
	PUSHARG 1
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 256
	SUB
	POPN 1
	PUSH 1
	DELAY
	JMP LOC_C310
LOC_C388:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 1

}}

void function ProduceStoneEmitter (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSHARG -4
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_C410
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17023
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	JMP LOC_C444
LOC_C410:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17002
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
LOC_C444:
	PUSHARG 1
	PUSHARG -6
	PUSHARG -5
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 0
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_C5AC
	PUSHARG 1
	PUSH 17021
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSH 81920
	PUSH 81920
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 0
	PUSHARG 2
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_C580
	PUSHARG 2
	PUSH 63
	NEG
	PUSH 0
	PUSH 42
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	JMP LOC_C5AC
LOC_C580:
	PUSHARG 2
	PUSH 63
	PUSH 0
	PUSH 42
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_C5AC:
	RETN 5

}}

void function TraceStoneShadow (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
LOC_C5BC:
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_C6C8
	PUSHARG -4
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPLE
	JZ LOC_C618
	JMP LOC_C6C8
LOC_C618:
	PUSH 1
	DELAY
	PUSHARG -3
	PUSH 65536
	CMPL
	JZ LOC_C680
	PUSHARG -3
	PUSH 8192
	ADD
	POPN -3
	PUSHARG -5
	PUSHARG -3
	PUSHARG -3
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_C680:
	PUSHARG -2
	PUSH 16
	CMPL
	JZ LOC_C6C0
	INCN -2
	PUSHARG -5
	PUSHARG -2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
LOC_C6C0:
	JMP LOC_C5BC
LOC_C6C8:
	PUSHARG -5
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 4

}}

void function FlyStoneLB1 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSHARG -4
	DELAY
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_C750
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17005
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	JMP LOC_C784
LOC_C750:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17014
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
LOC_C784:
	PUSHARG 1
	PUSHARG -6
	PUSH 260
	ADD
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17004
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG -6
	PUSH 264
	ADD
	PUSHARG -5
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 2
	PUSH 23
	PUSH 0
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 2
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 2
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 4
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHSTR "TraceStoneShadow"
	PUSHARG 2
	PUSHARG 1
	PUSH 32768
	PUSH 4
	CALLBS
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_CA18
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17013
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSH 260
	ADD
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_CA18:
	RETN 5

}}

void function FlyStoneRB1 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSHARG -4
	DELAY
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_CA8C
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17006
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	JMP LOC_CAC0
LOC_CA8C:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17015
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
LOC_CAC0:
	PUSHARG 1
	PUSHARG -6
	PUSH 260
	SUB
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17004
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG -6
	PUSH 264
	SUB
	PUSHARG -5
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 2
	PUSH 23
	PUSH 0
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 2
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 2
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 4
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHSTR "TraceStoneShadow"
	PUSHARG 2
	PUSHARG 1
	PUSH 32768
	PUSH 4
	CALLBS
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_CD54
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17013
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSH 260
	SUB
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_CD54:
	RETN 5

}}

void function FlyStoneLB2 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 3
	PUSHARG -6
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -6
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN -5
	PUSHARG -4
	DELAY
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_CE00
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17005
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	JMP LOC_CE34
LOC_CE00:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17014
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
LOC_CE34:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17004
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_CF20
	PUSHARG 1
	PUSHARG 2
	PUSH 260
	ADD
	PUSH 24
	ADD
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 3
	PUSHARG 2
	PUSH 264
	ADD
	PUSH 24
	ADD
	PUSHARG -5
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	JMP LOC_CFF8
LOC_CF20:
	PUSHARG 1
	PUSHARG -6
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	PUSH 24
	ADD
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 3
	PUSHARG -6
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 3
	PUSH 264
	PUSH 24
	ADD
	PUSH 0
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
LOC_CFF8:
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 3
	PUSH 23
	PUSH 0
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 3
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 3
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 3
	PUSH 4
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHSTR "TraceStoneShadow"
	PUSHARG 3
	PUSHARG 1
	PUSH 32768
	PUSH 4
	CALLBS
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_D21C
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17013
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	PUSH 24
	ADD
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_D21C:
	RETN 5

}}

void function FlyStoneRB2 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 3
	PUSHARG -6
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -6
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN -5
	PUSHARG -4
	DELAY
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_D2C8
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17006
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	JMP LOC_D2FC
LOC_D2C8:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17015
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
LOC_D2FC:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17004
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_D3E8
	PUSHARG 1
	PUSHARG 2
	PUSH 260
	SUB
	PUSH 24
	SUB
	PUSHARG -5
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 3
	PUSHARG 2
	PUSH 264
	SUB
	PUSH 24
	SUB
	PUSHARG -5
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	JMP LOC_D4C8
LOC_D3E8:
	PUSHARG 1
	PUSHARG -6
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	NEG
	PUSH 24
	SUB
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 3
	PUSHARG -6
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 3
	PUSH 264
	NEG
	PUSH 24
	SUB
	PUSH 0
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
LOC_D4C8:
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 3
	PUSH 23
	PUSH 0
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 3
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 3
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 3
	PUSH 4
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHSTR "TraceStoneShadow"
	PUSHARG 3
	PUSHARG 1
	PUSH 32768
	PUSH 4
	CALLBS
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_D6F0
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 17013
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	NEG
	PUSH 24
	SUB
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_D6F0:
	RETN 5

}}

void function StoneEmitter (arg_0, arg_1, arg_2) {
__asm{
LOC_D6F8:
	STACK 13
	PUSHARG -3
	SETARG 9
	PUSH 1
	SETARG 10
	PUSH 0
	SETARG 11
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\007\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 30
	DELAY
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_D898
	PUSH 7001
	POPN 7
	JMP LOC_D8A8
LOC_D898:
	PUSH 7002
	POPN 7
LOC_D8A8:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_D8DC
	PUSH 0
	POPN 6
	JMP LOC_D8EC
LOC_D8DC:
	PUSH 128
	POPN 6
LOC_D8EC:
	PUSHARG -4
	PUSH 0
	CMP
	JZ LOC_D930
	PUSH 2
	POPN 8
	PUSH 4
	POPN 1
	JMP LOC_D950
LOC_D930:
	PUSH 1
	POPN 8
	PUSH 6
	POPN 1
LOC_D950:
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 13
	PUSHSTR "ProduceStoneEmitter"
	PUSH 6576
	PUSH 96
	PUSH 7
	MUL
	ADD
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMP
	MUL
	PUSH 240
	PUSH 96
	PUSH 7
	MUL
	SUB
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMPZ
	MUL
	ADD
	PUSH 180
	PUSHARG 1
	PUSH 72
	MUL
	PUSH 2
	MUL
	ADD
	PUSH 72
	PUSH 2
	MUL
	SUB
	PUSHARG 13
	PUSHARG 6
	PUSHARG -3
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHARG 1
	PUSHARG 8
	SUB
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_D950
	PUSHARG -4
	PUSH 2
	CMP
	JZ LOC_DC3C
	PUSH 1
	POPN 8
	PUSH 5
	POPN 1
LOC_DACC:
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 13
	PUSHSTR "ProduceStoneEmitter"
	PUSH 6576
	PUSH 96
	PUSH 7
	MUL
	ADD
	PUSH 96
	PUSH 2
	MUL
	ADD
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMP
	MUL
	PUSH 240
	PUSH 96
	PUSH 7
	MUL
	SUB
	PUSH 96
	PUSH 2
	MUL
	SUB
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMPZ
	MUL
	ADD
	PUSH 180
	PUSHARG 1
	PUSH 72
	MUL
	PUSH 2
	MUL
	ADD
	PUSH 72
	PUSH 1
	MUL
	SUB
	PUSHARG 13
	PUSHARG 6
	PUSHARG -3
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHARG 1
	PUSHARG 8
	SUB
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_DACC
LOC_DC3C:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_DCB0
	PUSHSTR "MoveCamera"
	PUSH 240
	PUSH 96
	PUSH 4
	MUL
	SUB
	PUSH 96
	SUB
	PUSH 0
	PUSH 40
	PUSH 0
	CALLBS
	JMP LOC_DD0C
LOC_DCB0:
	PUSHSTR "MoveCamera"
	PUSH 6576
	PUSH 96
	PUSH 4
	MUL
	ADD
	PUSH 1
	SUB
	PUSH 96
	ADD
	PUSH 0
	PUSH 40
	PUSH 0
	CALLBS
LOC_DD0C:
	PUSHSTR "MoveCamera"
	INST_45
	PUSH 92
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	POPN 9
	PUSH 0
	POPN 10
	PUSHARG 9
	PUSHARG -2
	CMPL
	JZ LOC_DD94
	PUSHARG -2
	PUSHARG 9
	SUB
	POPN 10
LOC_DD94:
	PUSHARG -2
	PUSHARG 10
	SUB
	PUSH 0
	CMPG
	JZ LOC_DFFC
	PUSH 0
	POPN 2
	PUSHARG -2
	PUSHARG 10
	SUB
	POPN 1
LOC_DDE8:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 3
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 2
	PUSH 0
	CMP
	JZ LOC_DE9C
	PUSH 1
	POPN 2
	PUSHARG 4
	POPN 11
	PUSHARG 4
	POPN 12
	JMP LOC_DEF4
LOC_DE9C:
	PUSHARG 11
	PUSHARG 4
	CMPL
	JZ LOC_DEC8
	PUSHARG 4
	POPN 11
LOC_DEC8:
	PUSHARG 12
	PUSHARG 4
	CMPG
	JZ LOC_DEF4
	PUSHARG 4
	POPN 12
LOC_DEF4:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_DF74
	PUSHSTR "FlyStoneRB2"
	PUSHARG 3
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -3
	PUSHARG 7
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_DFD0
LOC_DF74:
	PUSHSTR "FlyStoneLB2"
	PUSHARG 3
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -3
	PUSHARG 7
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_DFD0:
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_DDE8
	JMP LOC_E028
LOC_DFFC:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 11
	PUSHARG 11
	POPN 12
LOC_E028:
	PUSHARG 11
	PUSHARG 12
	CMP
	JZ LOC_E07C
	PUSHARG 11
	PUSH 512
	ADD
	POPN 11
	PUSHARG 12
	PUSH 512
	SUB
	POPN 12
LOC_E07C:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_E0D0
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_E0D0:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 11
	PUSHARG 10
	POPN 1
LOC_E0FC:
	PUSHARG 11
	PUSH 320
	NEG
	PUSH 320
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 4
	PUSH 150
	PUSH 650
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_E1D4
	PUSHSTR "FlyStoneRB1"
	PUSHARG 4
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -3
	PUSHARG 7
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_E230
LOC_E1D4:
	PUSHSTR "FlyStoneLB1"
	PUSHARG 4
	PUSHARG 5
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -3
	PUSHARG 7
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_E230:
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_E0FC
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_E2A8
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_E2A8:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSH 0
	PUSH 80
	CALL MoveCamera
	PUSHSTR "FallExplode1"
	INST_45
	PUSHSTR "Func7005"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 3

}}

void function ExplodeRoundCallback (arg_0, arg_1) callsign 8001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_E42C
	INST_09 12
	JZ LOC_E3A0
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 12
	DIV
	POPN 1
LOC_E3A0:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_E424
	INST_09 12
	PUSH 2
	MUL
	SETARG 12
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10016
	PUSH 60
	PUSH 0
	CALLBS
LOC_E424:
	JMP LOC_E478
LOC_E42C:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10016
	PUSH 60
	PUSH 0
	CALLBS
LOC_E478:
	RETN 2

}}

void function ProduceAirCircle (arg_0, arg_1, arg_2) {
__asm{
LOC_E480:
	STACK 2
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 8
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHARG 1
	PUSH 2
	SYSCALL 0x31, (2 | (0 << 16)) ; 0x0031 
	PUSH 1
	POPN 2
LOC_E538:
	PUSHARG 2
	PUSH 40
	CMPLE
	JZ LOC_E634
	PUSH 1
	DELAY
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_E590
	JMP LOC_E634
LOC_E590:
	PUSHARG 1
	PUSH 65536
	PUSH 12288
	PUSHARG 2
	MUL
	ADD
	PUSH 65536
	PUSH 12288
	PUSHARG 2
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 2
	PUSHARG -2
	CMP
	JZ LOC_E624
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_E624:
	INCN 2
	JMP LOC_E538
LOC_E634:
	RETN 3

}}

void function ProduceRound (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 3
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
	PUSHARG -5
	PUSHARG -4
	PUSHARG 2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 50331648
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSHARG -5
	PUSHARG 2
	PUSHARG -3
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHSTR "CreateExplodeRound"
	PUSHARG 1
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateExplodeRound"
	PUSHARG 1
	PUSH 2
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateExplodeRound"
	PUSHARG 1
	PUSH 4
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateExplodeRound"
	PUSHARG 1
	PUSH 5
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateExplodeRound"
	PUSHARG 1
	PUSH 7
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateExplodeRound"
	PUSHARG 1
	PUSH 9
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	RETN 4

}}

void function CreateExplodeRound (arg_0, arg_1) {
__asm{
	STACK 1
	PUSHARG -2
	DELAY
	PUSHARG -3
	PUSH 18004
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 65536
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 0
	PUSH 4
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 1
	PUSH 2176
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG 1
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function ExplodeRound (arg_0, arg_1, arg_2) {
__asm{
LOC_E9F4:
	STACK 4
	PUSH 1
	SETARG 12
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\008\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 10
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSH 10
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 18002
	PUSHARG -4
	PUSH 3
	MUL
	PUSH 18
	DIV
	CALL ProduceAirCircle
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 20
	DELAY
	PUSH 0
	POPN 1
LOC_EBCC:
	PUSHARG 1
	PUSHARG -4
	CMPL
	JZ LOC_EC90
	PUSHSTR "ProduceRound"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG -2
	PUSH 72
	PUSHARG -3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 8001
	CALLBS
	PUSH 1
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 1
	PUSH 0
	CMP
	JZ LOC_EC80
	PUSHSTR "m008snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
LOC_EC80:
	INCN 1
	JMP LOC_EBCC
LOC_EC90:
	PUSHSTR "ProduceRound"
	INST_45
	PUSHSTR "CreateExplodeRound"
	INST_45
	PUSH 30
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 3

}}

void function EightWayFireCallback (arg_0, arg_1) callsign 9001 {
__asm{
	STACK 1
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_EDE8
	INST_09 13
	JZ LOC_ED5C
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 13
	DIV
	POPN 1
LOC_ED5C:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_EDE0
	INST_09 13
	PUSH 2
	MUL
	SETARG 13
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_EDE0:
	JMP LOC_EE34
LOC_EDE8:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_EE34:
	RETN 2

}}

void function CreateEightWay (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 6
	PUSH 32768
	POPN 3
	PUSH 13
	POPN 4
	PUSH 20
	POPN 5
	PUSH 1
	POPN 6
	PUSHARG -6
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 9001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 2
LOC_EF00:
	PUSHARG 2
	PUSHARG -5
	PUSH 2
	MUL
	CMPL
	JZ LOC_F0C0
	PUSHARG 1
	PUSHARG 4
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHARG 1
	PUSH 98304
	PUSHARG 3
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -6
	PUSHARG -3
	PUSHARG 2
	PUSH 1
	ADD
	PUSHARG 5
	MUL
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 2
	DELAY
	PUSHARG 3
	PUSH 2048
	ADD
	POPN 3
	PUSHARG 4
	PUSHARG 6
	ADD
	POPN 4
	PUSHARG 4
	PUSH 16
	CMPGE
	JZ LOC_F030
	PUSH 3
	NEG
	POPN 6
	JMP LOC_F054
LOC_F030:
	PUSHARG 4
	PUSH 0
	CMPLE
	JZ LOC_F054
	JMP LOC_F0C0
LOC_F054:
	PUSHARG -2
	JZ LOC_F0B0
	PUSHARG -3
	PUSH 8
	ADD
	PUSH 255
	AND
	POPN -3
	PUSHARG -5
	PUSH 1
	AND
	JZ LOC_F0B0
	DECN 5
LOC_F0B0:
	INCN 2
	JMP LOC_EF00
LOC_F0C0:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 5

}}

void function EightWayFireMotion (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 1
	PUSH 0
	POPN 1
LOC_F0F4:
	PUSHARG 1
	PUSHARG -5
	PUSH 8
	SUB
	CMPL
	JZ LOC_F174
	PUSHSTR "CreateEightWay"
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 4
	DELAY
	INCN 1
	JMP LOC_F0F4
LOC_F174:
	RETN 5

}}

void function EightWayFire (arg_0, arg_1, arg_2) {
__asm{
LOC_F17C:
	STACK 5
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\009\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 1
	SETARG 13
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG -4
	PUSH 0
	CMP
	JZ LOC_F348
	PUSH 4
	POPN 1
	PUSH 4
	POPN 2
	PUSH 8
	POPN 5
	JMP LOC_F3CC
LOC_F348:
	PUSHARG -4
	PUSH 1
	CMP
	JZ LOC_F39C
	PUSH 6
	POPN 1
	PUSH 2
	POPN 2
	PUSH 10
	POPN 5
	JMP LOC_F3CC
LOC_F39C:
	PUSH 7
	POPN 1
	PUSH 1
	POPN 2
	PUSH 14
	POPN 5
LOC_F3CC:
	PUSHSTR "EightWayFireMotion"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 5
	PUSHARG -2
	PUSHARG 1
	PUSH 32
	MUL
	PUSHARG -3
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHARG 1
	PUSHARG 2
	SUB
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_F3CC
	PUSHSTR "m009snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "CreateEightWay"
	INST_45
	PUSH 30
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 3

}}

void function ConvexStoneCallback (arg_0, arg_1) callsign 10001 {
__asm{
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CALL Hurt
	RETN 2

}}

void function Func10002 (arg_0, arg_1) callsign 10002 {
__asm{
	STACK 2
	PUSH 0
	POPN 2
LOC_F4EC:
	PUSHARG 2
	PUSH 10
	CMPL
	JZ LOC_F668
	PUSHARG -3
	PUSH 20005
	PUSH 20010
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 65536
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG 1
	PUSH 10752
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 0
	PUSH 256
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 64
	PUSH 32
	SUB
	PUSH 64
	PUSH 32
	ADD
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 6
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 512
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	INCN 2
	JMP LOC_F4EC
LOC_F668:
	RETN 2

}}

void function Func10003 (arg_0, arg_1) callsign 10003 {
__asm{
	STACK 2
	PUSH 0
	POPN 2
LOC_F688:
	PUSHARG 2
	PUSH 10
	CMPL
	JZ LOC_F804
	PUSHARG -3
	PUSH 20005
	PUSH 20010
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 65536
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG 1
	PUSH 10752
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 0
	PUSH 256
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 64
	PUSH 32
	SUB
	PUSH 64
	PUSH 32
	ADD
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 7
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 32
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 512
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	INCN 2
	JMP LOC_F688
LOC_F804:
	RETN 2

}}

void function TraceStone (arg_0, arg_1) {
__asm{
	STACK 2
	PUSH 0
	POPN 1
LOC_F824:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_FB10
	PUSHARG -3
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 2
	PUSHARG 2
	PUSH 0
	CMPLE
	JZ LOC_FAFC
	PUSHARG 1
	JCOND 0, LOC_F8B0
	JCOND 1, LOC_F974
	JCOND 2, LOC_FA38
	POP
	JMP LOC_FAFC
LOC_F8B0:
	PUSHARG -3
	PUSH 65536
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -3
	PUSHARG -2
	PUSH 46
	PUSH 54
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 6
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 3
	DELAY
	PUSHARG -3
	PUSH 65536
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG -3
	PUSH 49152
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	INCN 1
	JMP LOC_FAFC
LOC_F974:
	PUSHARG -3
	PUSH 65536
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -3
	PUSHARG -2
	PUSH 42
	PUSH 50
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 4
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 2
	DELAY
	PUSHARG -3
	PUSH 65536
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG -3
	PUSH 32768
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	INCN 1
	JMP LOC_FAFC
LOC_FA38:
	PUSHARG -3
	PUSH 65536
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -3
	PUSHARG -2
	PUSH 40
	PUSH 44
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 1
	DELAY
	PUSHARG -3
	PUSH 65536
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG -3
	PUSH 16384
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	INCN 1
	JMP LOC_FAFC
LOC_FAFC:
	PUSH 1
	DELAY
	JMP LOC_F824
LOC_FB10:
	RETN 2

}}

void function BrokenStone (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5) {
__asm{
	STACK 2
	PUSHARG -7
	PUSHARG -6
	PUSHARG 2
	PUSHARG -4
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -5
	PUSH 0
	CMPG
	JZ LOC_FB88
	PUSH 0
	POPN 2
	JMP LOC_FBAC
LOC_FB88:
	PUSHARG -5
	NEG
	POPN -5
	PUSH 128
	POPN 2
LOC_FBAC:
	PUSHARG 1
	PUSHARG -7
	PUSHARG 2
	PUSHARG -5
	PUSHARG -4
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 43008
	PUSH 73728
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 61440
	PUSH 73728
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 512
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSH 2
	DELAY
	PUSHARG 1
	PUSHARG -2
	PUSH 52
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 6
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHSTR "TraceStone"
	PUSHARG 1
	PUSHARG -2
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG 1
	PUSH 48
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 6

}}

void function ProduceSomethingXY (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5) {
__asm{
	STACK 6
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -3
	JZ LOC_FD78
	PUSHARG -3
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	SYSCALL 0x1, (4 | (0 << 16)) ; 0x0001 
LOC_FD78:
	PUSHARG 1
	PUSHARG -7
	PUSHARG -6
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSH 0
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -2
	JZ LOC_104FC
	PUSH 12
	DELAY
	PUSHARG -5
	PUSH 20002
	CMP
	JZ LOC_101CC
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20011
	PUSH 7
	NEG
	PUSH 9
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 147
	PUSH 0
	PUSH 128
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20012
	PUSH 6
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 134
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20011
	PUSH 7
	NEG
	PUSH 9
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 120
	PUSH 0
	PUSH 128
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20012
	PUSH 6
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 107
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20014
	PUSH 11
	NEG
	PUSH 12
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 99
	PUSH 0
	PUSH 128
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20013
	PUSH 10
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 85
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20011
	PUSH 9
	NEG
	PUSH 10
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 70
	PUSH 0
	PUSH 128
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20014
	PUSH 11
	PUSH 13
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 67
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20012
	PUSH 10
	NEG
	PUSH 11
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 52
	PUSH 0
	PUSH 128
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20013
	PUSH 11
	PUSH 13
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 49
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	JMP LOC_104AC
LOC_101CC:
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20011
	PUSH 7
	NEG
	PUSH 9
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 120
	PUSH 0
	PUSH 128
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20012
	PUSH 6
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 107
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20014
	PUSH 8
	NEG
	PUSH 9
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 99
	PUSH 0
	PUSH 128
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20013
	PUSH 7
	PUSH 9
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 85
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20011
	PUSH 6
	NEG
	PUSH 7
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 70
	PUSH 0
	PUSH 128
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20014
	PUSH 8
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 67
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20012
	PUSH 6
	NEG
	PUSH 7
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 52
	PUSH 0
	PUSH 128
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "BrokenStone"
	PUSHARG 1
	PUSH 20013
	PUSH 7
	PUSH 9
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 49
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
LOC_104AC:
	PUSH 2
	DELAY
	PUSHARG 1
	PUSH 128
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHSTR "BrokenStone"
	INST_45
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	JMP LOC_1052C
LOC_104FC:
	PUSH 8
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_1052C:
	RETN 6

}}

void function ConvexStone (arg_0) {
__asm{
LOC_10534:
	STACK 14
	PUSH 10002
	POPN 9
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\010\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 6
	PUSHARG 5
	PUSHARG 6
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 30
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_106B4
	PUSH 0
	POPN 10
	JMP LOC_106C4
LOC_106B4:
	PUSH 128
	POPN 10
LOC_106C4:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 6
	PUSHARG 5
	PUSHARG 6
	PUSH 120
	SUB
	PUSH 40
	CALL MoveCamera
	PUSH 15
	DELAY
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 6
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_107A0
	PUSH 1
	POPN 1
	JMP LOC_107F4
LOC_107A0:
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_107D4
	PUSH 3
	POPN 1
	JMP LOC_107F4
LOC_107D4:
	PUSH 5
	POPN 1
	PUSH 10003
	POPN 9
LOC_107F4:
	PUSH 0
	POPN 7
	PUSH 0
	POPN 8
	PUSHARG 7
	POPN 11
	PUSHARG 8
	POPN 12
LOC_10834:
	PUSHSTR "ProduceSomethingXY"
	PUSHARG 5
	PUSHARG 7
	ADD
	PUSHARG 6
	PUSHARG 8
	ADD
	PUSH 20001
	PUSHARG -2
	PUSH 2
	CMP
	ADD
	PUSHARG 10
	PUSHARG 9
	PUSH 1
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "ProduceSomethingXY"
	PUSHARG 5
	PUSHARG 7
	ADD
	PUSHARG 6
	PUSHARG 8
	ADD
	PUSH 20003
	PUSHARG -2
	PUSH 2
	CMP
	ADD
	PUSHARG 10
	PUSHARG 9
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "LockTargetXY"
	PUSHARG 5
	PUSHARG 7
	ADD
	PUSHARG 6
	PUSHARG 8
	ADD
	PUSH 2501
	PUSHARG 10
	PUSH 8
	PUSH 10001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSH 1
	POPN 2
LOC_109AC:
	PUSHARG 2
	PUSH 6
	CMPL
	JZ LOC_10B38
	PUSHARG 6
	PUSHARG 8
	ADD
	PUSH 72
	PUSH 3
	MUL
	PUSH 2
	DIV
	SUB
	PUSHARG 2
	PUSH 72
	MUL
	PUSH 2
	DIV
	ADD
	POPN 14
	PUSH 1
	POPN 3
LOC_10A3C:
	PUSHARG 3
	PUSH 6
	CMPL
	JZ LOC_10B28
	PUSHARG 5
	PUSHARG 7
	ADD
	PUSH 96
	PUSH 3
	MUL
	PUSH 2
	DIV
	SUB
	PUSHARG 3
	PUSH 96
	MUL
	PUSH 2
	DIV
	ADD
	POPN 13
	PUSHSTR "LockTargetXY"
	PUSHARG 13
	PUSHARG 14
	PUSH 2501
	PUSHARG 10
	PUSH 8
	PUSH 10001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	INCN 3
	JMP LOC_10A3C
LOC_10B28:
	INCN 2
	JMP LOC_109AC
LOC_10B38:
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
LOC_10B58:
	PUSH 1
	JZ LOC_10BEC
	PUSH 240
	NEG
	PUSH 240
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 7
	PUSHARG 7
	PUSHARG 11
	PUSH 28
	ADD
	CMPG
	PUSHARG 7
	PUSHARG 11
	PUSH 28
	SUB
	CMPL
	ORZ
	JZ LOC_10BE4
	JMP LOC_10BEC
LOC_10BE4:
	JMP LOC_10B58
LOC_10BEC:
	PUSH 1
	JZ LOC_10C80
	PUSH 110
	NEG
	PUSH 340
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 8
	PUSHARG 8
	PUSHARG 12
	PUSH 36
	ADD
	CMPG
	PUSHARG 8
	PUSHARG 12
	PUSH 36
	SUB
	CMPL
	ORZ
	JZ LOC_10C78
	JMP LOC_10C80
LOC_10C78:
	JMP LOC_10BEC
LOC_10C80:
	PUSHARG 7
	POPN 11
	PUSHARG 8
	POPN 12
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_10834
	PUSHSTR "CreateEightWay"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function TornadorCallback (arg_0, arg_1) callsign 11001 {
__asm{
	STACK 4
	PUSHARG -2
	PUSH 65536
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -2
	PUSH 0
	PUSH 6
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 1
	PUSH 0
	PUSH 18
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 4
LOC_10DAC:
	PUSHARG -3
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHARG -2
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 2
	PUSHARG -2
	PUSHARG -3
	PUSHARG 1
	PUSHARG 4
	PUSHARG 2
	PUSHARG 3
	SUB
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG 1
	PUSH 16
	ADD
	PUSH 255
	AND
	POPN 1
	PUSHARG 2
	PUSH 240
	CMPG
	JZ LOC_10E7C
	JMP LOC_10EC0
LOC_10E7C:
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	ZERO
	JZ LOC_10EA4
	JMP LOC_10EC0
LOC_10EA4:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JNZ LOC_10DAC
LOC_10EC0:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function TornadoMotion (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6) {
__asm{
	STACK 2
	PUSHARG -4
	POPN 1
LOC_10EF4:
	PUSHARG -7
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_10FE0
	PUSHARG -2
	JZ LOC_10F4C
	PUSHARG 1
	PUSHARG -5
	SYSCALL 0x201, (2 | (1 << 16)) ; 0x0201 
	POPN 2
	JMP LOC_10F70
LOC_10F4C:
	PUSHARG 1
	PUSHARG -5
	SYSCALL 0x202, (2 | (1 << 16)) ; 0x0202 
	POPN 2
LOC_10F70:
	PUSHARG -7
	PUSHARG -8
	PUSH 0
	PUSHARG 2
	PUSHARG -6
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG 1
	PUSH 4
	ADD
	PUSH 255
	AND
	POPN 1
	JMP LOC_10EF4
LOC_10FE0:
	RETN 7

}}

void function TornadoStoneMotion (arg_0, arg_1) {
__asm{
	STACK 5
	PUSHARG -2
	PUSH 65536
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -2
	PUSH 0
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 1
	PUSH 40
	PUSH 80
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 4
LOC_1108C:
	PUSHARG -3
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHARG -2
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 2
	PUSHARG -2
	PUSHARG -3
	PUSHARG 1
	PUSHARG 4
	PUSHARG 2
	PUSHARG 3
	SUB
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG 1
	PUSH 4
	ADD
	PUSH 255
	AND
	POPN 1
	PUSHARG 2
	PUSH 240
	CMPG
	JZ LOC_1115C
	JMP LOC_111A0
LOC_1115C:
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	ZERO
	JZ LOC_11184
	JMP LOC_111A0
LOC_11184:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JNZ LOC_1108C
LOC_111A0:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function TornadoStone (arg_0) {
__asm{
	STACK 1
	PUSH 10
	PUSH 18
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -2
	PUSH 21003
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 524288
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG 1
	PUSH 16384
	PUSH 49152
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 16384
	PUSH 49152
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "TornadoStoneMotion"
	PUSHARG -2
	PUSHARG 1
	PUSH 0
	PUSH 0
	CALLBS
	RETN 1

}}

void function BottomSmoke (arg_0) {
__asm{
	STACK 1
	PUSHARG -2
	PUSH 7050
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -2
	PUSH 128
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 16
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 16384
	PUSH 18432
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 0
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 1
	PUSH 12
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 512
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	RETN 1

}}

void function BottomMotion (arg_0, arg_1) {
__asm{
	STACK 1
	PUSH 0
	POPN 1
LOC_1140C:
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_114CC
	PUSHARG -2
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 5
	MOD
	PUSH 0
	CMP
	JZ LOC_114B0
	PUSHSTR "TornadoStone"
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
LOC_114B0:
	PUSH 1
	DELAY
	INCN 1
	JMP LOC_1140C
LOC_114CC:
	RETN 2

}}

void function ProduceTornado (arg_0) {
__asm{
	STACK 15
	PUSH 0
	PUSH 2134
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	AND
	POPN 15
	PUSHARG -2
	PUSH 21002
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHSTR "BottomMotion"
	PUSHARG -2
	PUSHARG 1
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 0
	POPN 14
LOC_1157C:
	PUSHARG 14
	PUSH 12
	CMPL
	JZ LOC_116F0
	PUSHARG -2
	PUSH 21001
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	PUSHARG 14
	SETNR 2
	PUSHARG 14
	PUSHNR 2
	PUSH 16384
	PUSH 81920
	PUSH 12
	DIV
	PUSHARG 14
	MUL
	ADD
	PUSH 65536
	PUSH 98304
	PUSH 12
	DIV
	PUSHARG 14
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "TornadoMotion"
	PUSHARG -2
	PUSHARG 14
	PUSHNR 2
	PUSHARG 14
	PUSH 1
	ADD
	PUSH 16
	MUL
	PUSH 8
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 32
	PUSHARG 14
	PUSH 2
	DIV
	MUL
	PUSHARG 14
	PUSHARG 15
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
	INCN 14
	JMP LOC_1157C
LOC_116F0:
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_11720
	PUSH 2
	DELAY
	JMP LOC_116F0
LOC_11720:
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 0
	POPN 14
LOC_11754:
	PUSHARG 14
	PUSH 12
	CMPL
	JZ LOC_117B8
	PUSH 2
	DELAY
	PUSHARG 14
	PUSHNR 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	INCN 14
	JMP LOC_11754
LOC_117B8:
	RETN 1

}}

void function DummyMotion (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 4
	PUSH 3
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 1
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	POPN 4
	PUSHARG 4
	PUSH 0
	CMP
	JZ LOC_1184C
	PUSH 1
	NEG
	POPN 2
	JMP LOC_118C4
LOC_1184C:
	PUSHARG 4
	PUSH 3
	CMPL
	JZ LOC_1189C
	PUSH 2
	NEG
	PUSH 3
	NEG
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
	JMP LOC_118C4
LOC_1189C:
	PUSH 2
	NEG
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
LOC_118C4:
	PUSH 1
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
LOC_118E8:
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_119B8
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG -3
	PUSHARG 3
	ADD
	PUSH 255
	AND
	POPN -3
	PUSHARG -3
	PUSHARG 1
	MOD
	PUSH 0
	CMP
	JZ LOC_119B0
	PUSHARG -2
	PUSHARG 2
	ADD
	POPN -2
LOC_119B0:
	JMP LOC_118E8
LOC_119B8:
	PUSHARG -5
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 4

}}

void function CreateDummyRef (arg_0, arg_1, arg_2) {
__asm{
LOC_119D4:
	STACK 1
	PUSHARG -4
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 33554432
	PUSH 134217728
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 11001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	INST_01 3

}}

void function WaitTarget (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
LOC_11AA0:
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_11C00
	PUSHARG -4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG -4
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG -3
	PUSH 96
	PUSH 4
	DIV
	ADD
	CMPL
	PUSHARG 1
	PUSHARG -3
	PUSH 96
	PUSH 4
	DIV
	SUB
	CMPG
	ORNZ
	PUSHARG 2
	PUSHARG -2
	PUSH 72
	PUSH 4
	DIV
	ADD
	CMPL
	PUSHARG 2
	PUSHARG -2
	PUSH 72
	PUSH 4
	DIV
	SUB
	CMPG
	ORNZ
	ORNZ
	JZ LOC_11BC0
	JMP LOC_11C00
LOC_11BC0:
	PUSH 1
	DELAY
	INCN 3
	PUSHARG 3
	PUSH 60
	CMPG
	JZ LOC_11BF8
	JMP LOC_11C00
LOC_11BF8:
	JMP LOC_11AA0
LOC_11C00:
	RETN 3

}}

void function GetSpeed (arg_0, arg_1, arg_2, arg_3) {
__asm{
LOC_11C08:
	STACK 1
	PUSH 10
	INST_01 4
	PUSHARG -3
	PUSHARG -5
	SUB
	POPN -3
	PUSHARG -2
	PUSHARG -4
	SUB
	POPN -2
	PUSHARG -3
	PUSH 180
	CMPG
	PUSHARG -2
	PUSH 160
	CMPG
	ORZ
	JZ LOC_11CA4
	PUSH 15
	POPN 1
	JMP LOC_11D00
LOC_11CA4:
	PUSHARG -3
	PUSH 100
	CMPG
	PUSHARG -2
	PUSH 85
	CMPG
	ORZ
	JZ LOC_11CF0
	PUSH 10
	POPN 1
	JMP LOC_11D00
LOC_11CF0:
	PUSH 5
	POPN 1
LOC_11D00:
	PUSHARG 1
	INST_01 4

}}

void function GetDir (arg_0, arg_1, arg_2, arg_3) {
__asm{
LOC_11D10:
	STACK 2
	PUSHARG -3
	PUSHARG -5
	SUB
	POPN -3
	PUSHARG -2
	PUSHARG -4
	SUB
	POPN -2
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_11DB8
	PUSHARG -2
	PUSH 0
	CMPGE
	JZ LOC_11DA0
	PUSH 192
	INST_01 4
	JMP LOC_11DB0
LOC_11DA0:
	PUSH 64
	INST_01 4
LOC_11DB0:
	JMP LOC_11E18
LOC_11DB8:
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_11E18
	PUSHARG -3
	PUSH 0
	CMPGE
	JZ LOC_11E08
	PUSH 128
	INST_01 4
	JMP LOC_11E18
LOC_11E08:
	PUSH 0
	INST_01 4
LOC_11E18:
	PUSHARG -3
	PUSH 0
	CMPGE
	JZ LOC_11E50
	PUSHARG -3
	LTOF
	POPN 1
	JMP LOC_11E68
LOC_11E50:
	PUSHARG -3
	NEG
	LTOF
	POPN 1
LOC_11E68:
	PUSHARG -2
	PUSH 0
	CMPGE
	JZ LOC_11EA0
	PUSHARG -2
	LTOF
	POPN 2
	JMP LOC_11EB8
LOC_11EA0:
	PUSHARG -2
	NEG
	LTOF
	POPN 2
LOC_11EB8:
	PUSHARG 2
	PUSHARG 1
	DIVF
	POPN 2
	PUSHARG -3
	PUSH 0
	CMPG
	PUSHARG -2
	PUSH 0
	CMPG
	ORNZ
	JZ LOC_11F88
	PUSHARG 2
	PUSH 1058261487
	CMPLF
	JZ LOC_11F3C
	PUSH 128
	INST_01 4
	JMP LOC_11F80
LOC_11F3C:
	PUSHARG 2
	PUSH 1071493677
	CMPGEF
	JZ LOC_11F70
	PUSH 192
	INST_01 4
	JMP LOC_11F80
LOC_11F70:
	PUSH 160
	INST_01 4
LOC_11F80:
	JMP LOC_12168
LOC_11F88:
	PUSHARG -3
	PUSH 0
	CMPL
	PUSHARG -2
	PUSH 0
	CMPG
	ORNZ
	JZ LOC_1203C
	PUSHARG 2
	PUSH 1058261487
	CMPLF
	JZ LOC_11FF0
	PUSH 0
	INST_01 4
	JMP LOC_12034
LOC_11FF0:
	PUSHARG 2
	PUSH 1071493677
	CMPGEF
	JZ LOC_12024
	PUSH 192
	INST_01 4
	JMP LOC_12034
LOC_12024:
	PUSH 224
	INST_01 4
LOC_12034:
	JMP LOC_12168
LOC_1203C:
	PUSHARG -3
	PUSH 0
	CMPL
	PUSHARG -2
	PUSH 0
	CMPL
	ORNZ
	JZ LOC_120F0
	PUSHARG 2
	PUSH 1058261487
	CMPLF
	JZ LOC_120A4
	PUSH 0
	INST_01 4
	JMP LOC_120E8
LOC_120A4:
	PUSHARG 2
	PUSH 1071493677
	CMPGEF
	JZ LOC_120D8
	PUSH 64
	INST_01 4
	JMP LOC_120E8
LOC_120D8:
	PUSH 32
	INST_01 4
LOC_120E8:
	JMP LOC_12168
LOC_120F0:
	PUSHARG 2
	PUSH 1058261487
	CMPLF
	JZ LOC_12124
	PUSH 128
	INST_01 4
	JMP LOC_12168
LOC_12124:
	PUSHARG 2
	PUSH 1071493677
	CMPGEF
	JZ LOC_12158
	PUSH 0
	INST_01 4
	JMP LOC_12168
LOC_12158:
	PUSH 96
	INST_01 4
LOC_12168:
	PUSH 0
	INST_01 4

}}

void function Tornado (arg_0) {
__asm{
LOC_12178:
	STACK 16
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\011\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 4
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSH 2
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_122E8
	PUSH 0
	POPN 3
	JMP LOC_122F8
LOC_122E8:
	PUSH 128
	POPN 3
LOC_122F8:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMP
	JZ LOC_12390
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMP
	JZ LOC_12390
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 8
LOC_12390:
	PUSHARG 8
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 9
	PUSHARG 9
	PUSHARG -2
	PUSH 30
	MUL
	PUSH 160
	PUSH 200
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x1F, (2 | (0 << 16)) ; 0x001F 
	PUSHSTR "m011snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "LockCameraSimple"
	PUSHARG 9
	PUSH 320
	NEG
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 0
	POPN 7
LOC_12468:
	PUSHARG 7
	PUSHARG -2
	CMPLE
	JZ LOC_125B8
	PUSHARG 7
	PUSH 1
	ADD
	PUSH 85
	MUL
	PUSH 10
	NEG
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 11
	PUSHARG 7
	PUSH 83
	MUL
	PUSH 10
	NEG
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 13
	PUSHARG 9
	PUSHARG 13
	PUSHARG 11
	CALL CreateDummyRef
	PUSHARG 7
	SETNR 4
	PUSHSTR "ProduceTornado"
	PUSHARG 7
	PUSHNR 4
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "DummyMotion"
	PUSHARG 7
	PUSHNR 4
	PUSHARG 9
	PUSHARG 13
	PUSHARG 11
	CALLBS
	INCN 7
	JMP LOC_12468
LOC_125B8:
	PUSHARG 9
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_12984
	PUSHARG 8
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_12624
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 8
LOC_12624:
	PUSHARG 8
	JZ LOC_127E0
	PUSHARG 8
	SYSCALL 0x101, (1 | (1 << 16)) ; GetObjectXY 
	POPN 1
	PUSHARG 8
	SYSCALL 0x102, (1 | (1 << 16)) ; 0x0102 
	POPN 2
	PUSH 4
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 11
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 1
	PUSHARG 2
	PUSHARG 11
	PUSHARG 11
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 10
	PUSH 0
	POPN 12
	PUSHARG 10
	PUSH 1
	CMPG
	JZ LOC_12768
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 1
	PUSHARG 2
	PUSHARG 11
	PUSHARG 11
	PUSH 1
	PUSHARG 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 12
LOC_12768:
	PUSHARG 12
	PUSH 0
	CMP
	JZ LOC_127D8
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 12
	PUSHARG 12
	PUSH 0
	CMP
	JZ LOC_127D8
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 12
LOC_127D8:
	JMP LOC_12834
LOC_127E0:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 12
	PUSHARG 12
	PUSH 0
	CMP
	JZ LOC_12834
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 12
LOC_12834:
	PUSHARG 9
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 14
	PUSHARG 9
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 15
	PUSHARG 12
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 12
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 14
	PUSHARG 15
	PUSHARG 1
	PUSHARG 2
	CALL GetSpeed
	POPN 16
	PUSHARG 16
	PUSH 2
	MUL
	SETARG 14
	PUSHARG 14
	PUSHARG 15
	PUSHARG 1
	PUSHARG 2
	CALL GetDir
	SETARG 15
	PUSHARG 9
	PUSHARG 12
	PUSHARG 16
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	PUSHSTR "WaitTarget"
	PUSHARG 9
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	CALLBS
	PUSHSTR "WaitTarget"
	INST_45
	JMP LOC_125B8
LOC_12984:
	PUSHSTR "ProduceTornado"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function DuplicatorCallback (arg_0, arg_1) callsign 12001 {
__asm{
	STACK 1
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CALL Hurt
	PUSHARG -2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	OR
	JZ LOC_12B38
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSH 4
	DELAY
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSH 4
	DELAY
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSH 4
	DELAY
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSH 4
	DELAY
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	JMP LOC_12B64
LOC_12B38:
	PUSHSTR "Blood"
	PUSHARG -2
	PUSH 16
	PUSH 0
	PUSH 0
	CALLBS
LOC_12B64:
	RETN 2

}}

void function TraceDuplicator (arg_0, arg_1) {
__asm{
	STACK 4
	PUSH 0
	POPN 4
LOC_12B84:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_12D30
	PUSH 1
	DELAY
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_12BDC
	JMP LOC_12D30
LOC_12BDC:
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG -2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG 2
	PUSHARG 1
	SUB
	POPN 3
	PUSHARG 3
	PUSH 0
	CMPL
	JZ LOC_12C60
	PUSHARG 3
	NEG
	POPN 3
LOC_12C60:
	PUSHARG 3
	PUSH 360
	CMPL
	PUSHARG 4
	PUSH 2
	CMPL
	ORNZ
	JZ LOC_12CC8
	PUSHARG -3
	PUSH 4
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 2
	POPN 4
	JMP LOC_12D28
LOC_12CC8:
	PUSHARG 3
	PUSH 1080
	CMPL
	PUSHARG 4
	PUSH 1
	CMPL
	ORNZ
	JZ LOC_12D28
	PUSHARG -3
	PUSH 2
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 1
	POPN 4
LOC_12D28:
	JMP LOC_12B84
LOC_12D30:
	RETN 2

}}

void function MoveDuplicator (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSHARG -4
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 3
	PUSHARG -4
	PUSHARG -3
	PUSHARG 3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG -4
	PUSHARG 3
	PUSH 48
	PUSH 64
	ADD
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG -2
	POPN 1
LOC_12DE0:
	PUSHARG 2
	PUSHARG -4
	PUSHARG 3
	PUSH 48
	PUSH 64
	ADD
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	ZERO
	JZ LOC_12E54
	JMP LOC_12E78
LOC_12E54:
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_12DE0
LOC_12E78:
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 3

}}

void function ProduceDuplicator (arg_0, arg_1, arg_2, arg_3) {
__asm{
LOC_12E94:
	PUSHARG -5
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_12F0C
	PUSHSTR "DuplicatorShadow"
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	PUSH 8
	SUB
	PUSH 14
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 8
	DELAY
	JMP LOC_12E94
LOC_12F0C:
	RETN 4

}}

void function DuplicatorShadow (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_12F40
	RETN 5
LOC_12F40:
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -4
	PUSH 0
	CMP
	JZ LOC_12FC8
	PUSHARG 1
	PUSH 8
	NEG
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	JMP LOC_12FF4
LOC_12FC8:
	PUSHARG 1
	PUSH 8
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_12FF4:
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSHARG -3
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 2
	DELAY
	PUSHARG 1
	PUSH 20
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_13088:
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_130E8
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_130D4
	RETN 5
LOC_130D4:
	PUSH 1
	DELAY
	JMP LOC_13088
LOC_130E8:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 5

}}

void function Duplicator (arg_0) {
__asm{
LOC_13104:
	STACK 10
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\012\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSH 0
	POPN 10
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	CMP
	JZ LOC_131BC
	PUSH 0
	PUSH 90
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 10
LOC_131BC:
	PUSH 1
	PUSH 2
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMPZ
	MUL
	SUB
	POPN 9
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_13224
	PUSH 0
	POPN 8
	JMP LOC_13234
LOC_13224:
	PUSH 128
	POPN 8
LOC_13234:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 7
	PUSHARG 5
	PUSH 180
	PUSHARG 9
	MUL
	SUB
	PUSHARG 7
	PUSH 120
	SUB
	PUSHARG 10
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16384
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHSTR "att07"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 10
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 22002
	PUSHARG 8
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG 8
	PUSH 0
	PUSH 16
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 2
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 12001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHSTR "ProduceShadowTime"
	PUSHARG 2
	PUSH 9999
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "MoveDuplicator"
	PUSHARG 2
	PUSH 22001
	PUSH 9999
	PUSH 0
	CALLBS
	PUSHSTR "LockCamera"
	PUSHARG 2
	PUSH 180
	PUSH 120
	NEG
	PUSHARG 10
	ADD
	PUSHINV 5 ; INTV_IS_RIGHT
	CALLBS
	PUSH 16
	POPN 5
	PUSH 1
	POPN 4
	PUSH 0
	POPN 3
	PUSHSTR "TraceDuplicator"
	PUSHARG 2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 0
	PUSH 0
	CALLBS
LOC_134DC:
	PUSHARG 2
	PUSHARG 8
	PUSH 0
	PUSHARG 5
	PUSH 16
	DIV
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 5
	PUSH 24
	PUSH 16
	MUL
	CMPL
	JZ LOC_13574
	PUSHARG 5
	PUSHARG 4
	ADD
	POPN 5
	PUSHARG 4
	PUSH 1
	ADD
	POPN 4
LOC_13574:
	PUSHARG 3
	PUSH 1
	AND
	PUSH 0
	CMP
	JZ LOC_13608
	PUSHARG 5
	PUSH 255
	CMPL
	JZ LOC_135E4
	PUSHARG 2
	PUSHSTR "m012snd01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	JMP LOC_13608
LOC_135E4:
	PUSHARG 2
	PUSHSTR "m012snd01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
LOC_13608:
	INCN 3
	PUSH 1
	DELAY
	PUSHARG 2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	POPN 1
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 6
	PUSHARG 6
	PUSH 0
	CMPLE
	PUSHARG 6
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	CMPGE
	ORZ
	JZ LOC_136A0
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_136A0:
	PUSHARG 1
	JNZ LOC_134DC
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function StopAllSoldier (arg_0, arg_1) {
__asm{
	STACK 4
	PUSH 0
	POPN 1
LOC_13700:
	PUSHARG 1
	PUSH 71
	CMPL
	JZ LOC_13808
	PUSH 0
	POPN 2
LOC_1372C:
	PUSHARG 2
	PUSH 15
	CMPL
	JZ LOC_137F8
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
	PUSHARG 3
	PUSHARG 3
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	ORNZ
	JZ LOC_137E8
	PUSHARG 3
	SYSCALL 0x115, (1 | (1 << 16)) ; GetSoldierSide 
	POPN 4
	PUSHARG -3
	PUSHARG 4
	CMP
	JZ LOC_137E8
	PUSHARG 3
	PUSHARG -2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
LOC_137E8:
	INCN 2
	JMP LOC_1372C
LOC_137F8:
	INCN 1
	JMP LOC_13700
LOC_13808:
	RETN 2

}}

void function Func13001 (arg_0) {
__asm{
	STACK 1
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 256
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSH 2
	DELAY
	PUSHARG -2
	PUSH 65536
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -2
	PUSH 128
	PUSH 192
	PUSH 3
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 64
	DELAY
	PUSHARG -2
	PUSH 128
	PUSH 192
	PUSH 0
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 64
	DELAY
	PUSH 0
	POPN 1
LOC_138F4:
	PUSHARG 1
	PUSH 10
	CMPL
	JZ LOC_13968
	PUSHARG -2
	PUSH 0
	PUSH 65536
	PUSHARG 1
	PUSH 65536
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	INCN 1
	JMP LOC_138F4
LOC_13968:
	PUSHARG 1
	PUSH 30
	CMPL
	JZ LOC_13A08
	PUSHARG -2
	PUSH 0
	PUSH 65536
	PUSHARG 1
	PUSH 65536
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 30
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSH 1
	DELAY
	INCN 1
	JMP LOC_13968
LOC_13A08:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 1

}}

void function ProduceSomethingXY2 (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG -3
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHSTR "Func13001"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "Func13001"
	INST_45
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 4

}}

void function Frozen () {
__asm{
LOC_13AF0:
	STACK 7
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\013\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 30
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_13C60
	PUSH 0
	POPN 6
	JMP LOC_13C70
LOC_13C60:
	PUSH 128
	POPN 6
LOC_13C70:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	POPN 7
	PUSHARG 7
	PUSH 0
	CMPG
	JZ LOC_13E0C
	PUSHARG 7
	PUSH 2
	DIV
	PUSH 1
	ADD
	POPN 1
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 2
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
LOC_13D20:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 2
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_13DB4
	PUSHARG 5
	PUSHARG 3
	CMPG
	JZ LOC_13DAC
	PUSHARG 3
	POPN 5
LOC_13DAC:
	JMP LOC_13DE0
LOC_13DB4:
	PUSHARG 5
	PUSHARG 3
	CMPL
	JZ LOC_13DE0
	PUSHARG 3
	POPN 5
LOC_13DE0:
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_13D20
	JMP LOC_13EA0
LOC_13E0C:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_13E68
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 3
	PUSH 320
	SUB
	POPN 5
	JMP LOC_13EA0
LOC_13E68:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 3
	PUSH 320
	ADD
	POPN 5
LOC_13EA0:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_13EFC
	PUSHARG 5
	PUSH 320
	ADD
	POPN 5
	PUSHARG 5
	PUSH 0
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	JMP LOC_13F34
LOC_13EFC:
	PUSHARG 5
	PUSH 320
	SUB
	POPN 5
	PUSHARG 5
	PUSH 0
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
LOC_13F34:
	PUSH 15
	DELAY
	PUSHSTR "m013snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_141A0
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 240
	SUB
	PUSH 468
	PUSH 240
	ADD
	PUSH 23009
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 80
	SUB
	PUSH 468
	PUSH 240
	ADD
	PUSH 23010
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 80
	ADD
	PUSH 468
	PUSH 240
	ADD
	PUSH 23011
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 240
	ADD
	PUSH 468
	PUSH 240
	ADD
	PUSH 23012
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 240
	SUB
	PUSH 468
	PUSH 240
	SUB
	PUSH 23013
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 80
	SUB
	PUSH 468
	PUSH 240
	SUB
	PUSH 23014
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 80
	ADD
	PUSH 468
	PUSH 240
	SUB
	PUSH 23015
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 240
	ADD
	PUSH 468
	PUSH 240
	SUB
	PUSH 23016
	PUSHARG 6
	CALLBS
	JMP LOC_143C0
LOC_141A0:
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 240
	SUB
	PUSH 468
	PUSH 240
	ADD
	PUSH 23001
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 80
	SUB
	PUSH 468
	PUSH 240
	ADD
	PUSH 23002
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 80
	ADD
	PUSH 468
	PUSH 240
	ADD
	PUSH 23003
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 240
	ADD
	PUSH 468
	PUSH 240
	ADD
	PUSH 23004
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 240
	SUB
	PUSH 468
	PUSH 240
	SUB
	PUSH 23005
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 80
	SUB
	PUSH 468
	PUSH 240
	SUB
	PUSH 23006
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 80
	ADD
	PUSH 468
	PUSH 240
	SUB
	PUSH 23007
	PUSHARG 6
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	PUSHARG 5
	PUSH 240
	ADD
	PUSH 468
	PUSH 240
	SUB
	PUSH 23008
	PUSHARG 6
	CALLBS
LOC_143C0:
	PUSHSTR "StopAllSoldier"
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSH 25
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "ProduceSomethingXY2"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 0

}}

void function DemonDancingCallback (arg_0, arg_1) callsign 14001 {
__asm{
	PUSHARG -3
	PUSHARG -2
	INST_09 16
	CALL Hurt
	INST_09 16
	PUSH 20
	CMP
	JZ LOC_14488
	PUSH 0
	SETARG 16
LOC_14488:
	RETN 2

}}

void function CreateLastAttack (arg_0, arg_1) {
__asm{
LOC_14490:
	STACK 2
	PUSHARG -3
	PUSH 24005
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 2
LOC_14504:
	PUSHARG 2
	PUSH 20
	CMPLE
	JZ LOC_14588
	PUSHARG 1
	PUSHARG -3
	PUSHARG -2
	PUSH 48
	PUSHARG 2
	PUSH 4
	MUL
	ADD
	PUSH 64
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_14504
LOC_14588:
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function DemonDancing () {
__asm{
LOC_145B4:
	STACK 7
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\014\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_146F0
	PUSHARG 4
	PUSH 96
	DIV
	PUSH 1
	ADD
	PUSHARG 5
	PUSH 72
	DIV
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 2
	JMP LOC_14738
LOC_146F0:
	PUSHARG 4
	PUSH 96
	DIV
	PUSH 1
	SUB
	PUSHARG 5
	PUSH 72
	DIV
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 2
LOC_14738:
	PUSHARG 2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_1476C
	PUSH 1
	POPN 6
	JMP LOC_1477C
LOC_1476C:
	PUSH 0
	POPN 6
LOC_1477C:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_147B0
	PUSH 0
	POPN 7
	JMP LOC_147C0
LOC_147B0:
	PUSH 128
	POPN 7
LOC_147C0:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMP
	JZ LOC_1488C
	PUSHARG 4
	PUSH 96
	DIV
	PUSH 1
	SUB
	PUSHARG 5
	PUSH 72
	DIV
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 2
	JMP LOC_148D4
LOC_1488C:
	PUSHARG 4
	PUSH 96
	DIV
	PUSH 1
	ADD
	PUSHARG 5
	PUSH 72
	DIV
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 2
LOC_148D4:
	PUSHARG 2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_14E08
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 4
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 4
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 8192
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 10
	DELAY
	PUSHSTR "att07"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHSTR "yell01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 24001
	PUSHARG 7
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 7
	PUSH 58
	PUSH 30
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 20
	DELAY
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 20
	POPN 1
LOC_14A54:
	PUSH 2
	SETARG 16
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_14AFC
	PUSHSTR "LockTargetXY"
	PUSHARG 4
	PUSH 96
	ADD
	PUSHARG 5
	PUSH 2501
	PUSHARG 7
	PUSH 2
	PUSH 14001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	JMP LOC_14B70
LOC_14AFC:
	PUSHSTR "LockTargetXY"
	PUSHARG 4
	PUSH 96
	SUB
	PUSHARG 5
	PUSH 2501
	PUSHARG 7
	PUSH 2
	PUSH 14001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
LOC_14B70:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 24002
	PUSH 24004
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG 7
	PUSH 64
	PUSH 48
	PUSH 64
	ADD
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSHARG 3
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 3
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHSTR "SmallFireBall"
	PUSHARG 3
	PUSHARG 3
	PUSH 10
	PUSH 0
	CALLBS
	PUSH 5
	DELAY
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_14A54
	PUSH 10
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHSTR "att07"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 7
	CALL CreateLastAttack
	PUSH 20
	SETARG 16
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_14D8C
	PUSHSTR "LockTargetXY"
	PUSHARG 4
	PUSH 96
	ADD
	PUSHARG 5
	PUSH 2501
	PUSHARG 7
	PUSH 2
	PUSH 14001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	JMP LOC_14E00
LOC_14D8C:
	PUSHSTR "LockTargetXY"
	PUSHARG 4
	PUSH 96
	SUB
	PUSHARG 5
	PUSH 2501
	PUSHARG 7
	PUSH 2
	PUSH 14001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
LOC_14E00:
	JMP LOC_1505C
LOC_14E08:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 16384
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 10
	DELAY
	PUSHSTR "att07"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHSTR "yell01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 24001
	PUSHARG 7
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 7
	PUSH 58
	PUSH 30
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 20
	DELAY
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 2
	SETARG 16
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_14FE8
	PUSHSTR "LockTargetXY"
	PUSHARG 4
	PUSH 96
	ADD
	PUSHARG 5
	PUSH 2501
	PUSHARG 7
	PUSH 2
	PUSH 14001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	JMP LOC_1505C
LOC_14FE8:
	PUSHSTR "LockTargetXY"
	PUSHARG 4
	PUSH 96
	SUB
	PUSHARG 5
	PUSH 2501
	PUSHARG 7
	PUSH 2
	PUSH 14001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
LOC_1505C:
	PUSH 90
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 0

}}

void function FlyingSwordCallback (arg_0, arg_1) callsign 15001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_15144
	INST_09 17
	JZ LOC_150E4
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 17
	DIV
	POPN 1
LOC_150E4:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_1513C
	INST_09 17
	PUSH 2
	MUL
	SETARG 17
LOC_1513C:
	JMP LOC_15164
LOC_15144:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_15164:
	RETN 2

}}

void function Func15010 (arg_0, arg_1) {
__asm{
	STACK 2
	PUSH 0
	POPN 2
LOC_15184:
	PUSHARG 2
	PUSH 15
	CMPL
	JZ LOC_152EC
	PUSHARG -2
	PUSH 25001
	PUSH 25002
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 10752
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHARG 1
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 0
	PUSH 256
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 16
	PUSH 128
	PUSH 16
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 4
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 64
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 512
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	INCN 2
	JMP LOC_15184
LOC_152EC:
	RETN 2

}}

void function Func15009 (arg_0, arg_1, arg_2) {
__asm{
	STACK 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHSTR "LockTargetTime2"
	PUSHARG 1
	PUSH 25008
	PUSH 8
	PUSH 0
	CALLBS
	PUSHSTR "Func15010"
	PUSHARG 1
	PUSHARG 1
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 8
	DELAY
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 3

}}

void function TraceSmallSword (arg_0) {
__asm{
	STACK 4
LOC_153E4:
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_15604
	PUSHARG -2
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	PUSH 4
	CMPLE
	JZ LOC_155F0
	PUSHARG -2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG -2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSH 0
	POPN 3
LOC_15484:
	PUSHARG 3
	PUSH 10
	CMPL
	JZ LOC_155E8
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 25001
	PUSH 25002
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 4
	PUSHARG 4
	PUSH 10752
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHARG 4
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 4
	PUSH 0
	PUSH 256
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 16
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 4
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 4
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 4
	PUSH 512
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	INCN 3
	JMP LOC_15484
LOC_155E8:
	JMP LOC_15604
LOC_155F0:
	PUSH 1
	DELAY
	JMP LOC_153E4
LOC_15604:
	RETN 1

}}

void function CreateSmallSwords (arg_0, arg_1, arg_2) {
__asm{
	STACK 9
	PUSH 0
	POPN 6
	PUSHARG -4
	SYSCALL 0x101, (1 | (1 << 16)) ; GetObjectXY 
	POPN 4
	PUSHARG -4
	SYSCALL 0x102, (1 | (1 << 16)) ; 0x0102 
	POPN 5
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 4
	PUSHARG 5
	PUSH 5
	PUSH 4
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 7
	PUSH 0
	POPN 2
LOC_156B4:
	PUSHARG 2
	PUSHARG 7
	CMPL
	JZ LOC_15894
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 4
	PUSHARG 5
	PUSH 5
	PUSH 4
	PUSH 0
	PUSHARG 7
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 8
	PUSHARG 8
	JZ LOC_15884
	PUSH 0
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 8
	PUSH 25005
	PUSHARG -2
	PUSH 280
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 0
	PUSH 192
	PUSH 60
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 15001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSHSTR "att04"
	PUSH 128
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHSTR "TraceSmallSword"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	INCN 6
	PUSHARG 6
	PUSH 16
	CMPGE
	JZ LOC_15884
	JMP LOC_15894
LOC_15884:
	INCN 2
	JMP LOC_156B4
LOC_15894:
	PUSHARG 6
	POPN 2
LOC_158A4:
	PUSHARG 2
	PUSH 24
	CMPL
	JZ LOC_159FC
	PUSH 2
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -4
	PUSH 25005
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 64
	PUSH 130
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 280
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 0
	PUSH 192
	PUSH 16
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSHSTR "att04"
	PUSH 128
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHSTR "TraceSmallSword"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	INCN 2
	JMP LOC_158A4
LOC_159FC:
	RETN 3

}}

void function SwordBomb (arg_0, arg_1, arg_2) {
__asm{
	STACK 6
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 96
	ADD
	PUSHARG -3
	PUSH 2501
	PUSHARG -2
	PUSH 8
	PUSH 15001
	PUSH 0
	PUSH 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 96
	SUB
	PUSHARG -3
	PUSH 2501
	PUSHARG -2
	PUSH 8
	PUSH 15001
	PUSH 0
	PUSH 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSHARG -3
	PUSH 72
	ADD
	PUSH 2501
	PUSHARG -2
	PUSH 8
	PUSH 15001
	PUSH 0
	PUSH 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSHARG -3
	PUSH 72
	SUB
	PUSH 2501
	PUSHARG -2
	PUSH 8
	PUSH 15001
	PUSH 0
	PUSH 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 96
	ADD
	PUSHARG -3
	PUSH 72
	ADD
	PUSH 2501
	PUSHARG -2
	PUSH 8
	PUSH 15001
	PUSH 0
	PUSH 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 96
	ADD
	PUSHARG -3
	PUSH 72
	SUB
	PUSH 2501
	PUSHARG -2
	PUSH 8
	PUSH 15001
	PUSH 0
	PUSH 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 96
	SUB
	PUSHARG -3
	PUSH 72
	ADD
	PUSH 2501
	PUSHARG -2
	PUSH 8
	PUSH 15001
	PUSH 0
	PUSH 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 96
	SUB
	PUSHARG -3
	PUSH 72
	SUB
	PUSH 2501
	PUSHARG -2
	PUSH 8
	PUSH 15001
	PUSH 0
	PUSH 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "m015snd02"
	PUSH 128
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "Func15009"
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 10
	DELAY
	PUSHSTR "m015snd02"
	PUSH 128
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "Func15009"
	PUSHARG -4
	PUSHARG -3
	PUSH 16
	PUSH 0
	CALLBS
	PUSH 8
	DELAY
	PUSHSTR "m015snd02"
	PUSH 128
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "Func15009"
	PUSHARG -4
	PUSHARG -3
	PUSH 32
	PUSH 0
	CALLBS
	PUSH 6
	DELAY
	PUSHSTR "m015snd02"
	PUSH 128
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "Func15009"
	PUSHARG -4
	PUSHARG -3
	PUSH 48
	PUSH 0
	CALLBS
	PUSH 6
	DELAY
	PUSHSTR "m015snd02"
	PUSH 128
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "Func15009"
	PUSHARG -4
	PUSHARG -3
	PUSH 64
	PUSH 0
	CALLBS
	PUSH 6
	DELAY
	PUSHSTR "m015snd02"
	PUSH 128
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "Func15009"
	PUSHARG -4
	PUSHARG -3
	PUSH 80
	PUSH 0
	CALLBS
	PUSH 0
	POPN 5
	PUSH 0
	POPN 1
LOC_15FE8:
	PUSHARG 1
	PUSH 16
	CMPL
	JZ LOC_1626C
	PUSH 0
	POPN 2
LOC_16014:
	PUSHARG 2
	PUSH 1
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	CMPL
	JZ LOC_16108
	PUSHARG -4
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 3
	PUSHARG -3
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSHARG 5
	PUSH 0
	PUSH 25007
	PUSH 25008
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
	INCN 2
	JMP LOC_16014
LOC_16108:
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CMP
	JZ LOC_16250
	PUSHARG -4
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 3
	PUSHARG -3
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSHARG 5
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 25009
	PUSH 25010
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 6
	PUSHARG 6
	PUSH 10
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 10
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
LOC_16250:
	PUSH 1
	DELAY
	INCN 1
	JMP LOC_15FE8
LOC_1626C:
	RETN 3

}}

void function CreateBigSword (arg_0, arg_1) {
__asm{
	STACK 4
	PUSHARG -3
	PUSH 25006
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSHARG 3
	PUSH 0
	PUSH 0
	PUSH 300
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 3
	PUSH 65536
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 3
	PUSH 0
	PUSH 192
	PUSH 40
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 3
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 3
	PUSH 15001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSH 1
	POPN 4
LOC_16380:
	PUSHARG 4
	PUSH 10
	CMPL
	JZ LOC_1640C
	PUSHARG 3
	PUSH 98304
	PUSHARG 4
	PUSH 8192
	MUL
	ADD
	PUSH 106496
	PUSHARG 4
	PUSH 8192
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	INCN 4
	JMP LOC_16380
LOC_1640C:
	PUSH 10
	DELAY
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHSTR "SwordBomb"
	PUSHARG 1
	PUSHARG 2
	PUSHARG -2
	PUSH 0
	CALLBS
	PUSHARG 3
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function SwordAttack (arg_0, arg_1) {
__asm{
	STACK 5
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	POPN 5
	PUSH 0
	POPN 2
	PUSHARG 5
	PUSH 0
	CMPG
	JZ LOC_16588
	PUSHARG -2
	JZ LOC_1653C
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 2
LOC_1653C:
	PUSHARG 2
	PUSH 0
	CMP
	JZ LOC_16580
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 2
LOC_16580:
	JMP LOC_16598
LOC_16588:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 2
LOC_16598:
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 240
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHSTR "CreateBigSword"
	PUSHARG 2
	PUSHARG -3
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 10
	DELAY
	PUSHSTR "CreateSmallSwords"
	PUSHARG 2
	PUSH 0
	PUSH 63
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -3
	PUSH 0
	CALLBS
	PUSH 90
	DELAY
	RETN 2

}}

void function ProduceSwordShadow (arg_0, arg_1, arg_2) {
__asm{
LOC_16688:
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_166E0
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	SYSCALL 0x23, (3 | (1 << 16)) ; CreateObject_Shadow 
	POP
	PUSH 3
	DELAY
	JMP LOC_16688
LOC_166E0:
	RETN 3

}}

void function LargerSword (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 5
	PUSH 256
	POPN 3
	PUSH 256
	POPN 4
	PUSH 0
	POPN 1
LOC_16720:
	PUSHARG 1
	PUSH 32
	CMPL
	JZ LOC_167EC
	PUSHARG -5
	PUSHARG 3
	PUSHARG 4
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	PUSHARG 3
	PUSHARG -4
	CMPL
	JZ LOC_167A4
	PUSHARG 3
	PUSH 2048
	ADD
	POPN 3
LOC_167A4:
	PUSHARG 4
	PUSHARG -3
	CMPL
	JZ LOC_167DC
	PUSHARG 4
	PUSH 2048
	ADD
	POPN 4
LOC_167DC:
	INCN 1
	JMP LOC_16720
LOC_167EC:
	PUSH 30
	DELAY
	PUSHARG -5
	PUSH 25004
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 5
	PUSHARG -5
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 5
	PUSH 0
	PUSH 64
	PUSH 1
	NEG
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 25
	DELAY
	PUSHARG 5
	PUSH 0
	PUSH 64
	PUSH 16
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHSTR "ProduceSwordShadow"
	PUSHARG 5
	PUSH 16
	PUSH 1
	PUSH 0
	CALLBS
	PUSHARG 5
	PUSH 60
	SYSCALL 0x1F, (2 | (0 << 16)) ; 0x001F 
	RETN 4

}}

void function PrepareSword (arg_0, arg_1, arg_2) {
__asm{
	STACK 1
	PUSHARG -4
	PUSH 25003
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSH 128
	PUSH 64
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 0
	PUSH 64
	PUSH 1
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 256
	PUSH 256
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "LargerSword"
	PUSHARG 1
	PUSH 65536
	PUSH 65536
	PUSHARG -2
	CALLBS
	RETN 3

}}

void function FlyingSword (arg_0) {
__asm{
LOC_169EC:
	STACK 9
	PUSH 1
	SETARG 17
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\015\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_16B60
	PUSH 0
	POPN 7
	JMP LOC_16B70
LOC_16B60:
	PUSH 128
	POPN 7
LOC_16B70:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POP
	PUSH 15
	DELAY
	PUSHARG -2
	JCOND 0, LOC_16BE8
	JCOND 1, LOC_16C1C
	JCOND 2, LOC_16C50
	POP
	JMP LOC_16C84
LOC_16BE8:
	PUSH 4
	POPN 8
	PUSHSTR "m015snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_16C84
LOC_16C1C:
	PUSH 8
	POPN 8
	PUSHSTR "m015snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_16C84
LOC_16C50:
	PUSH 16
	POPN 8
	PUSHSTR "m015snd03"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_16C84
LOC_16C84:
	PUSH 256
	PUSHARG 8
	DIV
	POPN 6
	PUSH 0
	PUSH 63
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 9
	PUSH 0
	POPN 1
LOC_16CD4:
	PUSHARG 1
	PUSHARG 8
	CMPL
	JZ LOC_16D50
	PUSHSTR "PrepareSword"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 9
	PUSHARG 1
	PUSHARG 6
	MUL
	ADD
	PUSHARG 7
	PUSH 0
	CALLBS
	PUSH 1
	DELAY
	INCN 1
	JMP LOC_16CD4
LOC_16D50:
	PUSH 135
	DELAY
	PUSH 0
	POPN 1
LOC_16D6C:
	PUSHARG 1
	PUSHARG -2
	CMPLE
	JZ LOC_16DE8
	PUSHSTR "SwordAttack"
	PUSHARG 7
	PUSH 2
	PUSHARG 1
	SUB
	PUSH 2
	DIV
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 100
	DELAY
	INCN 1
	JMP LOC_16D6C
LOC_16DE8:
	PUSHSTR "SwordBomb"
	INST_45
	PUSHSTR "TraceSmallSword"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function CreateHolyBall (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSH 1
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -4
	PUSHARG -2
	PUSH 0
	PUSHARG -3
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSH 49152
	PUSH 81920
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSHARG 2
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 8
	PUSH 38
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -3
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHARG 1
	PUSH 0
	PUSH 1
	PUSH 7
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSH 1
	POPN 3
LOC_16FB8:
	PUSHARG 3
	PUSH 8
	CMPLE
	JZ LOC_1700C
	PUSH 1
	DELAY
	PUSHARG 1
	PUSHARG 3
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	INCN 3
	JMP LOC_16FB8
LOC_1700C:
	PUSH 16
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
	PUSHARG 1
	PUSH 256
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG 1
	PUSHARG 3
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 3
	DELAY
	RETN 3

}}

void function RoundHolyBall (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
	PUSHARG -5
	PUSHARG -2
	PUSH 0
	PUSHARG -4
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 81920
	PUSH 81920
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -5
	PUSH 192
	PUSH 16
	PUSHARG -4
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSHARG -3
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSH 2
	DELAY
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 4

}}

void function IncreaseHP () {
__asm{
	STACK 2
	PUSHINV 5 ; INTV_IS_RIGHT
	SYSCALL 0x117, (1 | (1 << 16)) ; GetMajorHP 
	POPN 1
	PUSH 1
	POPN 2
LOC_171B0:
	PUSHARG 2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CMPLE
	JZ LOC_17210
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSHARG 1
	PUSHARG 2
	ADD
	SYSCALL 0x118, (2 | (0 << 16)) ; SetMajorHP? 
	PUSH 2
	DELAY
	INCN 2
	JMP LOC_171B0
LOC_17210:
	RETN 0

}}

void function CreateHolyLight (arg_0, arg_1) {
__asm{
LOC_17218:
	STACK 6
	PUSHARG -2
	JCOND 0, LOC_17258
	JCOND 1, LOC_17280
	JCOND 2, LOC_172A8
	POP
	JMP LOC_172D0
LOC_17258:
	PUSH 26001
	POPN 4
	PUSH 26004
	POPN 6
	JMP LOC_172D0
LOC_17280:
	PUSH 26002
	POPN 4
	PUSH 26005
	POPN 6
	JMP LOC_172D0
LOC_172A8:
	PUSH 26003
	POPN 4
	PUSH 26006
	POPN 6
	JMP LOC_172D0
LOC_172D0:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_17304
	PUSH 0
	POPN 5
	JMP LOC_17318
LOC_17304:
	PUSH 6
	NEG
	POPN 5
LOC_17318:
	PUSHARG -3
	PUSHARG 4
	PUSH 0
	PUSH 220
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 2048
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -3
	PUSH 192
	PUSH 16
	PUSH 240
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSHARG 5
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 98304
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSH 0
	POPN 2
LOC_173FC:
	PUSHARG 2
	PUSH 30
	CMPL
	JZ LOC_17478
	PUSHSTR "RoundHolyBall"
	PUSHARG -3
	PUSH 240
	PUSHARG 2
	PUSH 8
	MUL
	SUB
	PUSHARG 5
	PUSHARG 6
	CALLBS
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_173FC
LOC_17478:
	PUSH 40
	DELAY
	PUSHSTR "TraceHolyLight"
	PUSHARG 1
	PUSH 2048
	PUSH 69632
	PUSH 32
	CALLBS
	PUSHSTR "IncreaseHP"
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 0
	POPN 3
LOC_174EC:
	PUSHARG 3
	PUSH 8
	CMPL
	JZ LOC_175CC
	PUSH 0
	POPN 2
LOC_17518:
	PUSHARG 2
	PUSH 10
	CMPL
	JZ LOC_1759C
	PUSHSTR "CreateHolyBall"
	PUSHARG -3
	PUSH 5
	PUSH 40
	PUSHARG 3
	PUSH 2
	MUL
	ADD
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG 6
	PUSH 0
	CALLBS
	INCN 2
	JMP LOC_17518
LOC_1759C:
	PUSH 8
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 3
	JMP LOC_174EC
LOC_175CC:
	PUSHSTR "TraceHolyLight"
	INST_45
	RETN 2

}}

void function TraceHolyLight (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 3
	PUSHARG -3
	PUSHARG -4
	SUB
	POPN 3
	PUSH 1
	POPN 1
LOC_17614:
	PUSHARG 1
	PUSHARG -2
	CMPLE
	JZ LOC_176A4
	PUSHARG -4
	PUSHARG 3
	PUSHARG -2
	DIV
	PUSHARG 1
	MUL
	ADD
	POPN 2
	PUSHARG -5
	PUSHARG 2
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	INCN 1
	JMP LOC_17614
LOC_176A4:
	PUSH 60
	DELAY
	PUSHARG -5
	PUSH 1024
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG -5
	PUSH 48
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 48
	DELAY
	RETN 4

}}

void function Heal (arg_0) {
__asm{
LOC_17704:
	STACK 3
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\016\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 5
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 10
	DELAY
	PUSHSTR "m016snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG -2
	CALL CreateHolyLight
	PUSH 10
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function FireDragonCallback (arg_0, arg_1) callsign 17001 {
__asm{
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_17938
	PUSHARG -3
	PUSHARG -2
	INST_09 18
	CALL Hurt
	PUSH 2
	SETARG 18
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
	JMP LOC_17984
LOC_17938:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_17984:
	RETN 2

}}

void function CreateStart (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -3
	PUSH 27010
	PUSHARG -2
	PUSH 64
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 131072
	PUSH 114688
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 2
LOC_17A18:
	PUSHARG 2
	PUSH 16
	CMPL
	JZ LOC_17A6C
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_17A18
LOC_17A6C:
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSH 64
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function sc4501 (arg_0, arg_1) {
__asm{
	STACK 8
	PUSH 0
	POPN 4
	PUSH 0
	POPN 5
	PUSHSTR "CreateStart"
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 32
	DELAY
	PUSHARG -3
	PUSH 27002
	PUSHARG -2
	PUSH 64
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 17001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSH 60
	PUSH 6
	MUL
	POPN 1
	PUSH 128
	POPN 4
	PUSH 0
	POPN 5
	PUSHSTR "m017snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
LOC_17BF0:
	PUSHARG 2
	PUSHARG 4
	PUSH 0
	PUSH 7
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 6
	PUSHARG 2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 7
	PUSHARG 5
	PUSH 32
	SYSCALL 0x201, (2 | (1 << 16)) ; 0x0201 
	POPN 8
	PUSHARG 2
	PUSHARG 6
	PUSHARG 7
	PUSH 64
	PUSHARG 8
	ADD
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 2
	PUSH 65536
	PUSH 1
	PUSH 2
	PUSHARG 4
	PUSH 64
	SUB
	PUSH 255
	AND
	PUSH 128
	CMPG
	MUL
	SUB
	MUL
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 5
	PUSH 255
	AND
	PUSH 128
	SUB
	POPN 3
	PUSHARG 3
	PUSH 0
	CMPL
	JZ LOC_17D7C
	PUSH 0
	PUSHARG 3
	SUB
	POPN 3
LOC_17D7C:
	PUSHARG 3
	PUSH 16
	CMPL
	JZ LOC_17DBC
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017a40001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_17F18
LOC_17DBC:
	PUSHARG 3
	PUSH 32
	CMPL
	JZ LOC_17DFC
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017a20001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_17F18
LOC_17DFC:
	PUSHARG 3
	PUSH 48
	CMPL
	JZ LOC_17E3C
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017a20001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_17F18
LOC_17E3C:
	PUSHARG 3
	PUSH 80
	CMPL
	JZ LOC_17E7C
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017a10001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_17F18
LOC_17E7C:
	PUSHARG 3
	PUSH 96
	CMPL
	JZ LOC_17EBC
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017a10001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_17F18
LOC_17EBC:
	PUSHARG 3
	PUSH 112
	CMPL
	JZ LOC_17EFC
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017a30001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_17F18
LOC_17EFC:
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017a30001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
LOC_17F18:
	PUSHARG 4
	PUSH 255
	AND
	POPN 3
	PUSHARG 3
	PUSH 192
	CMPGE
	PUSHARG 3
	PUSH 224
	CMPL
	ORNZ
	JZ LOC_17F84
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017a40001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
LOC_17F84:
	PUSHARG 3
	PUSH 170
	CMPG
	PUSHARG 3
	PUSH 192
	CMPL
	ORNZ
	JZ LOC_17FD4
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017a60001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
LOC_17FD4:
	PUSHSTR "sc4502"
	PUSHARG 2
	PUSHARG 4
	PUSHARG 5
	PUSH 0
	CALLBS
	PUSH 1
	DELAY
	INCARG 19
	PUSHARG 4
	PUSH 2
	ADD
	POPN 4
	PUSHARG 5
	PUSH 4
	ADD
	POPN 5
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_17BF0
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 16
	DELAY
	INCARG 20
	RETN 2

}}

void function sc4502 (arg_0, arg_1, arg_2) {
__asm{
	STACK 5
	PUSHARG -4
	PUSH 27005
	INST_09 19
	PUSH 4
	DIV
	PUSH 1
	AND
	ADD
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSH 0
	POPN 3
	PUSH 0
	POPN 4
LOC_18130:
	PUSHARG 3
	PUSH 3
	CMPG
	JZ LOC_185F8
	PUSHARG 1
	PUSH 65536
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 0
	POPN 3
	INCN 4
	PUSHARG 4
	PUSH 7
	CMP
	JZ LOC_181B4
	PUSH 1
	POPN 3
LOC_181B4:
	PUSHARG 4
	PUSH 8
	CMP
	JZ LOC_185B0
	PUSHARG 1
	PUSH 27007
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG -2
	PUSH 255
	AND
	PUSH 128
	SUB
	POPN 5
	PUSHARG 5
	PUSH 0
	CMPL
	JZ LOC_18264
	PUSH 0
	PUSHARG 5
	SUB
	POPN 5
LOC_18264:
	PUSHARG 5
	PUSH 16
	CMPL
	JZ LOC_182A4
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017c50001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_18400
LOC_182A4:
	PUSHARG 5
	PUSH 32
	CMPL
	JZ LOC_182E4
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017c30001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_18400
LOC_182E4:
	PUSHARG 5
	PUSH 48
	CMPL
	JZ LOC_18324
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017c30001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_18400
LOC_18324:
	PUSHARG 5
	PUSH 80
	CMPL
	JZ LOC_18364
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017c10001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_18400
LOC_18364:
	PUSHARG 5
	PUSH 96
	CMPL
	JZ LOC_183A4
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017c10001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_18400
LOC_183A4:
	PUSHARG 5
	PUSH 112
	CMPL
	JZ LOC_183E4
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017c20001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
	JMP LOC_18400
LOC_183E4:
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017c40001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
LOC_18400:
	PUSHARG -3
	PUSH 255
	AND
	POPN 5
	PUSHARG 5
	PUSH 192
	CMPGE
	PUSHARG 5
	PUSH 224
	CMPL
	ORNZ
	JZ LOC_1846C
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017c50001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
LOC_1846C:
	PUSHARG 5
	PUSH 170
	CMPG
	PUSHARG 5
	PUSH 192
	CMPL
	ORNZ
	JZ LOC_184BC
	PUSHARG 2
	PUSHSTR "MAGIC\\017\\m017c70001"
	SYSCALL 0x1C, (2 | (0 << 16)) ; 0x001C 
LOC_184BC:
	PUSHARG 2
	PUSH 65536
	PUSH 1
	PUSH 2
	PUSHARG -3
	PUSH 64
	SUB
	PUSH 255
	AND
	PUSH 128
	CMPG
	MUL
	SUB
	MUL
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 49152
	PUSH 1
	PUSH 2
	PUSHARG -3
	PUSH 64
	SUB
	PUSH 255
	AND
	PUSH 128
	CMPG
	MUL
	SUB
	MUL
	PUSH 49152
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 2
	PUSH 1
	SYSCALL 0x1F, (2 | (0 << 16)) ; 0x001F 
LOC_185B0:
	PUSHARG 4
	PUSH 9
	CMP
	JZ LOC_185F0
	PUSHARG 1
	PUSH 256
	PUSH 256
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_185F0:
	JMP LOC_1861C
LOC_185F8:
	PUSHARG 1
	PUSH 256
	PUSH 256
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_1861C:
	PUSH 1
	DELAY
	INCN 3
	PUSHARG 4
	PUSH 9
	CMP
	JZ LOC_18654
	JMP LOC_1867C
LOC_18654:
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMPZ
	JNZ LOC_18130
LOC_1867C:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 3

}}

void function FireDragon (arg_0) {
__asm{
LOC_18698:
	STACK 11
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	SETARG 18
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\017\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 0
	SETARG 19
	PUSH 0
	SETARG 20
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_18838
	PUSH 128
	POPN 11
	JMP LOC_18848
LOC_18838:
	PUSH 128
	POPN 11
LOC_18848:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 2
	PUSHARG 2
	PUSH 0
	CMP
	JZ LOC_1889C
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 2
LOC_1889C:
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 220
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHARG 2
	PUSH 2501
	PUSHARG 11
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHSTR "m017snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG 2
	PUSHARG 3
	PUSH 120
	ADD
	PUSHARG 4
	PUSH 120
	ADD
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHSTR "sc4501"
	PUSHARG 2
	PUSHARG 11
	PUSH 16
	PUSH 1
	CALLBS
	PUSH 50
	DELAY
	PUSHARG -2
	PUSH 0
	CMPG
	JZ LOC_18B50
	PUSHARG 2
	PUSH 2501
	PUSHARG 11
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 6
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMP
	JZ LOC_18A70
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 8
LOC_18A70:
	PUSHARG 8
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 8
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 220
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHARG 6
	PUSHARG 3
	PUSH 120
	ADD
	PUSHARG 4
	PUSH 120
	ADD
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHSTR "sc4501"
	PUSHARG 6
	PUSHARG 11
	PUSH 16
	PUSH 1
	CALLBS
	PUSH 50
	DELAY
LOC_18B50:
	PUSHARG -2
	PUSH 1
	CMPG
	JZ LOC_18CD4
	PUSHARG 2
	PUSH 2501
	PUSHARG 11
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 7
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMP
	JZ LOC_18BF4
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 8
LOC_18BF4:
	PUSHARG 8
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 8
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 220
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHARG 7
	PUSHARG 3
	PUSH 120
	ADD
	PUSHARG 4
	PUSH 120
	ADD
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHSTR "sc4501"
	PUSHARG 7
	PUSHARG 11
	PUSH 16
	PUSH 1
	CALLBS
	PUSH 50
	DELAY
LOC_18CD4:
	PUSHARG -2
	PUSH 2
	CMPG
	JZ LOC_18E58
	PUSHARG 2
	PUSH 2501
	PUSHARG 11
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 9
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMP
	JZ LOC_18D78
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 8
LOC_18D78:
	PUSHARG 8
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 8
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 220
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHARG 9
	PUSHARG 3
	PUSH 120
	ADD
	PUSHARG 4
	PUSH 120
	ADD
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHSTR "sc4501"
	PUSHARG 9
	PUSHARG 11
	PUSH 16
	PUSH 1
	CALLBS
	PUSH 50
	DELAY
LOC_18E58:
	PUSHARG -2
	PUSH 3
	CMPG
	JZ LOC_18FD0
	PUSHARG 2
	PUSH 2501
	PUSHARG 11
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 10
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMP
	JZ LOC_18EFC
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 8
LOC_18EFC:
	PUSHARG 8
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 8
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 4
	PUSH 220
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHARG 10
	PUSHARG 3
	PUSH 120
	ADD
	PUSHARG 4
	PUSH 120
	ADD
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHSTR "sc4501"
	PUSHARG 10
	PUSHARG 11
	PUSH 16
	PUSH 1
	CALLBS
LOC_18FD0:
	PUSH 1
	DELAY
	INST_09 20
	PUSHARG -2
	CMPLE
	JNZ LOC_18FD0
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 6
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 7
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 9
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 10
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function CallDragonCallback (arg_0, arg_1) callsign 18001 {
__asm{
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	INST_09 22
	PUSH 0
	CMP
	ORNZ
	JZ LOC_1912C
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CALL Hurt
	PUSH 1
	SETARG 22
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
	JMP LOC_19178
LOC_1912C:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_19178:
	RETN 2

}}

void function sc3601 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSH 10
	PUSH 50
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	PUSHARG -5
	PUSH 28001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSH 60
	POPN 2
LOC_191F4:
	PUSHARG 2
	PUSH 0
	CMPG
	JZ LOC_19260
	INCN -2
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	DECN 2
	PUSH 1
	DELAY
	JMP LOC_191F4
LOC_19260:
	PUSH 30
	DELAY
	PUSHSTR "sc3602"
	PUSHARG -6
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	CALLBS
	PUSH 0
	POPN 2
LOC_192A8:
	PUSHARG 2
	PUSH 10
	CMPL
	JZ LOC_1931C
	PUSHARG 1
	PUSH 0
	PUSH 65536
	PUSHARG 2
	PUSH 65536
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_192A8
LOC_1931C:
	PUSHARG 2
	PUSH 30
	CMPL
	JZ LOC_193E4
	PUSHARG -2
	PUSHARG 2
	PUSH 10
	MUL
	ADD
	POPN -2
	PUSHARG 1
	PUSH 0
	PUSH 65536
	PUSHARG 2
	PUSH 65536
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_1931C
LOC_193E4:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 5

}}

void function sc3602 (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 6
	PUSHARG -5
	JCOND 0, LOC_19434
	JCOND 1, LOC_1944C
	POP
	JMP LOC_19464
LOC_19434:
	PUSH 10
	POPN 5
	JMP LOC_19474
LOC_1944C:
	PUSH 20
	POPN 5
	JMP LOC_19474
LOC_19464:
	PUSH 20
	POPN 5
LOC_19474:
	PUSH 0
	POPN 1
LOC_19484:
	PUSHARG 1
	PUSHARG 5
	CMPL
	JZ LOC_195E8
	PUSHARG -4
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	PUSHARG -3
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 3
	PUSHARG 2
	PUSHARG 3
	PUSHARG -2
	PUSH 20
	ADD
	PUSH 0
	PUSH 28002
	PUSH 28004
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 6
	PUSHARG 6
	PUSH 0
	PUSH 10
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHSTR "m016a"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 1
	JMP LOC_19484
LOC_195E8:
	PUSH 15
	DELAY
	RETN 4

}}

void function sc3603 (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 3
	PUSHARG -4
	PUSHARG -3
	PUSH 320
	PUSH 360
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 28005
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
	PUSH 4
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSH 2
	PUSH 3
	PUSHARG -5
	MUL
	ADD
	POPN 1
LOC_19698:
	PUSHARG 1
	DECN 1
	PUSH 0
	CMPG
	JZ LOC_19798
	PUSHARG -4
	PUSH 320
	NEG
	PUSH 320
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	PUSHARG -3
	PUSH 100
	NEG
	PUSH 300
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 3
	PUSHARG 2
	PUSHARG 3
	PUSH 320
	PUSH 360
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 28005
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
	PUSH 4
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	JMP LOC_19698
LOC_19798:
	RETN 4

}}

void function sc2512 (arg_0) {
__asm{
	STACK 2
	PUSH 16384
	POPN 1
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG -2
	PUSH 8192
	SYSCALL 0x21, (2 | (0 << 16)) ; 0x0021 
	PUSH 30
	PUSH 40
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
LOC_19848:
	PUSHARG 2
	DECN 2
	PUSH 0
	CMPG
	JZ LOC_198C0
	PUSHARG -2
	PUSHARG 1
	PUSHARG 1
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 256
	SUB
	POPN 1
	PUSH 1
	DELAY
	JMP LOC_19848
LOC_198C0:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 1

}}

void function sc3604 () callsign 18002 {
__asm{
	STACK 3
	SYSCALL 0xB, (0 | (1 << 16)) ; 0x000B 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x8, (1 | (0 << 16)) ; 0x0008 
	PUSHSTR "MovingShadow"
	PUSHARG 3
	INST_09 21
	PUSH 28011
	PUSH 0
	PUSH 18001
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "MovingShadow"
	PUSHARG 3
	INST_09 21
	PUSH 28011
	PUSH 128
	PUSH 18001
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "MovingShadow"
	PUSHARG 3
	INST_09 21
	PUSH 28011
	PUSH 64
	PUSH 18001
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "MovingShadow"
	PUSHARG 3
	INST_09 21
	PUSH 28011
	PUSH 192
	PUSH 18001
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHARG 3
	PUSH 0
	PUSH 0
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 3
	PUSH 0
	SYSCALL 0x1E, (2 | (0 << 16)) ; 0x001E 
	PUSH 0
	POPN 2
LOC_19A4C:
	PUSHARG 2
	PUSH 20
	CMPL
	JZ LOC_19B10
	PUSHARG 3
	PUSH 10003
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 16384
	PUSH 16384
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "sc2512"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	INCN 2
	JMP LOC_19A4C
LOC_19B10:
	PUSHARG 1
	PUSHSTR "m018snd03"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	RETN 0

}}

void function CallDragon (arg_0) {
__asm{
LOC_19B3C:
	STACK 13
	PUSH 0
	SETARG 22
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\018\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_19CBC
	PUSH 0
	POPN 10
	JMP LOC_19CCC
LOC_19CBC:
	PUSH 128
	POPN 10
LOC_19CCC:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHSTR "m018snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	JCOND 0, LOC_19D68
	JCOND 1, LOC_19DBC
	POP
	JMP LOC_19E10
LOC_19D68:
	PUSHSTR "sc3602"
	PUSHARG -2
	PUSHARG 1
	PUSHARG 2
	PUSHARG 3
	CALLBS
	PUSH 50
	POPN 11
	PUSH 110
	SETARG 21
	JMP LOC_19E78
LOC_19DBC:
	PUSHSTR "sc3602"
	PUSHARG -2
	PUSHARG 1
	PUSHARG 2
	PUSHARG 3
	CALLBS
	PUSH 100
	POPN 11
	PUSH 220
	SETARG 21
	JMP LOC_19E78
LOC_19E10:
	PUSHSTR "sc3601"
	PUSHARG -2
	PUSHARG 10
	PUSHARG 1
	PUSHARG 2
	PUSHARG 3
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 100
	PUSH 95
	ADD
	POPN 11
	PUSH 330
	SETARG 21
LOC_19E78:
	PUSH 0
	POPN 4
LOC_19E88:
	PUSHARG 4
	PUSHARG 11
	CMPL
	JZ LOC_1A294
	PUSH 1
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 12
	PUSH 0
	POPN 5
LOC_19ED8:
	PUSHARG 5
	PUSHARG 12
	CMPL
	JZ LOC_1A08C
	PUSHARG 1
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 7
	PUSHARG 2
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 8
	PUSHARG -2
	PUSH 2
	CMP
	JZ LOC_1A030
	PUSHARG 7
	PUSH 48
	SUB
	PUSHARG 8
	PUSHARG 9
	PUSH 0
	PUSH 28006
	PUSH 28007
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
	PUSHARG 7
	PUSH 48
	ADD
	PUSHARG 8
	PUSHARG 9
	PUSH 0
	PUSH 28006
	PUSH 28007
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
	JMP LOC_1A07C
LOC_1A030:
	PUSHARG 7
	PUSHARG 8
	PUSHARG 9
	PUSH 0
	PUSH 28006
	PUSH 28007
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
LOC_1A07C:
	INCN 5
	JMP LOC_19ED8
LOC_1A08C:
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CMP
	JZ LOC_1A1D4
	PUSHARG 1
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 7
	PUSHARG 2
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 8
	PUSHARG 7
	PUSHARG 8
	PUSHARG 9
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 28008
	PUSH 28009
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 13
	PUSHARG 13
	PUSH 10
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 10
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
LOC_1A1D4:
	PUSH 1
	DELAY
	PUSHARG 4
	JCOND 49, LOC_1A218
	JCOND 99, LOC_1A23C
	JCOND 149, LOC_1A260
	POP
	JMP LOC_1A284
LOC_1A218:
	PUSHSTR "m018snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_1A284
LOC_1A23C:
	PUSHSTR "m018snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_1A284
LOC_1A260:
	PUSHSTR "m018snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_1A284
LOC_1A284:
	INCN 4
	JMP LOC_19E88
LOC_1A294:
	PUSHARG -2
	PUSH 1
	CMPG
	JZ LOC_1A2C4
	PUSHSTR "sc3601"
	INST_45
	JMP LOC_1A2D0
LOC_1A2C4:
	PUSHSTR "sc3602"
	INST_45
LOC_1A2D0:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 13
	PUSHARG 13
	PUSH 0
	CMP
	JZ LOC_1A324
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 13
LOC_1A324:
	PUSHARG 13
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 13
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 13
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHARG 2
	PUSH 240
	CMPG
	JZ LOC_1A3D4
	PUSHSTR "MoveCamera"
	PUSHARG 1
	PUSHARG 2
	PUSH 240
	SUB
	PUSH 20
	PUSH 0
	CALLBS
	JMP LOC_1A400
LOC_1A3D4:
	PUSHSTR "MoveCamera"
	PUSHARG 1
	PUSH 0
	PUSH 20
	PUSH 0
	CALLBS
LOC_1A400:
	PUSHSTR "MoveCamera"
	INST_45
	PUSHARG 13
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_1A488
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 13
	PUSHARG 13
	PUSH 0
	CMP
	JZ LOC_1A488
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 13
LOC_1A488:
	PUSHARG 13
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 13
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 13
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHSTR "sc3603"
	PUSHARG -2
	PUSHARG 1
	PUSHARG 2
	PUSHARG 3
	CALLBS
	PUSHSTR "sc3603"
	INST_45
	PUSH 65
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function RunningBowCallback (arg_0, arg_1) callsign 19001 {
__asm{
	STACK 1
	PUSHARG -3
	PUSH 2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_1A698
	DECARG 23
	INST_09 23
	PUSH 0
	CMP
	JZ LOC_1A638
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	PUSH 5
	INST_09 24
	PUSH 2
	MUL
	PUSH 2
	MUL
	ADD
	SUB
	POPN 1
	PUSHARG -3
	PUSHARG -2
	PUSH 11002
	PUSH 1
	PUSH 48
	PUSH 0
	CALL HitGeneral
	JMP LOC_1A670
LOC_1A638:
	PUSH 2
	POPN 1
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 48
	CALL SmallFireBall2
LOC_1A670:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	JMP LOC_1A70C
LOC_1A698:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
	PUSHARG -3
	PUSHARG -2
	PUSH 15
	PUSH 35
	CALL SmallFireBall2
LOC_1A70C:
	RETN 2

}}

void function CreateBowLight (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -3
	PUSH 0
	PUSHARG -2
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 24576
	PUSH 16384
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_1A7A0:
	PUSHARG -5
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1A7D0
	PUSH 1
	DELAY
	JMP LOC_1A7A0
LOC_1A7D0:
	PUSHARG 1
	PUSH 4
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 4

}}

void function CreateBow (arg_0, arg_1) {
__asm{
LOC_1A7FC:
	STACK 1
	PUSHARG -3
	PUSH 29001
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHARG 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 19001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSHARG -3
	PUSHARG -2
	PUSH 80
	PUSH 80
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	INST_01 2

}}

void function TraceBow (arg_0, arg_1) {
__asm{
	STACK 1
	PUSHARG -3
	PUSH 262144
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 16
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHSTR "CreateBowLight"
	PUSHARG -3
	PUSH 29002
	PUSHARG -2
	PUSH 16
	CALLBS
LOC_1A974:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1AA14
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPLE
	PUSHARG 1
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	CMPGE
	ORZ
	JZ LOC_1AA00
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	JMP LOC_1AA14
LOC_1AA00:
	PUSH 1
	DELAY
	JMP LOC_1A974
LOC_1AA14:
	RETN 2

}}

void function RunningBow (arg_0) {
__asm{
LOC_1AA1C:
	STACK 16
	PUSH 0
	SETARG 23
	PUSHARG -2
	SETARG 24
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\019\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	CMP
	JZ LOC_1AAEC
	PUSH 0
	PUSH 90
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 5
	JMP LOC_1AAFC
LOC_1AAEC:
	PUSH 0
	POPN 5
LOC_1AAFC:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_1AB44
	PUSH 0
	POPN 4
	PUSH 1
	NEG
	POPN 3
	JMP LOC_1AB64
LOC_1AB44:
	PUSH 128
	POPN 4
	PUSH 1
	POPN 3
LOC_1AB64:
	PUSHARG -2
	JCOND 0, LOC_1AB90
	JCOND 1, LOC_1ABB8
	POP
	JMP LOC_1ABE0
LOC_1AB90:
	PUSH 5
	POPN 16
	PUSH 5
	SETARG 23
	JMP LOC_1AC00
LOC_1ABB8:
	PUSH 7
	POPN 16
	PUSH 7
	SETARG 23
	JMP LOC_1AC00
LOC_1ABE0:
	PUSH 9
	POPN 16
	PUSH 9
	SETARG 23
LOC_1AC00:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 3
	PUSH 180
	MUL
	SUB
	PUSHARG 2
	PUSH 140
	SUB
	PUSHARG 5
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 524288
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHSTR "m019snd01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 0
	POPN 6
LOC_1AD24:
	PUSHARG 6
	PUSHARG 16
	CMPL
	JZ LOC_1AD78
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 4
	CALL CreateBow
	PUSHARG 6
	SETNR 7
	INCN 6
	JMP LOC_1AD24
LOC_1AD78:
	PUSH 0
	POPN 6
LOC_1AD88:
	PUSHARG 6
	PUSHARG 16
	CMPL
	JZ LOC_1AE30
	PUSHSTR "TraceBow"
	PUSHARG 6
	PUSHNR 7
	PUSHARG 4
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG 6
	PUSH 4
	CMPL
	JZ LOC_1AE14
	PUSH 3
	PUSHARG 6
	ADD
	DELAY
	JMP LOC_1AE20
LOC_1AE14:
	PUSH 5
	DELAY
LOC_1AE20:
	INCN 6
	JMP LOC_1AD88
LOC_1AE30:
	PUSHSTR "LockCamera2"
	PUSH 0
	PUSHNR 7
	PUSH 180
	PUSH 160
	NEG
	PUSHARG 5
	ADD
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSHARG 16
	PUSH 1
	SUB
	PUSHNR 7
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "TraceBow"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function BlackHoleCallback (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 1
	PUSHARG -2
	PUSHARG -3
	PUSH 16
	PUSH 25
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
LOC_1AF38:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1AFE0
	PUSH 1
	DELAY
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 2
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG -2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 2
	PUSHARG 1
	PUSH 10
	SUB
	CMPGE
	JZ LOC_1AFD8
	JMP LOC_1AFE0
LOC_1AFD8:
	JMP LOC_1AF38
LOC_1AFE0:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function KillMan (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -3
	PUSH 0
	PUSH 123
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSH 0
	POPN 2
LOC_1B038:
	PUSHARG 2
	PUSH 20
	CMPL
	JZ LOC_1B0A8
	PUSHARG -3
	PUSHARG -2
	PUSH 4
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_1B038
LOC_1B0A8:
	PUSH 0
	POPN 2
LOC_1B0B8:
	PUSHARG 2
	PUSH 30
	CMPL
	JZ LOC_1B128
	PUSHARG -3
	PUSHARG -2
	PUSH 2
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_1B0B8
LOC_1B128:
	PUSHARG -3
	SYSCALL 0x134, (1 | (1 << 16)) ; KillSoldier 
	POP
	PUSHSTR "BlackHoleCallback"
	PUSHARG -2
	PUSHARG -3
	PUSH 0
	PUSH 0
	CALLBS
	RETN 2

}}

void function Engulf (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 245
	PUSH 0
	POPN 244
	PUSHARG -4
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 236
	PUSHARG -3
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 237
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_1B218
	PUSH 3
	POPN 241
	PUSH 9
	POPN 242
	PUSH 8
	POPN 243
	JMP LOC_1B248
LOC_1B218:
	PUSH 4
	POPN 241
	PUSH 16
	POPN 242
	PUSH 10
	POPN 243
LOC_1B248:
	PUSH 0
	POPN 234
LOC_1B258:
	PUSHARG 234
	PUSHARG 243
	CMPL
	JZ LOC_1B5B8
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 236
	PUSHARG 237
	PUSHARG 241
	PUSHARG 242
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 232
	PUSHARG 232
	PUSH 0
	CMPG
	JZ LOC_1B5A8
	PUSH 0
	POPN 233
LOC_1B2E8:
	PUSHARG 233
	PUSHARG 232
	CMPL
	JZ LOC_1B36C
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 236
	PUSHARG 237
	PUSHARG 241
	PUSHARG 242
	PUSHARG 233
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	PUSHARG 233
	SETNR 1
	INCN 233
	JMP LOC_1B2E8
LOC_1B36C:
	PUSH 0
	POPN 233
LOC_1B37C:
	PUSHARG 233
	PUSHARG 232
	CMPL
	JZ LOC_1B428
	PUSH 0
	PUSHARG 232
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 239
	PUSHARG 233
	PUSHNR 1
	POPN 240
	PUSHARG 239
	PUSHNR 1
	PUSHARG 233
	SETNR 1
	PUSHARG 240
	PUSHARG 239
	SETNR 1
	INCN 233
	JMP LOC_1B37C
LOC_1B428:
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_1B470
	PUSH 4
	PUSH 7
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 232
	JMP LOC_1B494
LOC_1B470:
	PUSH 6
	PUSH 9
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 232
LOC_1B494:
	PUSH 0
	POPN 233
LOC_1B4A4:
	PUSHARG 233
	PUSHARG 232
	CMPL
	JZ LOC_1B5A8
	PUSHARG 233
	PUSHNR 1
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	PUSH 123
	CMPZ
	PUSHARG 233
	PUSHNR 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	ORNZ
	JZ LOC_1B54C
	PUSHSTR "KillMan"
	PUSHARG 233
	PUSHNR 1
	PUSHARG -5
	PUSH 0
	PUSH 0
	CALLBS
LOC_1B54C:
	PUSH 3
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 245
	PUSHARG 245
	DELAY
	PUSHARG 244
	PUSHARG 245
	ADD
	POPN 244
	INCN 233
	JMP LOC_1B4A4
LOC_1B5A8:
	INCN 234
	JMP LOC_1B258
LOC_1B5B8:
	PUSHARG -2
	PUSH 0
	CMP
	PUSHARG 244
	PUSH 160
	CMPL
	ORNZ
	JZ LOC_1B60C
	PUSH 160
	PUSHARG 244
	SUB
	DELAY
	JMP LOC_1B658
LOC_1B60C:
	PUSHARG -2
	PUSH 0
	CMPZ
	PUSHARG 244
	PUSH 350
	CMPL
	ORNZ
	JZ LOC_1B658
	PUSH 350
	PUSHARG 244
	SUB
	DELAY
LOC_1B658:
	RETN 4

}}

void function CreateBlackHoleBall (arg_0) {
__asm{
	STACK 1
LOC_1B668:
	INST_09 25
	JZ LOC_1B7A4
	PUSHARG -2
	PUSH 30013
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -2
	PUSH 152
	PUSH 232
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 200
	PUSH 300
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 80
	NEG
	PUSH 80
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSHARG -2
	PUSH 7
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 10
	PUSH 18
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	JMP LOC_1B668
LOC_1B7A4:
	RETN 1

}}

void function CreateBlackHoleStars (arg_0) {
__asm{
	PUSHSTR "CreateBlackHoleBall"
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
LOC_1B7D8:
	INST_09 25
	JZ LOC_1B928
	PUSHSTR "CreateBlackHoleStar"
	PUSHARG -2
	PUSH 30003
	PUSH 30011
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 30
	PUSH 130
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 127
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateBlackHoleStar"
	PUSHARG -2
	PUSH 30003
	PUSH 30011
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 30
	PUSH 130
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 128
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 0
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	JMP LOC_1B7D8
LOC_1B928:
	RETN 1

}}

void function CreateBlackHoleStar (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 1
	PUSHARG -6
	PUSHARG -5
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 131072
	PUSH 131072
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -6
	PUSH 0
	PUSHARG -3
	PUSHARG -4
	PUSH 0
	SYSCALL 0x16, (6 | (0 << 16)) ; 0x0016 
	PUSHARG 1
	PUSHARG -6
	PUSHARG -2
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	PUSHARG 1
	PUSHARG -4
	PUSHARG -2
	DIV
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_1BA20:
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1BAA8
	PUSHARG 1
	PUSH 4
	PUSH 1
	SYSCALL 0x23, (3 | (1 << 16)) ; CreateObject_Shadow 
	POP
	PUSH 1
	DELAY
	INST_09 25
	PUSH 0
	CMP
	JZ LOC_1BAA0
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_1BAA0:
	JMP LOC_1BA20
LOC_1BAA8:
	RETN 5

}}

void function CreateBlackHole (arg_0, arg_1, arg_2) {
__asm{
LOC_1BAB0:
	STACK 11
	PUSHARG -4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -4
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG -3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHINV 5 ; INTV_IS_RIGHT
	CALL GetSoldierMaxX2
	POPN 11
	PUSHARG 11
	PUSH 1
	NEG
	CMP
	JZ LOC_1BB90
	PUSHARG 2
	PUSHARG 3
	ADD
	PUSH 2
	DIV
	POPN 2
	JMP LOC_1BBEC
LOC_1BB90:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_1BBD0
	PUSHARG 11
	PUSH 200
	ADD
	POPN 2
	JMP LOC_1BBEC
LOC_1BBD0:
	PUSHARG 11
	PUSH 200
	SUB
	POPN 2
LOC_1BBEC:
	PUSHARG 4
	PUSHARG 5
	ADD
	PUSH 2
	DIV
	POPN 4
	PUSHARG 2
	PUSHARG 4
	PUSH 10
	CALL MoveCamera
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_1BCA0
	PUSHARG 2
	PUSHARG 4
	PUSH 700
	ADD
	PUSH 100
	PUSH 128
	PUSH 30012
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 9
	JMP LOC_1BCE8
LOC_1BCA0:
	PUSHARG 2
	PUSHARG 4
	PUSH 700
	ADD
	PUSH 100
	PUSH 128
	PUSH 30014
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 9
LOC_1BCE8:
	PUSH 0
	POPN 6
LOC_1BCF8:
	PUSHARG 6
	PUSH 106496
	CMPL
	JZ LOC_1BEEC
	PUSHARG 6
	PUSH 24576
	CMPL
	JZ LOC_1BD44
	PUSH 6
	DELAY
	JMP LOC_1BD50
LOC_1BD44:
	PUSH 1
	DELAY
LOC_1BD50:
	PUSHARG 6
	PUSH 24576
	CMP
	JZ LOC_1BE20
	PUSHARG 9
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 2
	PUSHARG 4
	PUSH 716
	ADD
	PUSH 100
	PUSH 128
	PUSH 30002
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 7
	PUSHARG 2
	PUSHARG 4
	PUSH 700
	ADD
	PUSH 100
	PUSH 128
	PUSH 30001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
LOC_1BE20:
	PUSHARG 6
	PUSH 24576
	CMPGE
	JZ LOC_1BE8C
	PUSHARG 7
	PUSHARG 6
	PUSHARG 6
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG 6
	PUSHARG 6
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	JMP LOC_1BEC8
LOC_1BE8C:
	PUSHARG 9
	PUSHARG 6
	PUSH 12
	MUL
	PUSHARG 6
	PUSH 12
	MUL
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_1BEC8:
	PUSHARG 6
	PUSH 4096
	ADD
	POPN 6
	JMP LOC_1BCF8
LOC_1BEEC:
	PUSH 1
	SETARG 25
	PUSHARG -2
	PUSH 0
	CMPG
	JZ LOC_1BF84
	PUSHARG 2
	PUSHARG 4
	PUSH 700
	ADD
	PUSH 100
	PUSH 128
	PUSH 30015
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 10
	PUSHARG 10
	PUSH 94208
	PUSH 94208
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_1BF84:
	PUSHSTR "CreateBlackHoleStars"
	PUSHARG 7
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "Engulf"
	PUSHARG 1
	PUSHARG 2
	PUSHARG 4
	PUSHARG -2
	CALLBS
	PUSHSTR "Engulf"
	INST_45
	PUSH 150
	DELAY
	PUSHARG -2
	PUSH 0
	CMPG
	JZ LOC_1C024
	PUSHARG 10
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_1C024:
	PUSH 0
	SETARG 25
	PUSH 131072
	POPN 6
LOC_1C044:
	PUSHARG 6
	PUSH 0
	CMPGE
	JZ LOC_1C0D8
	PUSHARG 1
	PUSHARG 6
	PUSHARG 6
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 7
	PUSHARG 6
	PUSHARG 6
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	PUSHARG 6
	PUSH 10240
	SUB
	POPN 6
	JMP LOC_1C044
LOC_1C0D8:
	PUSHARG 1
	PUSH 2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 7
	PUSH 2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function BlackHole (arg_0) {
__asm{
LOC_1C128:
	STACK 2
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\020\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 140
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 40
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_1C2A4
	PUSHSTR "m020snd01"
	PUSH 180
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_1C2C0
LOC_1C2A4:
	PUSHSTR "m020snd02"
	PUSH 210
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
LOC_1C2C0:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSHARG -2
	CALL CreateBlackHole
	PUSH 40
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function FireRingCallback (arg_0, arg_1) callsign 20001 {
__asm{
	STACK 2
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_1C450
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 2
	PUSHARG 2
	INST_4F 26
	JZ LOC_1C39C
	INST_09 30
	PUSHARG 2
	INST_4F 26
	DIV
	POPN 1
LOC_1C39C:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_1C448
	PUSHARG 2
	INST_4F 26
	PUSH 2
	MUL
	PUSHARG 2
	INST_52 26
	PUSHSTR "HitGeneral"
	PUSHARG -3
	PUSHARG -2
	PUSH 11002
	PUSH 1
	PUSH 48
	PUSH 60
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
LOC_1C448:
	JMP LOC_1C49C
LOC_1C450:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_1C49C:
	RETN 2

}}

void function CreateFire (arg_0) {
__asm{
	STACK 1
	PUSHARG -2
	PUSH 31001
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 65536
	PUSH 81920
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "StepShow"
	PUSHARG 1
	PUSH 8
	PUSH 0
	PUSH 0
	CALLBS
LOC_1C530:
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1C594
	PUSH 1
	DELAY
	PUSHARG 1
	PUSHARG -2
	PUSH 192
	PUSH 8
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	JMP LOC_1C530
LOC_1C594:
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 1

}}

void function FireRingMotion2 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 5
	PUSH 0
	POPN 1
	PUSH 0
	POPN 2
	PUSH 1
	POPN 3
	PUSHARG -3
	POPN 4
	PUSH 5
	POPN 5
LOC_1C618:
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1C7DC
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSHARG 4
	PUSHARG -2
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG -2
	PUSH 80
	CMPGE
	JZ LOC_1C6AC
	PUSH 1
	NEG
	POPN 3
	JMP LOC_1C6D8
LOC_1C6AC:
	PUSHARG -2
	PUSH 50
	CMPLE
	JZ LOC_1C6D8
	PUSH 1
	POPN 3
LOC_1C6D8:
	PUSHARG -2
	PUSHARG 3
	ADD
	POPN -2
	PUSHARG -4
	PUSH 2
	ADD
	PUSH 255
	AND
	POPN -4
	INCN 2
	PUSHARG 2
	PUSH 3
	AND
	PUSH 0
	CMP
	JZ LOC_1C754
	INCN 1
LOC_1C754:
	PUSHARG 4
	PUSH 240
	CMPGE
	JZ LOC_1C78C
	PUSH 5
	NEG
	POPN 5
	JMP LOC_1C7B8
LOC_1C78C:
	PUSHARG 4
	PUSHARG -3
	CMPLE
	JZ LOC_1C7B8
	PUSH 5
	POPN 5
LOC_1C7B8:
	PUSHARG 4
	PUSHARG 5
	ADD
	POPN 4
	JMP LOC_1C618
LOC_1C7DC:
	RETN 5

}}

void function FireRingMotion (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5) {
__asm{
	STACK 3
	PUSH 0
	POPN 1
	PUSH 0
	POPN 2
	PUSH 1
	POPN 3
LOC_1C81C:
	PUSHARG -7
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1C960
	PUSHARG -7
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG -3
	PUSH 80
	CMPGE
	JZ LOC_1C8B0
	PUSH 1
	NEG
	POPN 3
	JMP LOC_1C8DC
LOC_1C8B0:
	PUSHARG -3
	PUSH 50
	CMPLE
	JZ LOC_1C8DC
	PUSH 1
	POPN 3
LOC_1C8DC:
	PUSHARG -3
	PUSHARG 3
	ADD
	POPN -3
	PUSHARG -5
	PUSHARG -2
	ADD
	PUSH 255
	AND
	POPN -5
	INCN 2
	PUSHARG 2
	PUSH 3
	AND
	PUSH 0
	CMP
	JZ LOC_1C958
	INCN 1
LOC_1C958:
	JMP LOC_1C81C
LOC_1C960:
	RETN 6

}}

void function CreateFireRing (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6) {
__asm{
	STACK 2
	PUSH 0
	POPN 2
	PUSHARG -7
	PUSH 255
	AND
	POPN -7
	PUSHARG -8
	PUSH 31002
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -8
	PUSHARG -7
	PUSHARG -6
	PUSHARG -5
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 20001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_1CA90
	PUSHARG 1
	PUSH 0
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	JMP LOC_1CAB4
LOC_1CA90:
	PUSHARG 1
	PUSH 0
	PUSH 1
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
LOC_1CAB4:
	PUSHSTR "StepShow"
	PUSHARG 1
	PUSH 8
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateFire"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG -3
	PUSH 0
	CMP
	JZ LOC_1CC48
	PUSHSTR "FireRingMotion"
	PUSHARG 1
	PUSHARG -8
	PUSHARG -7
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
LOC_1CB6C:
	PUSHARG -8
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1CBC8
	PUSH 1
	DELAY
	INCN 2
	PUSHARG 2
	PUSH 400
	CMPG
	JZ LOC_1CBC0
	JMP LOC_1CBC8
LOC_1CBC0:
	JMP LOC_1CB6C
LOC_1CBC8:
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_1CC28
	PUSH 0
	PUSH 0
	INST_52 28
	JMP LOC_1CC40
LOC_1CC28:
	PUSH 0
	PUSH 1
	INST_52 28
LOC_1CC40:
	JMP LOC_1CD58
LOC_1CC48:
	PUSHSTR "FireRingMotion2"
	PUSHARG 1
	PUSHARG -8
	PUSHARG -7
	PUSHARG -6
	PUSHARG -5
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_1CC84:
	PUSHARG -8
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1CCE0
	PUSH 1
	DELAY
	INCN 2
	PUSHARG 2
	PUSH 400
	CMPG
	JZ LOC_1CCD8
	JMP LOC_1CCE0
LOC_1CCD8:
	JMP LOC_1CC84
LOC_1CCE0:
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_1CD40
	PUSH 0
	PUSH 0
	INST_52 28
	JMP LOC_1CD58
LOC_1CD40:
	PUSH 0
	PUSH 1
	INST_52 28
LOC_1CD58:
	RETN 7

}}

void function FireRing (arg_0, arg_1) {
__asm{
LOC_1CD60:
	STACK 6
	PUSH 0
	POPN 6
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_1CE08
	PUSH 0
	INST_4F 28
	PUSH 1
	CMP
	JZ LOC_1CDD0
	PUSH 1
	POPN 6
	JMP LOC_1CE00
LOC_1CDD0:
	PUSH 1
	PUSH 0
	INST_52 28
	PUSH 1
	PUSH 0
	INST_52 26
LOC_1CE00:
	JMP LOC_1CE90
LOC_1CE08:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMP
	JZ LOC_1CE90
	PUSH 1
	INST_4F 28
	PUSH 1
	CMP
	JZ LOC_1CE60
	PUSH 1
	POPN 6
	JMP LOC_1CE90
LOC_1CE60:
	PUSH 1
	PUSH 1
	INST_52 28
	PUSH 1
	PUSH 1
	INST_52 26
LOC_1CE90:
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	SETARG 30
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\021\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHARG 6
	PUSH 0
	CMP
	JZ LOC_1D28C
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHSTR "m021snd01"
	PUSH 200
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 4
	POPN 5
	PUSH 80
	PUSH 50
	SUB
	PUSH 10
	SUB
	PUSHARG 5
	DIV
	POPN 4
	PUSH 0
	POPN 3
LOC_1D060:
	PUSHARG 3
	PUSHARG 5
	CMPL
	JZ LOC_1D12C
	PUSHSTR "CreateFireRing"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 3
	PUSH 256
	MUL
	PUSHARG 5
	DIV
	PUSH 60
	PUSH 50
	PUSH 5
	ADD
	PUSHARG 3
	PUSHARG 4
	MUL
	ADD
	PUSH 4
	PUSHARG -3
	PUSH 2
	MUL
	ADD
	PUSHARG -2
	PUSHINV 5 ; INTV_IS_RIGHT
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
	INCN 3
	JMP LOC_1D060
LOC_1D12C:
	PUSHARG -3
	PUSH 0
	CMPG
	JZ LOC_1D284
	PUSHARG -2
	PUSH 0
	CMPG
	JZ LOC_1D170
	PUSH 20
	DELAY
LOC_1D170:
	PUSH 6
	POPN 5
	PUSH 80
	PUSH 50
	SUB
	PUSH 10
	SUB
	PUSHARG 5
	DIV
	POPN 4
	PUSH 0
	POPN 3
LOC_1D1C4:
	PUSHARG 3
	PUSHARG 5
	CMPL
	JZ LOC_1D284
	PUSHSTR "CreateFireRing"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32
	PUSHARG 3
	PUSH 256
	MUL
	PUSHARG 5
	DIV
	ADD
	PUSH 120
	PUSH 50
	PUSH 5
	ADD
	PUSHARG 3
	PUSHARG 4
	MUL
	ADD
	PUSH 2
	PUSHARG -2
	PUSHINV 5 ; INTV_IS_RIGHT
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
	INCN 3
	JMP LOC_1D1C4
LOC_1D284:
	JMP LOC_1D2E0
LOC_1D28C:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_1D2C8
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	CALL CastFail
	JMP LOC_1D2E0
LOC_1D2C8:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 128
	CALL CastFail
LOC_1D2E0:
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 2

}}

void function IceCallback (arg_0, arg_1) callsign 22001 {
__asm{
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_1D3C4
	INST_09 31
	PUSH 4
	CMPL
	JZ LOC_1D3A0
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 31
	DIV
	CALL Hurt
	INST_09 31
	PUSH 2
	MUL
	SETARG 31
	JMP LOC_1D3BC
LOC_1D3A0:
	PUSHARG -3
	PUSH 16777216
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
LOC_1D3BC:
	JMP LOC_1D3E4
LOC_1D3C4:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_1D3E4:
	RETN 2

}}

void function CreateIceShatter (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -5
	PUSH 32003
	PUSH 32005
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 12288
	PUSH 20480
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12288
	PUSH 20480
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -5
	PUSH 128
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 30
	PUSHARG -4
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 0
	PUSHARG -3
	PUSHARG -2
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG -4
	PUSH 20
	DIV
	DELAY
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 4

}}

void function CreateIceFog (arg_0, arg_1, arg_2) {
__asm{
	PUSHSTR "CreateFogSpeed"
	PUSHARG -3
	PUSH 2
	NEG
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 14
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFogSpeed"
	PUSHARG -3
	PUSH 32
	ADD
	PUSH 2
	NEG
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 14
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFogSpeed"
	PUSHARG -3
	PUSH 32
	SUB
	PUSH 2
	NEG
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 14
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 16
	DELAY
	PUSHSTR "CreateFogSpeed"
	PUSHARG -3
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 17
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFogSpeed"
	PUSHARG -3
	PUSH 30
	ADD
	PUSH 6
	NEG
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 17
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFogSpeed"
	PUSHARG -3
	PUSH 30
	SUB
	PUSH 6
	NEG
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 17
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 18
	DELAY
	PUSHSTR "CreateFogSpeed"
	PUSHARG -3
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFogSpeed"
	PUSHARG -3
	PUSH 28
	ADD
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFogSpeed"
	PUSHARG -3
	PUSH 28
	SUB
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	RETN 3

}}

void function CreateIce (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5) {
__asm{
	STACK 2
	PUSHARG -3
	DELAY
	PUSHARG -7
	PUSHARG -6
	PUSH 0
	PUSH 128
	PUSH 32002
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSHARG -4
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -2
	JZ LOC_1DD2C
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 22001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_1DD2C:
	PUSHSTR "CreateFogSpeed"
	PUSHARG -7
	PUSH 2
	NEG
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -6
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFogSpeed"
	PUSHARG -7
	PUSH 32
	ADD
	PUSH 2
	NEG
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -6
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFogSpeed"
	PUSHARG -7
	PUSH 32
	SUB
	PUSH 2
	NEG
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -6
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 48
	PUSH 64
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 0
	POPN 2
LOC_1DF88:
	PUSHARG 2
	PUSH 8
	CMPL
	JZ LOC_1E070
	PUSHSTR "CreateIceShatter"
	PUSHARG 1
	PUSHARG -4
	PUSHARG 2
	PUSH 1
	ADD
	MUL
	PUSH 65536
	DIV
	PUSH 20
	MUL
	PUSH 26
	PUSH 36
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	CALLBS
	PUSH 1
	DELAY
	PUSHARG 1
	PUSH 2
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	INCN 2
	JMP LOC_1DF88
LOC_1E070:
	PUSHSTR "LockTargetXY"
	PUSHARG -7
	PUSH 54
	ADD
	PUSHARG -6
	PUSH 2501
	PUSH 0
	PUSH 4
	PUSH 22001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -7
	PUSH 54
	SUB
	PUSHARG -6
	PUSH 2501
	PUSH 0
	PUSH 4
	PUSH 22001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -7
	PUSHARG -6
	PUSH 45
	ADD
	PUSH 2501
	PUSH 0
	PUSH 4
	PUSH 22001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -7
	PUSHARG -6
	PUSH 45
	ADD
	PUSH 2501
	PUSH 0
	PUSH 4
	PUSH 22001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -7
	PUSH 54
	ADD
	PUSHARG -6
	PUSH 45
	ADD
	PUSH 2501
	PUSH 0
	PUSH 4
	PUSH 22001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -7
	PUSH 54
	ADD
	PUSHARG -6
	PUSH 45
	SUB
	PUSH 2501
	PUSH 0
	PUSH 4
	PUSH 22001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -7
	PUSH 54
	SUB
	PUSHARG -6
	PUSH 45
	ADD
	PUSH 2501
	PUSH 0
	PUSH 4
	PUSH 22001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -7
	PUSH 54
	SUB
	PUSHARG -6
	PUSH 45
	SUB
	PUSH 2501
	PUSH 0
	PUSH 4
	PUSH 22001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSH 35
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 6

}}

void function CreateFogSpeed (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 1
	PUSH 1
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -6
	PUSHARG -5
	PUSH 0
	PUSH 0
	PUSH 32001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 0
	PUSHARG -4
	PUSHARG -3
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 1024
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG -2
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 5

}}

void function Ice (arg_0) {
__asm{
LOC_1E524:
	STACK 9
	PUSH 1
	SETARG 31
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\022\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 0
	POPN 4
LOC_1E680:
	PUSHARG 4
	PUSHARG -2
	PUSH 1
	ADD
	CMPL
	JZ LOC_1F198
	PUSHARG 4
	PUSHARG -2
	CMP
	JZ LOC_1E6F4
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	JMP LOC_1E71C
LOC_1E6F4:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 3
LOC_1E71C:
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_1E748
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_1E748:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 140
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHSTR "m022snd01"
	PUSH 180
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "CreateIce"
	PUSHARG 1
	PUSHARG 2
	PUSH 65536
	PUSH 65536
	PUSH 0
	PUSH 1
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateIce"
	PUSHARG 1
	PUSH 44
	ADD
	PUSHARG 2
	PUSH 12
	ADD
	PUSH 49152
	PUSH 45056
	PUSH 3
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateIce"
	PUSHARG 1
	PUSH 44
	SUB
	PUSHARG 2
	PUSH 10
	ADD
	PUSH 53248
	PUSH 49152
	PUSH 4
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateIce"
	PUSHARG 1
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 2
	PUSH 16
	SUB
	PUSH 49152
	PUSH 36864
	PUSH 6
	PUSH 7
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 1
	PUSH 180
	PUSH 260
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 5
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	JZ LOC_1EA20
	PUSHARG 2
	PUSH 180
	PUSH 240
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 6
	JMP LOC_1EA50
LOC_1EA20:
	PUSHARG 2
	PUSH 180
	PUSH 230
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 6
LOC_1EA50:
	PUSHARG 5
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 8
	PUSHARG 6
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 9
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 8
	PUSHARG 9
	PUSH 5
	PUSH 4
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 7
	PUSHARG 7
	PUSH 0
	CMPG
	JZ LOC_1EBB0
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 8
	PUSHARG 9
	PUSH 5
	PUSH 4
	PUSH 0
	PUSHARG 7
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 3
	PUSHARG 3
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	JZ LOC_1EBB0
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 6
LOC_1EBB0:
	PUSHSTR "m022snd01"
	PUSH 200
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "CreateIce"
	PUSHARG 5
	PUSHARG 6
	PUSH 65536
	PUSH 65536
	PUSH 0
	PUSH 1
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateIce"
	PUSHARG 5
	PUSH 44
	ADD
	PUSHARG 6
	PUSH 12
	ADD
	PUSH 49152
	PUSH 45056
	PUSH 3
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateIce"
	PUSHARG 5
	PUSH 44
	SUB
	PUSHARG 6
	PUSH 10
	ADD
	PUSH 53248
	PUSH 49152
	PUSH 4
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateIce"
	PUSHARG 5
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 6
	PUSH 16
	SUB
	PUSH 49152
	PUSH 36864
	PUSH 6
	PUSH 7
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 1
	PUSH 170
	PUSH 260
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 5
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	JZ LOC_1EE24
	PUSHARG 2
	PUSH 190
	PUSH 230
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 6
	JMP LOC_1EE54
LOC_1EE24:
	PUSHARG 2
	PUSH 190
	PUSH 240
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 6
LOC_1EE54:
	PUSHARG 5
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 8
	PUSHARG 6
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 9
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 8
	PUSHARG 9
	PUSH 5
	PUSH 4
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 7
	PUSHARG 7
	PUSH 0
	CMPG
	JZ LOC_1EFB4
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 8
	PUSHARG 9
	PUSH 5
	PUSH 4
	PUSH 0
	PUSHARG 7
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 3
	PUSHARG 3
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	JZ LOC_1EFB4
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 6
LOC_1EFB4:
	PUSHSTR "m022snd01"
	PUSH 220
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "CreateIce"
	PUSHARG 5
	PUSHARG 6
	PUSH 65536
	PUSH 65536
	PUSH 0
	PUSH 1
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateIce"
	PUSHARG 5
	PUSH 44
	ADD
	PUSHARG 6
	PUSH 12
	ADD
	PUSH 49152
	PUSH 45056
	PUSH 3
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateIce"
	PUSHARG 5
	PUSH 44
	SUB
	PUSHARG 6
	PUSH 10
	ADD
	PUSH 53248
	PUSH 49152
	PUSH 4
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateIce"
	PUSHARG 5
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 6
	PUSH 16
	SUB
	PUSH 49152
	PUSH 36864
	PUSH 6
	PUSH 7
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSH 30
	DELAY
	INCN 4
	JMP LOC_1E680
LOC_1F198:
	PUSHSTR "CreateIce"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function OnFireCallback (arg_0, arg_1) callsign 23001 {
__asm{
	STACK 2
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	PUSHARG -2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	ORZ
	JZ LOC_1F314
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 2
	PUSHARG 2
	INST_4F 32
	JZ LOC_1F278
	INST_09 34
	PUSHARG 2
	INST_4F 32
	DIV
	POPN 1
LOC_1F278:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_1F30C
	PUSHARG 2
	INST_4F 32
	PUSH 2
	MUL
	PUSHARG 2
	INST_52 32
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_1F30C:
	JMP LOC_1F360
LOC_1F314:
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_1F360:
	RETN 2

}}

void function CreateOnFireSmoke (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7) {
__asm{
	STACK 1
	PUSHARG -9
	PUSHARG -8
	PUSHARG -7
	PUSH 0
	PUSH 33002
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_1F3F4
	PUSHARG 1
	PUSH 8192
	PUSH 16384
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	JMP LOC_1F418
LOC_1F3F4:
	PUSHARG 1
	PUSH 53248
	PUSH 53248
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_1F418:
	PUSHARG 1
	PUSH 0
	PUSHARG -4
	PUSHARG -5
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 2
	DELAY
	PUSHARG 1
	PUSHARG -3
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_1F4A0
	PUSH 12
	DELAY
	JMP LOC_1F4AC
LOC_1F4A0:
	PUSH 4
	DELAY
LOC_1F4AC:
	PUSHARG 1
	PUSHARG -6
	PUSH 12
	SUB
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 8

}}

void function CreateOnFireFire (arg_0, arg_1, arg_2) {
__asm{
	STACK 2
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 128
	MUL
	PUSH 33001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 251658240
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 23001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_1F5C8
	PUSHARG 1
	PUSH 0
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	JMP LOC_1F5EC
LOC_1F5C8:
	PUSHARG 1
	PUSH 0
	PUSH 1
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
LOC_1F5EC:
	PUSH 4096
	POPN 2
LOC_1F5FC:
	PUSHARG 2
	PUSH 81920
	CMPLE
	JZ LOC_1F66C
	PUSHARG 1
	PUSHARG 2
	PUSHARG 2
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 2
	DELAY
	PUSHARG 2
	PUSH 4096
	ADD
	POPN 2
	JMP LOC_1F5FC
LOC_1F66C:
	PUSH 150
	DELAY
	PUSHSTR "m023snd01"
	PUSH 128
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 250
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function CreateOnFire (arg_0, arg_1) {
__asm{
	STACK 5
	PUSHSTR "m023snd01"
	PUSH 224
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	POPN 1
LOC_1F724:
	PUSHARG 1
	PUSH 80
	CMPL
	JZ LOC_1F85C
	PUSHSTR "CreateOnFireSmoke"
	PUSHARG -3
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 0
	PUSH 64
	PUSH 80
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 50
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 512
	PUSH 768
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x313, (9 | (0 << 16)) ; 0x0313 
	PUSH 1
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 1
	JMP LOC_1F724
LOC_1F85C:
	PUSHSTR "m023snd02"
	PUSH 224
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 3
	PUSHSTR "CreateOnFireFire"
	PUSHARG -3
	PUSHARG -2
	PUSHARG 3
	PUSH 0
	CALLBS
	PUSH 0
	POPN 1
LOC_1F8F0:
	PUSHARG 3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_1FADC
	PUSHARG 1
	PUSH 12
	MOD
	PUSH 0
	CMP
	JZ LOC_1FAC0
	PUSH 24
	NEG
	PUSH 24
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 4
	PUSHARG 4
	PUSH 0
	CMPG
	JZ LOC_1F9B8
	PUSH 5
	NEG
	PUSHARG 4
	MUL
	PUSH 2
	DIV
	PUSH 80
	ADD
	POPN 5
	JMP LOC_1F9EC
LOC_1F9B8:
	PUSH 5
	PUSHARG 4
	MUL
	PUSH 2
	DIV
	PUSH 80
	ADD
	POPN 5
LOC_1F9EC:
	PUSHSTR "CreateOnFireSmoke"
	PUSHARG -3
	PUSHARG 4
	ADD
	PUSHARG -2
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 5
	PUSH 48
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 54
	PUSH 74
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 768
	PUSH 1024
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	SYSCALL 0x313, (9 | (0 << 16)) ; 0x0313 
LOC_1FAC0:
	PUSH 1
	DELAY
	INCN 1
	JMP LOC_1F8F0
LOC_1FADC:
	RETN 2

}}

void function TraceOnFire (arg_0) {
__asm{
	PUSHSTR "CreateOnFire"
	INST_45
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_1FB2C
	PUSH 0
	PUSH 0
	INST_52 35
	JMP LOC_1FB44
LOC_1FB2C:
	PUSH 0
	PUSH 1
	INST_52 35
LOC_1FB44:
	RETN 1

}}

void function OnFire (arg_0) {
__asm{
LOC_1FB4C:
	STACK 9
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 3
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 4
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 5
	PUSH 0
	POPN 9
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_1FC24
	PUSH 0
	INST_4F 35
	PUSH 1
	CMP
	JZ LOC_1FBEC
	PUSH 1
	POPN 9
	JMP LOC_1FC1C
LOC_1FBEC:
	PUSH 1
	PUSH 0
	INST_52 35
	PUSH 1
	PUSH 0
	INST_52 32
LOC_1FC1C:
	JMP LOC_1FCAC
LOC_1FC24:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMP
	JZ LOC_1FCAC
	PUSH 1
	INST_4F 35
	PUSH 1
	CMP
	JZ LOC_1FC7C
	PUSH 1
	POPN 9
	JMP LOC_1FCAC
LOC_1FC7C:
	PUSH 1
	PUSH 1
	INST_52 35
	PUSH 1
	PUSH 1
	INST_52 32
LOC_1FCAC:
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	SETARG 34
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\023\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHARG -2
	JCOND 0, LOC_1FD10
	JCOND 1, LOC_1FD28
	POP
	JMP LOC_1FD40
LOC_1FD10:
	PUSH 5
	POPN 6
	JMP LOC_1FD50
LOC_1FD28:
	PUSH 9
	POPN 6
	JMP LOC_1FD50
LOC_1FD40:
	PUSH 13
	POPN 6
LOC_1FD50:
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHARG 3
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 3
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHARG 9
	PUSH 0
	CMP
	JZ LOC_20144
	PUSHARG 3
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHARG 3
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 0
	POPN 8
LOC_1FE88:
	PUSHARG 8
	PUSHARG 6
	CMPL
	JZ LOC_20110
	PUSHARG 5
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 7
	PUSHARG 7
	PUSH 0
	CMP
	JZ LOC_20040
	PUSHARG 4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 4
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	JZ LOC_1FF7C
	PUSHARG 1
	PUSH 40
	PUSH 400
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 1
	JMP LOC_1FFAC
LOC_1FF7C:
	PUSHARG 1
	PUSH 40
	PUSH 400
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 1
LOC_1FFAC:
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	JZ LOC_20008
	PUSHARG 2
	PUSH 30
	PUSH 300
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	JMP LOC_20038
LOC_20008:
	PUSHARG 2
	PUSH 30
	PUSH 300
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 2
LOC_20038:
	JMP LOC_20078
LOC_20040:
	PUSHARG 7
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 7
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
LOC_20078:
	PUSHARG 8
	PUSH 0
	CMP
	JZ LOC_200B4
	PUSHARG 1
	PUSH 200
	PUSH 30
	CALL MoveCamera
LOC_200B4:
	PUSHSTR "CreateOnFire"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 8
	JMP LOC_1FE88
LOC_20110:
	PUSHSTR "TraceOnFire"
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	JMP LOC_20198
LOC_20144:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_20180
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	CALL CastFail
	JMP LOC_20198
LOC_20180:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 128
	CALL CastFail
LOC_20198:
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function ProduceBackSoldier (arg_0, arg_1) {
__asm{
	STACK 7
	PUSH 0
	POPN 4
	PUSH 0
	POPN 1
	SYSCALL 0x12D, (0 | (1 << 16)) ; GetBattleWidth 
	POPN 6
	SYSCALL 0x12E, (0 | (1 << 16)) ; GetBattleHeight 
	POPN 7
LOC_20220:
	PUSHARG 7
	PUSH 2
	DIV
	POPN 2
LOC_2023C:
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_2029C
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
	JMP LOC_202C0
LOC_2029C:
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
LOC_202C0:
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_203F4
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_20370
	PUSHARG -3
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 2
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
	JMP LOC_203C8
LOC_20370:
	PUSHARG -3
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
LOC_203C8:
	INCN 4
	PUSHARG 4
	PUSHARG -2
	CMPGE
	JZ LOC_203F4
	RETN 2
LOC_203F4:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_2046C
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
	JMP LOC_204A8
LOC_2046C:
	PUSHARG 1
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
LOC_204A8:
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_2060C
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_20570
	PUSHARG -3
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
	JMP LOC_205E0
LOC_20570:
	PUSHARG -3
	PUSHARG 1
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
LOC_205E0:
	INCN 4
	PUSHARG 4
	PUSHARG -2
	CMPGE
	JZ LOC_2060C
	RETN 2
LOC_2060C:
	DECN 2
	PUSHARG 2
	PUSH 0
	CMPG
	JNZ LOC_2023C
	INCN 1
	PUSHARG 1
	PUSHARG 6
	CMPLE
	JNZ LOC_20220
	RETN 2

}}

void function BackSoldier (arg_0, arg_1) {
__asm{
LOC_2065C:
	STACK 8
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\024\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 1
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 1
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_207A8
	PUSH 0
	POPN 2
	JMP LOC_207B8
LOC_207A8:
	PUSH 128
	POPN 2
LOC_207B8:
	PUSHARG 3
	SYSCALL 0x116, (1 | (1 << 16)) ; GetMajorLevel 
	POPN 6
	PUSHARG 6
	PUSH 40
	CMPG
	JZ LOC_20800
	PUSH 40
	POPN 6
LOC_20800:
	PUSHARG 6
	PUSH 5
	MUL
	PUSHARG 3
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	SUB
	POPN 7
	PUSHARG 7
	PUSH 0
	CMPL
	JZ LOC_20860
	PUSH 0
	POPN 7
LOC_20860:
	PUSHARG 7
	PUSHARG -3
	CMPG
	JZ LOC_2088C
	PUSHARG -3
	POPN 7
LOC_2088C:
	PUSHARG 7
	PUSH 0
	CMPZ
	JZ LOC_20A78
	PUSHSTR "ProduceBackSoldier"
	PUSHARG 3
	PUSHARG 7
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG 1
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 24
	DELAY
	PUSHARG 1
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 6
	DELAY
	PUSHSTR "m002snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "m002snd03"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_209C8
	PUSHSTR "MoveCamera"
	PUSH 6576
	PUSH 0
	PUSH 40
	PUSH 0
	CALLBS
	JMP LOC_209F4
LOC_209C8:
	PUSHSTR "MoveCamera"
	PUSH 240
	PUSH 0
	PUSH 40
	PUSH 0
	CALLBS
LOC_209F4:
	PUSHSTR "MoveCamera"
	INST_45
	PUSH 100
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	PUSH 20
	CALL MoveCamera
	JMP LOC_20A90
LOC_20A78:
	PUSHARG 1
	PUSHARG 2
	CALL CastFail
LOC_20A90:
	PUSH 8
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 2

}}

void function TaiChiCallback (arg_0, arg_1) callsign 25001 {
__asm{
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_20B74
	INST_09 37
	PUSH 4
	CMPL
	JZ LOC_20B50
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 37
	DIV
	CALL Hurt
	INST_09 37
	PUSH 2
	MUL
	SETARG 37
	JMP LOC_20B6C
LOC_20B50:
	PUSHARG -3
	PUSH 16777216
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
LOC_20B6C:
	JMP LOC_20B94
LOC_20B74:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_20B94:
	RETN 2

}}

void function CreateTaiChiBomb (arg_0, arg_1) {
__asm{
	STACK 3
	PUSH 8
	DELAY
	PUSHARG -3
	PUSH 35002
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 4096
	PUSH 4096
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -2
	JZ LOC_20C5C
	PUSHARG 1
	PUSH 25001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
LOC_20C5C:
	PUSHARG 1
	PUSH 4096
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSH 20
	DELAY
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 3
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	ADD
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	SUB
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 50
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 50
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	ADD
	PUSHARG 3
	PUSH 50
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	ADD
	PUSHARG 3
	PUSH 50
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	SUB
	PUSHARG 3
	PUSH 50
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	SUB
	PUSHARG 3
	PUSH 50
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	ADD
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	SUB
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 100
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 100
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	ADD
	PUSHARG 3
	PUSH 100
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	ADD
	PUSHARG 3
	PUSH 100
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	SUB
	PUSHARG 3
	PUSH 100
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	SUB
	PUSHARG 3
	PUSH 100
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 150
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 25001
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSH 20
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function CreateTaichi (arg_0, arg_1) {
__asm{
	STACK 3
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 35001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 2
	SYSCALL 0x31, (2 | (0 << 16)) ; 0x0031 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 0
	POPN 2
LOC_214D4:
	PUSHARG 2
	PUSH 16
	CMPLE
	JZ LOC_21528
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_214D4
LOC_21528:
	PUSHSTR "m025snd01"
	PUSH 220
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	POPN 2
LOC_21554:
	PUSHARG 2
	PUSH 3
	CMPL
	JZ LOC_215D0
	PUSHSTR "CreateTaiChiBomb"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	CMP
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 10
	PUSHARG 2
	SUB
	DELAY
	INCN 2
	JMP LOC_21554
LOC_215D0:
	PUSH 30
	DELAY
	PUSH 16
	POPN 2
LOC_215EC:
	PUSHARG 2
	PUSH 0
	CMPGE
	JZ LOC_21640
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	DECN 2
	JMP LOC_215EC
LOC_21640:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function TaiChi (arg_0) {
__asm{
LOC_2165C:
	STACK 15
	PUSH 1
	SETARG 37
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\025\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 0
	POPN 4
LOC_217B8:
	PUSHARG 4
	PUSHARG -2
	PUSH 1
	ADD
	CMPL
	JZ LOC_21FBC
	PUSH 0
	POPN 5
LOC_217F0:
	PUSHARG 5
	PUSH 3
	CMPL
	JZ LOC_21FA0
	PUSHARG 5
	PUSH 0
	CMP
	JZ LOC_21908
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_2187C
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_2187C:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 6
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 7
	PUSHARG 6
	POPN 1
	PUSHARG 7
	POPN 2
	PUSHARG 6
	PUSHARG 7
	PUSH 300
	SUB
	PUSH 40
	CALL MoveCamera
	JMP LOC_21F44
LOC_21908:
	PUSHARG 5
	PUSH 1
	CMP
	JZ LOC_21C38
	PUSHARG 6
	PUSH 200
	PUSH 260
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 1
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	JZ LOC_219B0
	PUSHARG 7
	PUSH 220
	PUSH 270
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	JMP LOC_219E0
LOC_219B0:
	PUSHARG 7
	PUSH 220
	PUSH 270
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 2
LOC_219E0:
	PUSHARG 1
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 9
	PUSHARG 2
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 10
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMPG
	JZ LOC_21C30
	PUSH 0
	POPN 12
LOC_21A8C:
	PUSHARG 12
	PUSHARG 8
	PUSH 2
	DIV
	CMPL
	JZ LOC_21C30
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	PUSH 0
	PUSHARG 8
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 11
	PUSHARG 11
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	JZ LOC_21C20
	PUSHARG 11
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 13
	PUSHARG 11
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 14
	PUSHARG 13
	PUSHARG 6
	SUB
	PUSHARG 13
	PUSHARG 6
	SUB
	MUL
	PUSHARG 14
	PUSHARG 7
	SUB
	PUSHARG 14
	PUSHARG 7
	SUB
	MUL
	ADD
	POPN 15
	PUSHARG 15
	PUSH 72200
	CMPGE
	JZ LOC_21C20
	PUSHARG 13
	POPN 1
	PUSHARG 14
	POPN 2
	JMP LOC_21C30
LOC_21C20:
	INCN 12
	JMP LOC_21A8C
LOC_21C30:
	JMP LOC_21F44
LOC_21C38:
	PUSHARG 6
	PUSH 200
	PUSH 260
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 1
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	JZ LOC_21CC4
	PUSHARG 7
	PUSH 220
	PUSH 270
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	JMP LOC_21CF4
LOC_21CC4:
	PUSHARG 7
	PUSH 220
	PUSH 270
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 2
LOC_21CF4:
	PUSHARG 1
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 9
	PUSHARG 2
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 10
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMPG
	JZ LOC_21F44
	PUSH 0
	POPN 12
LOC_21DA0:
	PUSHARG 12
	PUSHARG 8
	PUSH 2
	DIV
	CMPL
	JZ LOC_21F44
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	PUSH 0
	PUSHARG 8
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 11
	PUSHARG 11
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	JZ LOC_21F34
	PUSHARG 11
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 13
	PUSHARG 11
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 14
	PUSHARG 13
	PUSHARG 6
	SUB
	PUSHARG 13
	PUSHARG 6
	SUB
	MUL
	PUSHARG 14
	PUSHARG 7
	SUB
	PUSHARG 14
	PUSHARG 7
	SUB
	MUL
	ADD
	POPN 15
	PUSHARG 15
	PUSH 72200
	CMPGE
	JZ LOC_21F34
	PUSHARG 13
	POPN 1
	PUSHARG 14
	POPN 2
	JMP LOC_21F44
LOC_21F34:
	INCN 12
	JMP LOC_21DA0
LOC_21F44:
	PUSHSTR "CreateTaichi"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 8
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 5
	JMP LOC_217F0
LOC_21FA0:
	PUSH 45
	DELAY
	INCN 4
	JMP LOC_217B8
LOC_21FBC:
	PUSHSTR "CreateTaichi"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function SpoutCallback (arg_0) callsign 26001 {
__asm{
	STACK 4
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_22090
	INST_09 38
	PUSH 4
	CMPL
	JZ LOC_22088
	PUSH 0
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 38
	DIV
	CALL Hurt
	INST_09 38
	PUSH 2
	MUL
	SETARG 38
LOC_22088:
	RETN 1
LOC_22090:
	PUSHARG -2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSH 16
	SUB
	POPN 3
	PUSHARG -2
	SYSCALL 0x134, (1 | (1 << 16)) ; KillSoldier 
	POP
	PUSHARG -2
	PUSH 65536
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -2
	PUSH 0
	PUSH 8
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
LOC_2212C:
	PUSHARG -2
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 1
	PUSHARG -2
	PUSHARG 2
	PUSH 12
	NEG
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 3
	PUSH 9
	NEG
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 1
	PUSH 3
	NEG
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSH 1
	DELAY
	PUSHARG 1
	PUSH 240
	CMPG
	JZ LOC_22210
	JMP LOC_22248
LOC_22210:
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	ZERO
	JZ LOC_22238
	JMP LOC_22248
LOC_22238:
	PUSH 1
	JNZ LOC_2212C
LOC_22248:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 1

}}

void function SpoutKillEdge (arg_0, arg_1) {
__asm{
	STACK 5
	PUSHARG -3
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN -3
	PUSHARG -2
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN -2
	PUSHARG -3
	PUSH 1
	ADD
	PUSHARG -2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	PUSH 0
	SETNR 1
	PUSHARG -3
	PUSHARG -2
	PUSH 1
	ADD
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	PUSH 1
	SETNR 1
	PUSHARG -3
	PUSH 1
	SUB
	PUSHARG -2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	PUSH 2
	SETNR 1
	PUSHARG -3
	PUSHARG -2
	PUSH 1
	SUB
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	PUSH 3
	SETNR 1
	PUSH 0
	POPN 5
LOC_22394:
	PUSHARG 5
	PUSH 4
	CMPL
	JZ LOC_22484
	PUSHARG 5
	PUSHNR 1
	JZ LOC_22474
	PUSHARG 5
	PUSHNR 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	PUSHARG 5
	PUSHNR 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	ORZ
	JZ LOC_2242C
	PUSH 0
	PUSHARG 5
	SETNR 1
	JMP LOC_22474
LOC_2242C:
	PUSHARG 5
	PUSHNR 1
	SYSCALL 0x115, (1 | (1 << 16)) ; GetSoldierSide 
	PUSHINV 5 ; INTV_IS_RIGHT
	CMP
	JZ LOC_22474
	PUSH 0
	PUSHARG 5
	SETNR 1
LOC_22474:
	INCN 5
	JMP LOC_22394
LOC_22484:
	PUSH 0
	POPN 5
LOC_22494:
	PUSHARG 5
	PUSH 4
	CMPL
	JZ LOC_22538
	PUSHARG 5
	PUSHNR 1
	PUSH 0
	CMPZ
	JZ LOC_22528
	PUSHARG 5
	PUSHNR 1
	PUSHARG 5
	PUSH 64
	MUL
	PUSH 10
	PUSH 36
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 8
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
LOC_22528:
	INCN 5
	JMP LOC_22494
LOC_22538:
	PUSH 2
	DELAY
	PUSH 0
	POPN 5
LOC_22554:
	PUSHARG 5
	PUSH 4
	CMPL
	JZ LOC_225C4
	PUSHARG 5
	PUSHNR 1
	PUSH 0
	CMPZ
	JZ LOC_225B4
	PUSHARG 5
	PUSHNR 1
	SYSCALL 0x134, (1 | (1 << 16)) ; KillSoldier 
	POP
LOC_225B4:
	INCN 5
	JMP LOC_22554
LOC_225C4:
	RETN 2

}}

void function TraceStoneBomb (arg_0) {
__asm{
	PUSH 4
	DELAY
	PUSHARG -2
	PUSH 16384
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSH 6
	DELAY
	PUSHARG -2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 1

}}

void function CreateStoneBomb (arg_0, arg_1) {
__asm{
	STACK 4
	PUSH 0
	POPN 2
LOC_22644:
	PUSHARG 2
	PUSH 10
	CMPL
	JZ LOC_2281C
	PUSHARG -3
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -2
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 0
	PUSH 0
	PUSH 36002
	PUSH 36003
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 10240
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
	PUSH 32768
	PUSH 49152
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 4
	PUSHARG 1
	PUSHARG 4
	PUSHARG 4
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG 3
	PUSH 32
	PUSH 50
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 6
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHSTR "TraceStoneBomb"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 2
	JMP LOC_22644
LOC_2281C:
	RETN 2

}}

void function CreateSpout (arg_0, arg_1, arg_2) {
__asm{
	STACK 6
	PUSHSTR "CreateStoneBomb"
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 4
	DELAY
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 36012
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 5
	PUSHARG 5
	PUSH 65536
	PUSH 49152
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 36013
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 6
	PUSHARG 6
	PUSH 65536
	PUSH 49152
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -2
	JZ LOC_2296C
	PUSHSTR "MoveCamera"
	PUSHARG -4
	PUSHARG -3
	PUSH 240
	SUB
	PUSH 5
	PUSH 0
	CALLBS
LOC_2296C:
	PUSH 0
	POPN 2
LOC_2297C:
	PUSHARG 2
	PUSH 4
	CMPL
	JZ LOC_22A64
	PUSHARG 6
	PUSH 0
	PUSH 0
	PUSH 56
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 36005
	PUSHARG 2
	PUSH 2
	MUL
	ADD
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 2
	PUSH 3
	CMPL
	JZ LOC_22A54
	PUSH 1
	DELAY
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_22A54:
	INCN 2
	JMP LOC_2297C
LOC_22A64:
	PUSH 73728
	POPN 2
LOC_22A74:
	PUSHARG 2
	PUSH 131072
	CMPLE
	JZ LOC_22B10
	PUSHARG 6
	PUSH 0
	PUSH 0
	PUSH 28
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 1
	PUSH 65536
	PUSHARG 2
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	PUSHARG 2
	PUSH 8192
	ADD
	POPN 2
	JMP LOC_22A74
LOC_22B10:
	PUSH 24
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	PUSH 4096
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG 5
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 5
	PUSH 4096
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG 6
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 6
	PUSH 4096
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	RETN 3

}}

void function CreateSpoutAround (arg_0, arg_1, arg_2) {
__asm{
LOC_22BE4:
	STACK 52
	PUSHSTR "m026snd01"
	PUSH 200
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -4
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 1
	PUSHARG -3
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 1
	PUSHARG 2
	PUSH 4
	PUSH 2
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 6
	PUSH 0
	POPN 5
	PUSH 0
	POPN 4
LOC_22CA8:
	PUSHARG 4
	PUSHARG 6
	CMPL
	JZ LOC_22D58
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 1
	PUSHARG 2
	PUSH 4
	PUSH 2
	PUSHARG 4
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	PUSHARG 5
	SETNR 7
	PUSHARG 4
	PUSHNR 7
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	JZ LOC_22D48
	INCN 5
LOC_22D48:
	INCN 4
	JMP LOC_22CA8
LOC_22D58:
	PUSHARG 5
	POPN 6
	PUSH 0
	POPN 4
LOC_22D78:
	PUSHARG 4
	PUSHARG 6
	CMPL
	JZ LOC_22E24
	PUSH 0
	PUSHARG 6
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 52
	PUSHARG 4
	PUSHNR 7
	POPN 3
	PUSHARG 52
	PUSHNR 7
	PUSHARG 4
	SETNR 7
	PUSHARG 3
	PUSHARG 52
	SETNR 7
	INCN 4
	JMP LOC_22D78
LOC_22E24:
	PUSH 0
	POPN 4
LOC_22E34:
	PUSHARG 4
	PUSHARG -2
	CMPL
	JZ LOC_23030
	PUSH 4
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 6
	PUSH 0
	CMPG
	JZ LOC_22F8C
	PUSHARG 4
	PUSHNR 7
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 4
	PUSHNR 7
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHSTR "SpoutKillEdge"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "SpoutCallback"
	PUSHARG 4
	PUSHNR 7
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "m026snd01"
	PUSH 230
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "CreateSpout"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	DECN 6
	JMP LOC_23020
LOC_22F8C:
	PUSHARG -4
	PUSH 432
	NEG
	PUSH 432
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 1
	PUSHARG -3
	PUSH 187
	NEG
	PUSH 187
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	PUSHSTR "CreateSpout"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
LOC_23020:
	INCN 4
	JMP LOC_22E34
LOC_23030:
	RETN 3

}}

void function Spout (arg_0) {
__asm{
LOC_23038:
	STACK 4
	PUSH 1
	SETARG 38
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\026\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 0
	POPN 3
LOC_23194:
	PUSHARG 3
	PUSH 3
	CMPL
	JZ LOC_23374
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 4
	PUSHARG 4
	JZ LOC_23280
	PUSHARG 4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 4
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHSTR "SpoutKillEdge"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "SpoutCallback"
	PUSHARG 4
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	JMP LOC_23300
LOC_23280:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSH 200
	NEG
	PUSH 200
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSH 150
	NEG
	PUSH 150
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
LOC_23300:
	PUSHSTR "CreateSpout"
	PUSHARG 1
	PUSHARG 2
	PUSH 1
	PUSH 0
	CALLBS
	PUSHARG 1
	PUSHARG 2
	PUSHARG -2
	PUSH 2
	MUL
	CALL CreateSpoutAround
	PUSH 40
	DELAY
	INCN 3
	JMP LOC_23194
LOC_23374:
	PUSHSTR "CreateSpout"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function FireCowCallback (arg_0, arg_1) callsign 27001 {
__asm{
	STACK 3
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_234FC
	PUSHARG -3
	PUSH 2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -3
	PUSH 1
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 3
	PUSHARG 3
	INST_4F 39
	JZ LOC_23460
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	PUSHARG 3
	INST_4F 39
	DIV
	POPN 2
LOC_23460:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 2
	CALL Hurt
	PUSHARG 2
	PUSH 0
	CMPG
	JZ LOC_234F4
	PUSHARG 3
	INST_4F 39
	PUSH 2
	MUL
	PUSHARG 3
	INST_52 39
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_234F4:
	JMP LOC_23574
LOC_234FC:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
	PUSHSTR "Blood"
	PUSHARG -2
	PUSH 16
	PUSH 0
	PUSH 0
	CALLBS
LOC_23574:
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 1
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPLE
	JZ LOC_235E8
	PUSHARG -3
	PUSH 2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_2360C
LOC_235E8:
	PUSHARG -3
	PUSH 0
	PUSHARG 1
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
LOC_2360C:
	RETN 2

}}

void function AttachFireToCow (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -3
	PUSH 37002
	PUSHARG -2
	PUSH 50
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 131072
	PUSH 131072
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 12
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHARG -3
	PUSH 37002
	PUSHARG -2
	PUSH 50
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSH 131072
	PUSH 131072
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 2
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 12
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
LOC_2373C:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_23898
	PUSHARG 1
	PUSHARG -3
	PUSHARG -2
	PUSH 24
	PUSH 50
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 2
	PUSHARG -3
	PUSHARG -2
	PUSH 128
	SUB
	PUSH 20
	PUSH 50
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 2
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSH 1
	DELAY
	JMP LOC_2373C
LOC_23898:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function CreateFireCow (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 3
	PUSHARG -6
	PUSH 8
	PUSH 6
	NEG
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	ADD
	PUSHARG -5
	PUSH 8
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	ADD
	PUSH 0
	PUSHARG -4
	PUSH 37001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSH 8
	PUSH 2
	NEG
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 27001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 0
	PUSH 8
	PUSH 2
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_23A90
	PUSHARG 1
	PUSH 1
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	JMP LOC_23AB4
LOC_23A90:
	PUSHARG 1
	PUSH 1
	PUSH 1
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
LOC_23AB4:
	PUSHSTR "AttachFireToCow"
	PUSHARG 1
	PUSHARG -4
	PUSH 128
	ADD
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG -2
	JZ LOC_23B40
	PUSHSTR "LockCameraLine"
	PUSHARG 1
	PUSH 3
	PUSHARG -2
	SUB
	PUSH 80
	MUL
	PUSHARG -3
	PUSH 280
	CALLBS
LOC_23B40:
	PUSH 1
	POPN 3
LOC_23B50:
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_23CD4
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_23BF8
	PUSHARG 2
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	CMPGE
	JZ LOC_23BF0
	PUSHARG 1
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_23CD4
LOC_23BF0:
	JMP LOC_23C40
LOC_23BF8:
	PUSHARG 2
	PUSH 0
	CMPLE
	JZ LOC_23C40
	PUSHARG 1
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_23CD4
LOC_23C40:
	PUSH 1
	DELAY
	INCN 3
	PUSHARG 3
	PUSH 7
	AND
	PUSH 0
	CMP
	JZ LOC_23CCC
	PUSHARG 1
	PUSH 0
	PUSH 8
	PUSH 3
	NEG
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_23CCC:
	JMP LOC_23B50
LOC_23CD4:
	RETN 5

}}

void function FireCow (arg_0) {
__asm{
LOC_23CDC:
	STACK 5
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_23D20
	PUSH 1
	PUSH 0
	INST_52 39
	JMP LOC_23D38
LOC_23D20:
	PUSH 1
	PUSH 1
	INST_52 39
LOC_23D38:
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\027\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 10
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_23EC0
	PUSH 1
	NEG
	POPN 4
	PUSH 0
	POPN 3
	JMP LOC_23EE0
LOC_23EC0:
	PUSH 1
	POPN 4
	PUSH 128
	POPN 3
LOC_23EE0:
	PUSHINV 5 ; INTV_IS_RIGHT
	CALL GetSoldierMaxX
	POPN 5
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_23F44
	PUSHARG 5
	PUSH 320
	SUB
	PUSH 0
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	JMP LOC_23F6C
LOC_23F44:
	PUSHARG 5
	PUSH 320
	ADD
	PUSH 0
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
LOC_23F6C:
	PUSH 15
	DELAY
	PUSHSTR "m027snd01"
	PUSH 180
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "m027snd02"
	PUSH 180
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_24160
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 75
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 75
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 225
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSHARG -2
	PUSH 1
	ADD
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 225
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_24784
LOC_24160:
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_24424
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 350
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 250
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 150
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSHARG -2
	PUSH 1
	ADD
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 150
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 250
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 350
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_24784
LOC_24424:
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 400
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 300
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 200
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 100
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSHARG -2
	PUSH 1
	ADD
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 100
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 200
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 300
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "CreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 400
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_24784:
	PUSH 110
	PUSH 160
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHSTR "m027snd02"
	PUSH 210
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 10
	DELAY
	PUSHSTR "m027snd01"
	PUSH 160
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "LockCameraLine"
	INST_45
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	PUSH 20
	CALL MoveCamera
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function RollDownCallback (arg_0, arg_1) callsign 28001 {
__asm{
	STACK 9
	PUSHARG -3
	PUSH 1
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 2
	PUSHARG -3
	PUSH 2
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 3
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_24BAC
	INST_09 41
	JZ LOC_24934
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 41
	DIV
	POPN 9
LOC_24934:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 9
	CALL Hurt
	PUSHARG 9
	PUSH 0
	CMPG
	JZ LOC_2498C
	INST_09 41
	PUSH 2
	MUL
	SETARG 41
LOC_2498C:
	PUSHARG 2
	PUSH 0
	CMP
	JZ LOC_249CC
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN -3
LOC_249CC:
	INST_09 1
	PUSH 0
	CMP
	JZ LOC_24A08
	PUSHSTR "m028snd02"
	PUSH 255
	PUSH 10
	CALL DelayAmbientSound
LOC_24A08:
	PUSH 0
	POPN 8
LOC_24A18:
	PUSHARG 8
	PUSH 3
	CMPL
	JZ LOC_24B44
	PUSHSTR "CreateRollStoneBreak"
	PUSHARG -3
	PUSH 10
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateRollStoneBreak"
	PUSHARG -3
	PUSH 25
	PUSH 35
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateRollStoneBreak"
	PUSHARG -3
	PUSH 40
	PUSH 50
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateRollStoneBreak"
	PUSHARG -3
	PUSH 55
	PUSH 65
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	INCN 8
	JMP LOC_24A18
LOC_24B44:
	PUSHARG -3
	PUSH 128
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -3
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSH 4
	DELAY
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2
	JMP LOC_24BCC
LOC_24BAC:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_24BCC:
	PUSHARG 2
	PUSH 0
	CMPZ
	JZ LOC_24E68
	PUSHARG -3
	PUSH 1
	SYSCALL 0x20, (2 | (0 << 16)) ; 0x0020 
	PUSHARG 2
	PUSH 1
	SYSCALL 0x20, (2 | (0 << 16)) ; 0x0020 
	PUSHARG 3
	PUSH 1
	SYSCALL 0x20, (2 | (0 << 16)) ; 0x0020 
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 7
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSHARG 7
	ADD
	POPN 4
	PUSHARG -3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG -3
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 6
	PUSHARG -3
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSHARG 7
	ADD
	POPN 4
	PUSHARG 2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 2
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 6
	PUSHARG 2
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSHARG 7
	ADD
	POPN 4
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 3
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 6
	PUSHARG 3
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSH 1
	DELAY
	PUSHARG -3
	PUSH 0
	SYSCALL 0x20, (2 | (0 << 16)) ; 0x0020 
	PUSHARG 2
	PUSH 0
	SYSCALL 0x20, (2 | (0 << 16)) ; 0x0020 
	PUSHARG 3
	PUSH 0
	SYSCALL 0x20, (2 | (0 << 16)) ; 0x0020 
LOC_24E68:
	PUSHARG 2
	PUSH 0
	CMP
	JZ LOC_24EA8
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN -3
LOC_24EA8:
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 1
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPLE
	JZ LOC_250C8
	INST_09 1
	PUSH 0
	CMP
	JZ LOC_24F2C
	PUSHSTR "m028snd02"
	PUSH 255
	PUSH 10
	CALL DelayAmbientSound
LOC_24F2C:
	PUSH 0
	POPN 8
LOC_24F3C:
	PUSHARG 8
	PUSH 3
	CMPL
	JZ LOC_25068
	PUSHSTR "CreateRollStoneBreak"
	PUSHARG -3
	PUSH 10
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateRollStoneBreak"
	PUSHARG -3
	PUSH 25
	PUSH 35
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateRollStoneBreak"
	PUSHARG -3
	PUSH 40
	PUSH 50
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateRollStoneBreak"
	PUSHARG -3
	PUSH 55
	PUSH 65
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	INCN 8
	JMP LOC_24F3C
LOC_25068:
	PUSHARG -3
	PUSH 128
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -3
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSH 4
	DELAY
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	JMP LOC_250EC
LOC_250C8:
	PUSHARG -3
	PUSH 0
	PUSHARG 1
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
LOC_250EC:
	RETN 2

}}

void function CreateRollStoneBreak (arg_0, arg_1) {
__asm{
	STACK 2
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
	PUSHARG -3
	PUSH 38002
	PUSH 38008
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG 2
	PUSHARG -2
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 18432
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHARG 1
	PUSHARG -3
	PUSHARG 2
	PUSH 12
	PUSHARG -2
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSHARG 2
	PUSH 38
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 6
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 8
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function CreateRollStone (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSHARG -4
	PUSH 96
	ADD
	PUSHARG -3
	PUSH 8
	ADD
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 3
	PUSHARG 3
	PUSH 192
	PUSH 0
	PUSHARG -2
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 3
	PUSH 50331648
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 3
	PUSH 28001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 3
	PUSH 0
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 3
	PUSH 1
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 3
	PUSH 2
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG -4
	PUSH 96
	SUB
	PUSHARG -3
	PUSH 8
	ADD
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 2
	PUSHARG 2
	PUSH 192
	PUSH 0
	PUSHARG -2
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 2
	PUSH 50331648
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 28001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 2
	PUSH 0
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 2
	PUSH 1
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 2
	PUSH 2
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 38001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 192
	PUSH 0
	PUSHARG -2
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 49152
	PUSH 49152
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 50331648
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 28001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 0
	PUSH 8
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 1
	PUSH 1
	PUSHARG 2
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 1
	PUSH 2
	PUSHARG 3
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 2
	PUSH 0
	PUSHARG 1
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 3
	PUSH 0
	PUSHARG 1
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
LOC_2560C:
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSH 0
	CMPG
	JZ LOC_25648
	PUSH 2
	DELAY
	JMP LOC_2560C
LOC_25648:
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function TracingCamera (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 4
	PUSHARG -3
	DELAY
	PUSHARG -6
	SYSCALL 0x133, (0 | (1 << 16)) ; 0x0133 
	PUSH 100
	SUB
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG -5
	PUSH 400
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSHARG -4
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_25808
LOC_25778:
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSH 2
	DELAY
	PUSHARG 3
	PUSHARG 4
	PUSH 240
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 3
	PUSHARG -5
	CMPL
	JNZ LOC_25778
	JMP LOC_25890
LOC_25808:
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSH 2
	DELAY
	PUSHARG 3
	PUSHARG 4
	PUSH 240
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 3
	PUSHARG -5
	CMPG
	JNZ LOC_25808
LOC_25890:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 5

}}

void function RollDown (arg_0) {
__asm{
LOC_258C0:
	STACK 9
	PUSH 0
	SETARG 1
	PUSH 1
	SETARG 41
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\028\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG -2
	JCOND 0, LOC_25A48
	JCOND 1, LOC_25A70
	POP
	JMP LOC_25A98
LOC_25A48:
	PUSH 12
	POPN 8
	PUSH 8
	POPN 9
	JMP LOC_25AB8
LOC_25A70:
	PUSH 14
	POPN 8
	PUSH 8
	POPN 9
	JMP LOC_25AB8
LOC_25A98:
	PUSH 16
	POPN 8
	PUSH 8
	POPN 9
LOC_25AB8:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_25B0C
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_25B0C:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_25BD0
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSHARG -2
	PUSH 1
	ADD
	PUSH 250
	MUL
	ADD
	PUSH 25
	NEG
	PUSH 25
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 4
	MUL
	ADD
	PUSH 100
	SUB
	PUSH 20
	NEG
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 4
	JMP LOC_25C70
LOC_25BD0:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSHARG -2
	PUSH 1
	ADD
	PUSH 250
	MUL
	SUB
	PUSH 25
	NEG
	PUSH 25
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 4
	MUL
	ADD
	PUSH 100
	ADD
	PUSH 20
	NEG
	PUSH 20
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 4
LOC_25C70:
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG -2
	PUSH 1
	ADD
	PUSH 2
	MUL
	PUSH 1
	ADD
	POPN 7
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_25D5C
	PUSHSTR "TracingCamera"
	PUSHARG 4
	PUSHARG 7
	PUSH 250
	MUL
	SUB
	PUSHARG 4
	PUSHARG -2
	PUSH 1
	ADD
	PUSH 250
	MUL
	SUB
	PUSHARG 8
	PUSH 0
	PUSHINV 5 ; INTV_IS_RIGHT
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_25DD4
LOC_25D5C:
	PUSHSTR "TracingCamera"
	PUSHARG 4
	PUSHARG 7
	PUSH 250
	MUL
	ADD
	PUSHARG 4
	PUSHARG -2
	PUSH 1
	ADD
	PUSH 250
	MUL
	ADD
	PUSHARG 8
	PUSH 0
	PUSHINV 5 ; INTV_IS_RIGHT
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_25DD4:
	PUSH 0
	POPN 6
LOC_25DE4:
	PUSHARG 6
	PUSHARG 7
	CMPL
	JZ LOC_25ED0
	PUSHSTR "m028snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "CreateRollStone"
	PUSHARG 4
	SYSCALL 0x133, (0 | (1 << 16)) ; 0x0133 
	PUSH 200
	ADD
	PUSHARG 9
	PUSH 0
	CALLBS
	PUSH 10
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_25EA4
	PUSHARG 4
	PUSH 250
	SUB
	POPN 4
	JMP LOC_25EC0
LOC_25EA4:
	PUSHARG 4
	PUSH 250
	ADD
	POPN 4
LOC_25EC0:
	INCN 6
	JMP LOC_25DE4
LOC_25ED0:
	PUSHSTR "TracingCamera"
	INST_45
	PUSHSTR "CreateRollStone"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function PaCallback (arg_0, arg_1) callsign 29001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_25FD0
	INST_09 42
	JZ LOC_25F70
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 42
	DIV
	POPN 1
LOC_25F70:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_25FC8
	INST_09 42
	PUSH 2
	MUL
	SETARG 42
LOC_25FC8:
	JMP LOC_25FF0
LOC_25FD0:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_25FF0:
	RETN 2

}}

void function CreatePaBomb (arg_0, arg_1, arg_2) {
__asm{
	STACK 5
	PUSH 0
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	MUL
	DELAY
	PUSHARG -4
	PUSH 39011
	PUSH 0
	PUSH 220
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 4
	PUSHARG 4
	PUSHARG -4
	PUSHARG -2
	PUSHARG -3
	PUSH 220
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 4
	PUSH 4096
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 4
	PUSH 0
	PUSH 20
	NEG
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSH 1
	POPN 5
LOC_260F0:
	PUSHARG 5
	PUSH 10
	CMPLE
	JZ LOC_26170
	PUSH 2
	DELAY
	PUSHARG 4
	PUSH 4096
	PUSH 12288
	PUSH 10
	DIV
	PUSHARG 5
	MUL
	ADD
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	INCN 5
	JMP LOC_260F0
LOC_26170:
	PUSHARG 4
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -4
	PUSH 39002
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -2
	PUSHARG -3
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 4096
	PUSH 4096
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 29001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 4096
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSH 10
	DELAY
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 3
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 20
	ADD
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 8
	PUSH 29001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 20
	ADD
	PUSH 2501
	PUSH 0
	PUSH 8
	PUSH 29001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 20
	SUB
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 8
	PUSH 29001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 20
	SUB
	PUSH 2501
	PUSH 0
	PUSH 8
	PUSH 29001
	PUSH 0
	PUSH 0
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSH 10
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function BigBombCircle (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSH 1
	POPN 2
LOC_2651C:
	PUSHARG 2
	PUSH 32
	CMPL
	JZ LOC_265A8
	PUSHARG 1
	PUSH 65536
	PUSH 6144
	PUSHARG 2
	MUL
	ADD
	PUSH 65536
	PUSH 6144
	PUSHARG 2
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_2651C
LOC_265A8:
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function BigPaBombHurt (arg_0) {
__asm{
	STACK 6
	PUSHARG -2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG -2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSH 0
	POPN 3
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 6
	PUSH 0
	POPN 2
LOC_26658:
	PUSHARG 2
	PUSH 16
	CMPL
	JZ LOC_26764
	PUSHSTR "LockByCenter"
	PUSHARG -2
	PUSH 16018
	PUSHARG 6
	PUSHARG 3
	PUSH 4
	PUSH 33554432
	PUSH 16777216
	ADD
	PUSH 29001
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
	PUSHARG 6
	PUSH 64
	ADD
	PUSH 255
	AND
	POPN 6
	PUSHARG 2
	PUSH 4
	MOD
	PUSH 3
	CMP
	JZ LOC_26754
	PUSHARG 3
	PUSH 40
	ADD
	POPN 3
	PUSHARG 6
	PUSH 32
	ADD
	POPN 6
LOC_26754:
	INCN 2
	JMP LOC_26658
LOC_26764:
	RETN 1

}}

void function CreateBigPaBomb (arg_0) {
__asm{
LOC_2676C:
	STACK 2
	PUSHSTR "m029snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	PUSH 39012
	PUSH 0
	PUSH 220
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 0
	PUSH 20
	NEG
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
LOC_267EC:
	PUSH 1
	DELAY
	PUSHARG 1
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 2
	PUSHARG 2
	PUSH 0
	CMPG
	JNZ LOC_267EC
	PUSHSTR "BigPaBombHurt"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHSTR "BigBombCircle"
	PUSHARG -2
	PUSH 39013
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 10
	DELAY
	PUSHSTR "BigBombCircle"
	PUSHARG -2
	PUSH 39014
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 10
	DELAY
	PUSHSTR "BigBombCircle"
	PUSHARG -2
	PUSH 39013
	PUSH 0
	PUSH 0
	CALLBS
	RETN 1

}}

void function CreateRotateLight (arg_0, arg_1, arg_2, arg_3) {
__asm{
LOC_26924:
	STACK 3
	PUSHARG -5
	PUSH 39016
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 49152
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -5
	PUSH 39017
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSHARG 3
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 3
	PUSH 49152
	PUSH 20480
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 0
	POPN 2
LOC_26A7C:
	PUSHARG 2
	PUSH 128
	CMPL
	JZ LOC_26BBC
	PUSHARG -4
	PUSH 8
	ADD
	PUSH 255
	AND
	POPN -4
	PUSHARG 2
	PUSH 4
	MOD
	PUSH 0
	CMP
	JZ LOC_26B04
	PUSHARG -3
	PUSH 2
	ADD
	POPN -3
LOC_26B04:
	PUSH 1
	DELAY
	PUSHARG 1
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 3
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG -2
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	INCN 2
	JMP LOC_26A7C
LOC_26BBC:
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 3
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 4

}}

void function CreateRotateBomb (arg_0, arg_1, arg_2) {
__asm{
	STACK 2
	PUSHARG -4
	PUSH 39015
	PUSH 0
	PUSH 220
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	PUSH 220
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 49152
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 0
	PUSH 20
	NEG
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
LOC_26CC8:
	PUSH 1
	DELAY
	PUSHARG 1
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 2
	PUSHARG 2
	PUSH 0
	CMPG
	JNZ LOC_26CC8
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL CreateRotateLight
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function CreatePaLight (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
	PUSHARG -5
	PUSHARG -3
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSH 9
	DELAY
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG -5
	PUSHARG -4
	PUSH 128
	PUSH 45
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 0
	PUSH 16
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHSTR "ProduceShadowTime"
	PUSHARG 1
	PUSH 9999
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 18
	DELAY
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 4

}}

void function CreatePa (arg_0, arg_1) {
__asm{
	STACK 11
	PUSHSTR "m029snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 39001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 2
	SYSCALL 0x31, (2 | (0 << 16)) ; 0x0031 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 2
LOC_26F24:
	PUSHARG 2
	PUSH 16
	CMPLE
	JZ LOC_26F78
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_26F24
LOC_26F78:
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSHARG 1
	PUSH 128
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 2
LOC_26FC0:
	PUSHARG 2
	PUSH 8
	CMPL
	JZ LOC_27034
	PUSHARG 1
	PUSH 39003
	PUSHARG 2
	ADD
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	PUSHARG 2
	SETNR 4
	INCN 2
	JMP LOC_26FC0
LOC_27034:
	PUSH 10
	DELAY
	PUSH 0
	POPN 2
LOC_27050:
	PUSHARG 2
	PUSH 4
	CMPL
	JZ LOC_27144
	PUSHSTR "CreatePaLight"
	PUSHARG 1
	PUSH 39003
	PUSHARG 2
	ADD
	PUSH 39015
	PUSHARG 2
	ADD
	PUSHARG 2
	PUSHNR 4
	CALLBS
	PUSHSTR "CreatePaLight"
	PUSHARG 1
	PUSH 39003
	PUSHARG 2
	ADD
	PUSH 4
	ADD
	PUSH 39015
	PUSH 4
	ADD
	PUSHARG 2
	ADD
	PUSHARG 2
	PUSH 4
	ADD
	PUSHNR 4
	CALLBS
	PUSH 4
	DELAY
	INCN 2
	JMP LOC_27050
LOC_27144:
	PUSHSTR "CreatePaLight"
	INST_45
	PUSH 20
	DELAY
	PUSHARG 1
	CALL CreateBigPaBomb
	PUSHSTR "m029snd03"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	POPN 3
LOC_27198:
	PUSHARG 3
	PUSH 6
	CMPL
	JZ LOC_27290
	PUSH 0
	POPN 2
LOC_271C4:
	PUSHARG 2
	PUSH 6
	CMPL
	JZ LOC_27260
	PUSHSTR "CreatePaBomb"
	PUSHARG 1
	PUSH 130
	PUSH 60
	PUSHARG 3
	MUL
	ADD
	PUSH 0
	PUSH 128
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 40
	PUSHARG 2
	MUL
	ADD
	PUSH 0
	CALLBS
	INCN 2
	JMP LOC_271C4
LOC_27260:
	PUSH 1
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 3
	JMP LOC_27198
LOC_27290:
	PUSHSTR "CreatePaBomb"
	INST_45
	PUSH 10
	DELAY
	PUSH 8
	POPN 2
LOC_272B8:
	PUSHARG 2
	PUSH 0
	CMPGE
	JZ LOC_2730C
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 2
	DELAY
	DECN 2
	JMP LOC_272B8
LOC_2730C:
	RETN 2

}}

void function Pa (arg_0) {
__asm{
LOC_27314:
	STACK 3
	PUSH 1
	SETARG 42
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\029\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_274B4
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_274B4:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHSTR "HoldAllDelay"
	PUSH 8
	PUSH 6
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG 1
	PUSHARG 2
	PUSH 160
	SUB
	PUSH 40
	CALL MoveCamera
	PUSHSTR "CreatePa"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreatePa"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function HalfMoonNewCallback (arg_0, arg_1) callsign 30001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_276D0
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	INST_09 43
	JZ LOC_27638
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 43
	DIV
	POPN 1
LOC_27638:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_27690
	INST_09 43
	PUSH 2
	MUL
	SETARG 43
LOC_27690:
	PUSHARG -3
	PUSHARG -2
	PUSH 40003
	PUSH 2
	PUSH 48
	PUSH 0
	CALL HitGeneral
	JMP LOC_2771C
LOC_276D0:
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10016
	PUSH 60
	PUSH 0
	CALLBS
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_2771C:
	RETN 2

}}

void function CheckHalfMoonNew (arg_0, arg_1) {
__asm{
	STACK 1
LOC_2772C:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_2781C
	PUSH 1
	DELAY
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_277DC
	PUSHARG 1
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	PUSH 100
	SUB
	CMPG
	JZ LOC_277D4
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	JMP LOC_2781C
LOC_277D4:
	JMP LOC_27814
LOC_277DC:
	PUSHARG 1
	PUSH 100
	CMPL
	JZ LOC_27814
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	JMP LOC_2781C
LOC_27814:
	JMP LOC_2772C
LOC_2781C:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function HalfMoonNewMotion (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 12
	PUSHARG -5
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG -5
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG -5
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 7
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 3
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 4
	PUSHARG 3
	PUSHARG 1
	SUB
	POPN 9
	PUSHARG 9
	PUSH 0
	CMPL
	JZ LOC_27958
	PUSHARG 9
	NEG
	POPN 9
	PUSHARG 9
	PUSH 512
	CMPL
	JZ LOC_27950
	PUSHARG 1
	PUSH 512
	SUB
	POPN 3
LOC_27950:
	JMP LOC_27990
LOC_27958:
	PUSHARG 9
	PUSH 512
	CMPL
	JZ LOC_27990
	PUSHARG 1
	PUSH 512
	ADD
	POPN 3
LOC_27990:
	PUSHARG 9
	LTOF
	POPN 12
	PUSHARG 12
	PUSH 1124073472
	MULF
	PUSH 1167261696
	DIVF
	POPN 12
	PUSHARG 12
	FTOL
	POPN 10
	PUSH 0
	POPN 8
LOC_279F0:
	PUSHARG 8
	PUSHARG 10
	CMPL
	JZ LOC_27B7C
	PUSHARG 1
	PUSHARG 3
	PUSHARG 1
	SUB
	PUSHARG 8
	MUL
	PUSHARG 10
	DIV
	ADD
	POPN 6
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_27AB8
	PUSHARG 4
	PUSHARG 8
	PUSH 128
	MUL
	PUSHARG 10
	DIV
	PUSHARG -3
	SYSCALL 0x201, (2 | (1 << 16)) ; 0x0201 
	ADD
	POPN 5
	JMP LOC_27B00
LOC_27AB8:
	PUSHARG 4
	PUSHARG 8
	PUSH 128
	MUL
	PUSHARG 10
	DIV
	PUSHARG -3
	SYSCALL 0x201, (2 | (1 << 16)) ; 0x0201 
	SUB
	POPN 5
LOC_27B00:
	PUSHARG -5
	PUSHARG 6
	PUSHARG 5
	PUSHARG 7
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG -4
	PUSHARG -5
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	INCN 8
	JMP LOC_279F0
LOC_27B7C:
	PUSHARG 10
	LTOF
	PUSHARG 12
	CMPZF
	JZ LOC_27BFC
	PUSHARG -5
	PUSHARG 3
	PUSHARG 4
	PUSHARG 7
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG -4
	PUSHARG -5
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
LOC_27BFC:
	PUSHARG -5
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_27DA8
	PUSHARG -5
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSH 128
	POPN 8
LOC_27C4C:
	PUSHARG -5
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_27DA8
	PUSHARG 1
	PUSHARG 3
	PUSHARG 1
	SUB
	PUSHARG 8
	MUL
	PUSH 128
	DIV
	ADD
	POPN 6
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_27CFC
	PUSHARG 4
	PUSHARG 8
	PUSHARG -3
	SYSCALL 0x201, (2 | (1 << 16)) ; 0x0201 
	ADD
	POPN 5
	JMP LOC_27D2C
LOC_27CFC:
	PUSHARG 4
	PUSHARG 8
	PUSHARG -3
	SYSCALL 0x201, (2 | (1 << 16)) ; 0x0201 
	SUB
	POPN 5
LOC_27D2C:
	PUSHARG -5
	PUSHARG 6
	PUSHARG 5
	PUSHARG 7
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG -4
	PUSHARG -5
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	INCN 8
	JMP LOC_27C4C
LOC_27DA8:
	RETN 4

}}

void function GetGeneralWidth () {
__asm{
LOC_27DB0:
	STACK 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	SUB
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPL
	JZ LOC_27E1C
	PUSHARG 1
	NEG
	POPN 1
LOC_27E1C:
	PUSHARG 1
	INST_01 0

}}

void function CreateHalfMoonNew (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5) {
__asm{
	STACK 4
	PUSHARG -7
	PUSH 40001
	PUSHARG -6
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -7
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 30001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 49152
	PUSH 49152
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 40002
	PUSHARG -6
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	CALL GetGeneralWidth
	POPN 4
	PUSHSTR "CheckHalfMoonNew"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG -3
	JZ LOC_27FE8
	PUSHSTR "LockCameraSimple"
	PUSHARG 1
	PUSH 330
	NEG
	PUSH 0
	PUSH 0
	CALLBS
LOC_27FE8:
	PUSHARG 4
	PUSH 1200
	CMPL
	JZ LOC_28054
	PUSHARG 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 30
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	PUSHARG 2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 30
	SYSCALL 0x19, (3 | (0 << 16)) ; 0x0019 
	JMP LOC_28080
LOC_28054:
	PUSHSTR "HalfMoonNewMotion"
	PUSHARG 1
	PUSHARG 2
	PUSHARG -4
	PUSHARG -2
	CALLBS
LOC_28080:
	RETN 6

}}

void function HalfMoonNew (arg_0) {
__asm{
LOC_28088:
	STACK 12
	PUSH 2
	SETARG 43
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\030\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 3
	PUSH 0
	POPN 11
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	CMP
	JZ LOC_28180
	PUSH 0
	PUSH 90
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 11
LOC_28180:
	PUSH 18
	POPN 6
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_281D8
	PUSH 0
	POPN 5
	PUSH 1
	NEG
	POPN 12
	JMP LOC_281F8
LOC_281D8:
	PUSH 128
	POPN 5
	PUSH 1
	POPN 12
LOC_281F8:
	PUSHARG -2
	JCOND 0, LOC_28230
	JCOND 1, LOC_28254
	JCOND 2, LOC_28278
	POP
	JMP LOC_2829C
LOC_28230:
	PUSH 120
	PUSHARG 11
	SUB
	POPN 9
	JMP LOC_2829C
LOC_28254:
	PUSH 210
	PUSHARG 11
	SUB
	POPN 9
	JMP LOC_2829C
LOC_28278:
	PUSH 330
	PUSHARG 11
	SUB
	POPN 9
	JMP LOC_2829C
LOC_2829C:
	PUSHARG 1
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 7
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 8
	PUSHARG 7
	PUSHARG 12
	PUSH 180
	MUL
	SUB
	PUSHARG 8
	PUSHARG 9
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 1
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHARG 1
	PUSH 4096
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG 1
	PUSHSTR "m001snd01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHARG -2
	JZ LOC_2852C
	PUSHSTR "CreateHalfMoonNew"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 5
	PUSH 64
	PUSH 0
	PUSH 1
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateHalfMoonNew"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 5
	PUSH 64
	PUSH 200
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateHalfMoonNew"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 5
	PUSH 64
	PUSH 400
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateHalfMoonNew"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 5
	PUSH 192
	PUSH 200
	PUSH 0
	PUSH 1
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateHalfMoonNew"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 5
	PUSH 192
	PUSH 400
	PUSH 0
	PUSH 1
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	JMP LOC_285F8
LOC_2852C:
	PUSHSTR "CreateHalfMoonNew"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 5
	PUSH 64
	PUSH 0
	PUSH 1
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateHalfMoonNew"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 5
	PUSH 64
	PUSH 200
	PUSH 0
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	PUSHSTR "CreateHalfMoonNew"
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHARG 5
	PUSH 192
	PUSH 200
	PUSH 0
	PUSH 1
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
LOC_285F8:
	PUSH 8
	DELAY
	PUSHSTR "CheckHalfMoonNew"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function FirePillarCallback (arg_0, arg_1) callsign 31001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_28730
	INST_09 44
	JZ LOC_28698
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 44
	DIV
	POPN 1
LOC_28698:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_28728
	INST_09 44
	PUSH 2
	MUL
	SETARG 44
	PUSHARG -3
	PUSHARG -2
	PUSH 11002
	PUSH 1
	PUSH 48
	PUSH 0
	CALL HitGeneral
LOC_28728:
	JMP LOC_2877C
LOC_28730:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_2877C:
	RETN 2

}}

void function CreateFirePillarSource (arg_0, arg_1, arg_2) {
__asm{
	STACK 2
	PUSHARG -4
	PUSH 41001
	PUSH 0
	PUSH 8
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -2
	PUSHARG -3
	PUSH 8
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHSTR "m031snd03"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 8
	DELAY
	PUSHARG -3
	POPN 2
LOC_2882C:
	PUSHARG 2
	PUSH 0
	CMPG
	JZ LOC_288D4
	PUSHARG 1
	PUSHARG -4
	PUSHARG -2
	PUSHARG 2
	PUSH 8
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG -2
	PUSH 1
	ADD
	PUSH 255
	AND
	POPN -2
	PUSHARG 2
	PUSH 4
	SUB
	POPN 2
	JMP LOC_2882C
LOC_288D4:
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function CreateFirePillarLight (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
LOC_28900:
	STACK 3
	PUSHARG -6
	PUSH 41009
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 31001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 32768
	PUSH 24576
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -6
	PUSH 41010
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSHARG 3
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 3
	PUSH 32768
	PUSH 16384
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 0
	POPN 2
LOC_28A74:
	PUSHARG 2
	PUSHARG -2
	CMPL
	JZ LOC_28BFC
	PUSHARG -5
	PUSH 4
	ADD
	PUSH 255
	AND
	POPN -5
	PUSHARG -4
	PUSH 6
	ADD
	POPN -4
	PUSH 1
	DELAY
	PUSHARG 1
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 3
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG -3
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 2
	PUSHARG -2
	PUSH 16
	SUB
	CMP
	JZ LOC_28BEC
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 3
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_28BEC:
	INCN 2
	JMP LOC_28A74
LOC_28BFC:
	RETN 5

}}

void function CreateFirePillarBomb (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 2
	PUSHARG -5
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN -5
	PUSHARG -5
	PUSH 41008
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 32768
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSHARG 1
	PUSHARG -2
	CALL CreateFirePillarLight
	PUSHARG -5
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 4

}}

void function CreateFirePillar (arg_0, arg_1) {
__asm{
LOC_28D3C:
	STACK 6
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
	PUSH 0
	POPN 2
LOC_28DB4:
	PUSHARG 2
	PUSH 4
	CMPL
	JZ LOC_28E34
	PUSHSTR "CreateFirePillarSource"
	PUSHARG 1
	PUSH 320
	PUSHARG 3
	PUSH 0
	CALLBS
	PUSHARG 3
	PUSH 64
	ADD
	PUSH 255
	AND
	POPN 3
	INCN 2
	JMP LOC_28DB4
LOC_28E34:
	PUSHSTR "CreateFirePillarSource"
	INST_45
	PUSH 8
	DELAY
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 2501
	PUSH 0
	PUSH 60
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	ADD
	PUSHARG -2
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	SUB
	PUSHARG -2
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 50
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 50
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	ADD
	PUSHARG -2
	PUSH 50
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	ADD
	PUSHARG -2
	PUSH 50
	SUB
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	SUB
	PUSHARG -2
	PUSH 50
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	SUB
	PUSHARG -2
	PUSH 50
	SUB
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	ADD
	PUSHARG -2
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	SUB
	PUSHARG -2
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 100
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 100
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	ADD
	PUSHARG -2
	PUSH 100
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	ADD
	PUSHARG -2
	PUSH 100
	SUB
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	SUB
	PUSHARG -2
	PUSH 100
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	SUB
	PUSHARG -2
	PUSH 100
	SUB
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 31001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "m031snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	POPN 2
LOC_295C0:
	PUSHARG 2
	PUSH 4
	CMPL
	JZ LOC_2966C
	PUSHARG 1
	PUSH 41002
	PUSHARG 2
	ADD
	PUSH 0
	PUSH 12
	NEG
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 4
	PUSH 4
	DELAY
	PUSHARG 2
	PUSH 3
	CMPL
	JZ LOC_2965C
	PUSHARG 4
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_2965C:
	INCN 2
	JMP LOC_295C0
LOC_2966C:
	PUSH 65536
	POPN 2
LOC_2967C:
	PUSHARG 2
	PUSH 131072
	CMPL
	JZ LOC_296EC
	PUSHARG 4
	PUSH 65536
	PUSHARG 2
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 2
	DELAY
	PUSHARG 2
	PUSH 8192
	ADD
	POPN 2
	JMP LOC_2967C
LOC_296EC:
	PUSH 40
	DELAY
	PUSHSTR "m031snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "CreateFirePillarBomb"
	PUSHARG 4
	PUSH 32
	PUSH 10
	PUSH 68
	CALLBS
	PUSHSTR "CreateFirePillarBomb"
	PUSHARG 4
	PUSH 96
	PUSH 10
	PUSH 68
	CALLBS
	PUSHSTR "CreateFirePillarBomb"
	PUSHARG 4
	PUSH 160
	PUSH 10
	PUSH 68
	CALLBS
	PUSHSTR "CreateFirePillarBomb"
	PUSHARG 4
	PUSH 224
	PUSH 10
	PUSH 68
	CALLBS
	PUSHARG 4
	PUSH 4096
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG 4
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function FirePillar (arg_0) {
__asm{
LOC_29820:
	STACK 3
	PUSH 1
	SETARG 44
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\031\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_299C0
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_299C0:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 140
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHARG 1
	PUSHARG 2
	CALL CreateFirePillar
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function SparkCallback (arg_0, arg_1) callsign 32001 {
__asm{
	STACK 2
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 1
	PUSHARG 1
	PUSH 4660
	CMP
	JZ LOC_29AD4
	PUSH 2
	POPN 2
	JMP LOC_29AE4
LOC_29AD4:
	PUSH 2
	POPN 2
LOC_29AE4:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 2
	CALL Hurt
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 20
	PUSH 0
	CALLBS
	RETN 2

}}

void function DecreaseHP () {
__asm{
	STACK 1
	PUSH 1
	POPN 1
LOC_29B50:
	PUSHARG 1
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	PUSH 4
	SUB
	CMPLE
	JZ LOC_29BB8
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 0
	PUSH 1
	SYSCALL 0x125, (3 | (0 << 16)) ; 0x0125 
	PUSH 4
	DELAY
	INCN 1
	JMP LOC_29B50
LOC_29BB8:
	RETN 0

}}

void function CreateSparkleCenter (arg_0, arg_1) {
__asm{
	STACK 6
	PUSHARG -2
	DELAY
	PUSHARG -3
	PUSH 42001
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 73728
	PUSH 73728
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 1
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 6
	PUSH 60
	PUSH 80
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
	PUSH 0
	POPN 2
LOC_29CB4:
	PUSHARG 2
	PUSHARG 3
	PUSH 4
	DIV
	CMPL
	JZ LOC_29D6C
	PUSH 6
	DELAY
	PUSHARG 1
	PUSHARG 4
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 5
	PUSHARG 6
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	INCN 2
	JMP LOC_29CB4
LOC_29D6C:
	PUSHARG 1
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function CreateSparkle (arg_0) {
__asm{
LOC_29DC4:
	STACK 4
	PUSHSTR "m032snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN -2
	PUSHARG -2
	PUSH 42004
	PUSH 0
	PUSH 48
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 32001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 0
	PUSH 4660
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSH 4
	DELAY
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -2
	PUSH 42002
	PUSH 0
	PUSH 48
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "CreateSparkleCenter"
	PUSHARG 1
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateSparkleCenter"
	PUSHARG 1
	PUSH 20
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateSparkleCenter"
	PUSHARG 1
	PUSH 20
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateSparkleCenter"
	PUSHARG 1
	PUSH 20
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "DecreaseHP"
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "CreateSparkleCenter"
	INST_45
	PUSHSTR "m032snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG 1
	PUSH 42003
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSH 4096
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSH 0
	POPN 4
LOC_2A11C:
	PUSHARG 4
	PUSH 256
	CMPL
	JZ LOC_2A1A8
	PUSHSTR "LockByCenter"
	PUSHARG -2
	PUSH 2501
	PUSHARG 4
	PUSH 52
	PUSH 2
	PUSH 33554432
	PUSH 32001
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
	PUSHARG 4
	PUSH 32
	ADD
	POPN 4
	JMP LOC_2A11C
LOC_2A1A8:
	PUSH 0
	POPN 4
LOC_2A1B8:
	PUSHARG 4
	PUSH 256
	CMPL
	JZ LOC_2A244
	PUSHSTR "LockByCenter"
	PUSHARG -2
	PUSH 2501
	PUSHARG 4
	PUSH 110
	PUSH 2
	PUSH 33554432
	PUSH 32001
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
	PUSHARG 4
	PUSH 32
	ADD
	POPN 4
	JMP LOC_2A1B8
LOC_2A244:
	PUSH 2
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_2A274:
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_2A2A4
	PUSH 1
	DELAY
	JMP LOC_2A274
LOC_2A2A4:
	PUSH 8
	DELAY
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 1

}}

void function Sparkle (arg_0) {
__asm{
LOC_2A2F0:
	STACK 3
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\032\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 5
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 140
	SUB
	PUSH 40
	CALL MoveCamera
	PUSHARG 3
	CALL CreateSparkle
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function FireWorkCallback (arg_0, arg_1) callsign 33001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_2A5EC
	INST_09 45
	JZ LOC_2A554
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 45
	DIV
	POPN 1
LOC_2A554:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_2A5E4
	INST_09 45
	PUSH 2
	MUL
	SETARG 45
	PUSHARG -3
	PUSHARG -2
	PUSH 11002
	PUSH 1
	PUSH 48
	PUSH 0
	CALL HitGeneral
LOC_2A5E4:
	JMP LOC_2A638
LOC_2A5EC:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_2A638:
	RETN 2

}}

void function TraceFlash (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
LOC_2A648:
	PUSH 1
	DELAY
	PUSHARG -4
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPG
	JNZ LOC_2A648
	PUSHARG -3
	JZ LOC_2A7EC
	PUSHARG -4
	PUSH 43003
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG -2
	JZ LOC_2A724
	PUSHARG 2
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 33001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_2A724:
	PUSHARG 2
	PUSH 45056
	PUSH 45056
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 2
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSHARG 3
	PUSH 0
	PUSH 48
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 3
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 3
	PUSH 33001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_2A7EC:
	PUSHARG -4
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSH 26
	DELAY
	PUSHARG 3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG -3
	JZ LOC_2A854
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_2A854:
	RETN 3

}}

void function CreateCannonFlash (arg_0, arg_1) {
__asm{
	STACK 3
	PUSH 0
	POPN 3
LOC_2A874:
	PUSHARG 3
	PUSH 6
	CMPL
	JZ LOC_2AA38
	PUSH 0
	POPN 2
LOC_2A8A0:
	PUSHARG 2
	PUSH 256
	CMPL
	JZ LOC_2AA1C
	PUSHARG -3
	PUSH 43004
	PUSH 0
	PUSH 8
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -3
	PUSHARG 2
	PUSH 64
	PUSH 8
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSHARG 2
	PUSH 44
	PUSH 12
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 16
	PUSHARG 3
	PUSH 2
	MUL
	SUB
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHARG 1
	PUSH 2048
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHSTR "TraceFlash"
	PUSHARG 1
	PUSHARG 3
	PUSH 5
	CMP
	PUSH 1
	PUSH 0
	CALLBS
	PUSHARG 2
	PUSH 32
	ADD
	POPN 2
	JMP LOC_2A8A0
LOC_2AA1C:
	PUSH 1
	DELAY
	INCN 3
	JMP LOC_2A874
LOC_2AA38:
	RETN 2

}}

void function CannonExplode (arg_0, arg_1) {
__asm{
	STACK 1
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 43003
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 33001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSH 4
	DELAY
	PUSHSTR "CreateCannonFlash"
	PUSHARG 1
	PUSH 30720
	PUSH 36864
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 26
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function TraceCannon (arg_0) {
__asm{
	STACK 3
LOC_2AB54:
	PUSH 1
	DELAY
	PUSHARG -2
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMPG
	JNZ LOC_2AB54
	PUSHARG -2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG -2
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHSTR "CannonExplode"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 1

}}

void function ShootCannon () callsign 33002 {
__asm{
	STACK 4
	SYSCALL 0xB, (0 | (1 << 16)) ; 0x000B 
	POPN 2
	PUSHARG 2
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 4
	PUSHARG 2
	PUSH 43002
	PUSHARG 4
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 61440
	PUSH 61440
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG 2
	PUSHARG 4
	PUSH 45
	PUSH 85
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 30
	PUSH 30
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSH 2
	DELAY
	PUSH 32
	DELAY
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 0

}}

void function TraceCannonShadow (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
LOC_2AD3C:
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_2AE48
	PUSHARG -4
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 1
	PUSHARG 1
	PUSH 0
	CMPLE
	JZ LOC_2AD98
	JMP LOC_2AE48
LOC_2AD98:
	PUSH 1
	DELAY
	PUSHARG -3
	PUSH 65536
	CMPL
	JZ LOC_2AE00
	PUSHARG -3
	PUSH 8192
	ADD
	POPN -3
	PUSHARG -5
	PUSHARG -3
	PUSHARG -3
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_2AE00:
	PUSHARG -2
	PUSH 16
	CMPL
	JZ LOC_2AE40
	INCN -2
	PUSHARG -5
	PUSHARG -2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
LOC_2AE40:
	JMP LOC_2AD3C
LOC_2AE48:
	PUSHARG -5
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 4

}}

void function FlyCannonLB1 (arg_0, arg_1, arg_2) {
__asm{
	STACK 2
	PUSHARG -2
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 43006
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSH 260
	ADD
	PUSHARG -3
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHSTR "TraceCannon"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	RETN 3

}}

void function FlyCannonRB1 (arg_0, arg_1, arg_2) {
__asm{
	STACK 2
	PUSHARG -2
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 43006
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSH 260
	SUB
	PUSHARG -3
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHSTR "TraceCannon"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	RETN 3

}}

void function FlyCannonLB2 (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSHARG -4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -4
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN -3
	PUSHARG -2
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 43006
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_2B120
	PUSHARG 1
	PUSHARG 2
	PUSH 260
	ADD
	PUSH 24
	ADD
	PUSHARG -3
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	JMP LOC_2B18C
LOC_2B120:
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	PUSH 24
	ADD
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_2B18C:
	PUSHARG 1
	PUSH 128
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHSTR "TraceCannon"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	RETN 3

}}

void function FlyCannonRB2 (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSHARG -4
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -4
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN -3
	PUSHARG -2
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 43006
	PUSH 128
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_2B2E4
	PUSHARG 1
	PUSHARG 2
	PUSH 260
	SUB
	PUSH 24
	SUB
	PUSHARG -3
	PUSH 260
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	JMP LOC_2B354
LOC_2B2E4:
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 260
	NEG
	PUSH 24
	SUB
	PUSH 0
	PUSH 260
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_2B354:
	PUSHARG 1
	PUSH 0
	PUSH 32
	NEG
	PUSH 32
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHSTR "TraceCannon"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	RETN 3

}}

void function ProduceCannonEmitter (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 1
	PUSHARG -3
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_2B424
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 43005
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	JMP LOC_2B458
LOC_2B424:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 43001
	PUSHARG -2
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
LOC_2B458:
	PUSHARG 1
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 0
	PUSH 0
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	RETN 4

}}

void function FireWork (arg_0) {
__asm{
LOC_2B4B0:
	STACK 15
	PUSH 1
	SETARG 45
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\033\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_2B630
	PUSH 0
	POPN 3
	JMP LOC_2B640
LOC_2B630:
	PUSH 128
	POPN 3
LOC_2B640:
	PUSHARG -2
	JCOND 0, LOC_2B66C
	JCOND 1, LOC_2B6A4
	POP
	JMP LOC_2B6DC
LOC_2B66C:
	PUSH 2
	POPN 6
	PUSH 4
	POPN 4
	PUSH 3
	POPN 8
	JMP LOC_2B70C
LOC_2B6A4:
	PUSH 1
	POPN 6
	PUSH 4
	POPN 4
	PUSH 5
	POPN 8
	JMP LOC_2B70C
LOC_2B6DC:
	PUSH 2
	POPN 6
	PUSH 4
	POPN 4
	PUSH 7
	POPN 8
LOC_2B70C:
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 7
	PUSHSTR "ProduceCannonEmitter"
	PUSH 6576
	PUSH 96
	PUSH 7
	MUL
	ADD
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMP
	MUL
	PUSH 240
	PUSH 96
	PUSH 7
	MUL
	SUB
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMPZ
	MUL
	ADD
	PUSH 180
	PUSHARG 4
	PUSH 72
	MUL
	PUSH 2
	MUL
	ADD
	PUSH 72
	PUSH 2
	MUL
	SUB
	PUSHARG 7
	PUSHARG 3
	CALLBS
	PUSHARG 4
	PUSHARG 6
	SUB
	POPN 4
	PUSHARG 4
	PUSH 0
	CMPGE
	JNZ LOC_2B70C
	PUSHARG -2
	PUSH 2
	CMPGE
	JZ LOC_2B9D8
	PUSH 2
	POPN 6
	PUSH 6
	POPN 4
LOC_2B878:
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 7
	PUSHSTR "ProduceCannonEmitter"
	PUSH 6576
	PUSH 96
	PUSH 7
	MUL
	ADD
	PUSH 96
	PUSH 2
	MUL
	ADD
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMP
	MUL
	PUSH 240
	PUSH 96
	PUSH 7
	MUL
	SUB
	PUSH 96
	PUSH 2
	MUL
	SUB
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMPZ
	MUL
	ADD
	PUSH 180
	PUSHARG 4
	PUSH 72
	MUL
	PUSH 2
	MUL
	ADD
	PUSH 72
	PUSH 1
	MUL
	SUB
	PUSHARG 7
	PUSHARG 3
	CALLBS
	PUSHARG 4
	PUSHARG 6
	SUB
	POPN 4
	PUSHARG 4
	PUSH 0
	CMPG
	JNZ LOC_2B878
LOC_2B9D8:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_2BA40
	PUSH 240
	PUSH 96
	PUSH 4
	MUL
	SUB
	PUSH 96
	SUB
	PUSH 0
	PUSH 40
	CALL MoveCamera
	JMP LOC_2BA90
LOC_2BA40:
	PUSH 6576
	PUSH 96
	PUSH 4
	MUL
	ADD
	PUSH 1
	SUB
	PUSH 96
	ADD
	PUSH 0
	PUSH 40
	CALL MoveCamera
LOC_2BA90:
	PUSH 80
	DELAY
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	POPN 10
	PUSH 0
	POPN 11
	PUSHARG 10
	PUSHARG 8
	CMPL
	JZ LOC_2BB0C
	PUSHARG 8
	PUSHARG 10
	SUB
	POPN 11
LOC_2BB0C:
	PUSHARG 8
	PUSHARG 11
	SUB
	PUSH 0
	CMPG
	JZ LOC_2BD54
	PUSH 0
	POPN 5
	PUSHARG 8
	PUSHARG 11
	SUB
	POPN 4
LOC_2BB60:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 9
	PUSHARG 9
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 14
	PUSHARG 9
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 15
	PUSHARG 5
	PUSH 0
	CMP
	JZ LOC_2BC14
	PUSH 1
	POPN 5
	PUSHARG 14
	POPN 12
	PUSHARG 14
	POPN 13
	JMP LOC_2BC6C
LOC_2BC14:
	PUSHARG 12
	PUSHARG 14
	CMPL
	JZ LOC_2BC40
	PUSHARG 14
	POPN 12
LOC_2BC40:
	PUSHARG 13
	PUSHARG 14
	CMPG
	JZ LOC_2BC6C
	PUSHARG 14
	POPN 13
LOC_2BC6C:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_2BCDC
	PUSHSTR "FlyCannonRB2"
	PUSHARG 9
	PUSHARG 15
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 0
	CALLBS
	JMP LOC_2BD28
LOC_2BCDC:
	PUSHSTR "FlyCannonLB2"
	PUSHARG 9
	PUSHARG 15
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 0
	CALLBS
LOC_2BD28:
	DECN 4
	PUSHARG 4
	PUSH 0
	CMPG
	JNZ LOC_2BB60
	JMP LOC_2BD80
LOC_2BD54:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 12
	PUSHARG 12
	POPN 13
LOC_2BD80:
	PUSHARG 12
	PUSHARG 13
	CMP
	JZ LOC_2BDD4
	PUSHARG 12
	PUSH 512
	ADD
	POPN 12
	PUSHARG 13
	PUSH 512
	SUB
	POPN 13
LOC_2BDD4:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 9
	PUSHARG 9
	PUSH 0
	CMP
	JZ LOC_2BE28
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 9
LOC_2BE28:
	PUSHARG 9
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 12
	PUSHARG 11
	POPN 4
LOC_2BE54:
	PUSHARG 12
	PUSH 320
	NEG
	PUSH 320
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 14
	PUSH 150
	PUSH 650
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 15
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_2BF1C
	PUSHSTR "FlyCannonRB1"
	PUSHARG 14
	PUSHARG 15
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 0
	CALLBS
	JMP LOC_2BF68
LOC_2BF1C:
	PUSHSTR "FlyCannonLB1"
	PUSHARG 14
	PUSHARG 15
	PUSH 80
	PUSH 1
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 0
	CALLBS
LOC_2BF68:
	DECN 4
	PUSHARG 4
	PUSH 0
	CMPG
	JNZ LOC_2BE54
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 9
	PUSHARG 9
	PUSH 0
	CMP
	JZ LOC_2BFE0
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 9
LOC_2BFE0:
	PUSHARG 9
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 14
	PUSHARG 9
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 15
	PUSHARG 14
	PUSH 0
	PUSH 80
	CALL MoveCamera
	PUSHSTR "TraceFlash"
	INST_45
	PUSH 180
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function PowderCallback (arg_0, arg_1) callsign 34001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	PUSHARG -2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	ORZ
	JZ LOC_2C17C
	INST_09 46
	JZ LOC_2C0E4
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 46
	DIV
	POPN 1
LOC_2C0E4:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_2C174
	INST_09 46
	PUSH 2
	MUL
	SETARG 46
	PUSHARG -3
	PUSHARG -2
	PUSH 11002
	PUSH 1
	PUSH 48
	PUSH 0
	CALL HitGeneral
LOC_2C174:
	JMP LOC_2C1C8
LOC_2C17C:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_2C1C8:
	RETN 2

}}

void function CreatePowerExplode (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5) {
__asm{
	STACK 1
	PUSHARG -7
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 44003
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSH 2
	PUSH 8
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSHARG -3
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 32768
	PUSH 32768
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 512
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG -2
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 6

}}

void function CreatePowerSmoke (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6) {
__asm{
	STACK 1
	PUSHARG -2
	JZ LOC_2C384
	PUSHARG -8
	PUSHARG -7
	PUSHARG -6
	PUSH 0
	PUSH 44004
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSH 2
	PUSH 4
	PUSH 28
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSHARG -4
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	JMP LOC_2C40C
LOC_2C384:
	PUSHARG -8
	PUSHARG -7
	PUSHARG -6
	PUSH 0
	PUSH 44002
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSH 2
	PUSH 0
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSHARG -4
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
LOC_2C40C:
	PUSHARG -3
	PUSH 4
	SUB
	DELAY
	PUSHARG 1
	PUSH 1024
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSH 4
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 7

}}

void function CreatePowderBreak (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -2
	DELAY
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
	PUSHARG -3
	PUSH 44005
	PUSH 44011
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG 2
	PUSH 20
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 18432
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHARG 1
	PUSHARG -3
	PUSHARG 2
	PUSH 4
	PUSH 20
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSHARG 2
	PUSH 36
	PUSH 54
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 6
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSHSTR "m034snd01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSH 8
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function CreatePower (arg_0, arg_1, arg_2) {
__asm{
	STACK 2
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 44001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 2
LOC_2C680:
	PUSHARG 2
	PUSH 16
	CMPLE
	JZ LOC_2C6D4
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_2C680
LOC_2C6D4:
	PUSHARG -2
	DELAY
	PUSHARG 1
	PUSH 128
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 2
LOC_2C70C:
	PUSHARG 2
	PUSH 10
	CMPL
	JZ LOC_2C778
	PUSHSTR "CreatePowderBreak"
	PUSHARG 1
	PUSH 1
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	INCN 2
	JMP LOC_2C70C
LOC_2C778:
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSHARG -3
	PUSH 2501
	PUSH 0
	PUSH 2
	PUSH 34001
	PUSH 2
	PUSH 3
	PUSH 251658240
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 60
	ADD
	PUSHARG -3
	PUSH 2501
	PUSH 0
	PUSH 2
	PUSH 34001
	PUSH 2
	PUSH 3
	PUSH 251658240
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 60
	SUB
	PUSHARG -3
	PUSH 2501
	PUSH 0
	PUSH 2
	PUSH 34001
	PUSH 2
	PUSH 3
	PUSH 251658240
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSHARG -3
	PUSH 48
	ADD
	PUSH 2501
	PUSH 0
	PUSH 2
	PUSH 34001
	PUSH 2
	PUSH 3
	PUSH 251658240
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSHARG -3
	PUSH 48
	ADD
	PUSH 2501
	PUSH 0
	PUSH 2
	PUSH 34001
	PUSH 2
	PUSH 3
	PUSH 251658240
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 60
	ADD
	PUSHARG -3
	PUSH 48
	ADD
	PUSH 2501
	PUSH 0
	PUSH 2
	PUSH 34001
	PUSH 2
	PUSH 3
	PUSH 251658240
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 60
	ADD
	PUSHARG -3
	PUSH 48
	SUB
	PUSH 2501
	PUSH 0
	PUSH 2
	PUSH 34001
	PUSH 2
	PUSH 3
	PUSH 251658240
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 60
	SUB
	PUSHARG -3
	PUSH 48
	ADD
	PUSH 2501
	PUSH 0
	PUSH 2
	PUSH 34001
	PUSH 2
	PUSH 3
	PUSH 251658240
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -4
	PUSH 60
	SUB
	PUSHARG -3
	PUSH 48
	SUB
	PUSH 2501
	PUSH 0
	PUSH 2
	PUSH 34001
	PUSH 2
	PUSH 3
	PUSH 251658240
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSH 0
	POPN 2
LOC_2CB54:
	PUSHARG 2
	PUSH 12
	CMPL
	JZ LOC_2CD80
	PUSHSTR "CreatePowerSmoke"
	PUSHARG -4
	PUSHARG -3
	PUSH 20
	PUSH 40
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 16
	PUSH 0
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
	PUSHARG 2
	PUSH 1
	AND
	PUSH 0
	CMP
	JZ LOC_2CCA8
	PUSHSTR "CreatePowerSmoke"
	PUSHARG -4
	PUSHARG -3
	PUSH 20
	PUSH 40
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 18
	PUSH 1
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
LOC_2CCA8:
	PUSH 1
	DELAY
	PUSHARG 2
	PUSH 8
	CMPL
	JZ LOC_2CD50
	PUSHSTR "CreatePowerExplode"
	PUSHARG -4
	PUSHARG -3
	PUSH 20
	PUSH 40
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
LOC_2CD50:
	PUSH 1
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 2
	JMP LOC_2CB54
LOC_2CD80:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 3

}}

void function Powder (arg_0) {
__asm{
LOC_2CD9C:
	STACK 5
	PUSH 1
	SETARG 46
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\034\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHARG -2
	JCOND 0, LOC_2CF14
	JCOND 1, LOC_2CF2C
	POP
	JMP LOC_2CF44
LOC_2CF14:
	PUSH 2
	POPN 5
	JMP LOC_2CF54
LOC_2CF2C:
	PUSH 5
	POPN 5
	JMP LOC_2CF54
LOC_2CF44:
	PUSH 7
	POPN 5
LOC_2CF54:
	PUSH 0
	POPN 4
LOC_2CF64:
	PUSHARG 4
	PUSHARG 5
	CMPL
	JZ LOC_2D314
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 3
	PUSHARG 3
	JZ LOC_2D040
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	JMP LOC_2D0C0
LOC_2D040:
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSH 250
	NEG
	PUSH 250
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSH 200
	NEG
	PUSH 200
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
LOC_2D0C0:
	PUSHARG 4
	PUSH 0
	CMP
	JZ LOC_2D114
	PUSHSTR "MoveCamera"
	PUSHARG 1
	PUSHARG 2
	PUSH 140
	SUB
	PUSH 40
	PUSH 0
	CALLBS
LOC_2D114:
	PUSHSTR "CreatePower"
	PUSHARG 1
	PUSHARG 2
	PUSH 40
	PUSH 150
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	JZ LOC_2D1B0
	PUSHARG 1
	PUSH 150
	PUSH 200
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 1
	JMP LOC_2D1E0
LOC_2D1B0:
	PUSHARG 1
	PUSH 150
	PUSH 200
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 1
LOC_2D1E0:
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	JZ LOC_2D23C
	PUSHARG 2
	PUSH 120
	PUSH 170
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	JMP LOC_2D26C
LOC_2D23C:
	PUSHARG 2
	PUSH 120
	PUSH 170
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 2
LOC_2D26C:
	PUSHARG 2
	PUSH 800
	CMPG
	JZ LOC_2D298
	PUSH 800
	POPN 2
LOC_2D298:
	PUSHARG 2
	PUSH 200
	CMPL
	JZ LOC_2D2C4
	PUSH 200
	POPN 2
LOC_2D2C4:
	PUSHSTR "CreatePower"
	PUSHARG 1
	PUSHARG 2
	PUSH 80
	PUSH 120
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CALLBS
	INCN 4
	JMP LOC_2CF64
LOC_2D314:
	PUSHSTR "CreatePower"
	INST_45
	PUSHSTR "CreatePowerSmoke"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function SpearCallback (arg_0, arg_1) callsign 35001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_2D414
	INST_09 47
	JZ LOC_2D3B4
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 47
	DIV
	POPN 1
LOC_2D3B4:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_2D40C
	INST_09 47
	PUSH 2
	MUL
	SETARG 47
LOC_2D40C:
	JMP LOC_2D434
LOC_2D414:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_2D434:
	PUSHSTR "Blood"
	PUSHARG -2
	PUSH 16
	PUSH 0
	PUSH 0
	CALLBS
	RETN 2

}}

void function CreateSpears (arg_0, arg_1) {
__asm{
	STACK 4
	PUSHARG -3
	PUSH 36
	PUSH 3
	MUL
	ADD
	POPN 3
	PUSHARG -2
	PUSH 42
	PUSH 2
	MUL
	ADD
	POPN 4
	PUSHARG -3
	PUSH 36
	PUSH 3
	MUL
	SUB
	POPN 1
LOC_2D4E8:
	PUSHARG 1
	PUSHARG 3
	CMPLE
	JZ LOC_2D5D0
	PUSHARG -2
	PUSH 42
	PUSH 2
	MUL
	SUB
	POPN 2
LOC_2D52C:
	PUSHARG 2
	PUSHARG 4
	CMPLE
	JZ LOC_2D5AC
	PUSHSTR "CreateSpear"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CALLBS
	PUSHARG 2
	PUSH 42
	ADD
	POPN 2
	JMP LOC_2D52C
LOC_2D5AC:
	PUSHARG 1
	PUSH 36
	ADD
	POPN 1
	JMP LOC_2D4E8
LOC_2D5D0:
	RETN 2

}}

void function CreateSpear (arg_0, arg_1, arg_2) {
__asm{
	STACK 1
	PUSHARG -2
	DELAY
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 45001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 35001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSH 20
	DELAY
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 45002
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSH 8
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function Spear (arg_0) {
__asm{
LOC_2D700:
	STACK 4
	PUSH 1
	SETARG 47
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\035\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 0
	POPN 4
LOC_2D85C:
	PUSHARG 4
	PUSHARG -2
	PUSH 1
	ADD
	CMPL
	JZ LOC_2DBD0
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_2D9C0
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 10
	PUSH 24
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	SYSCALL 0x202, (2 | (1 << 16)) ; 0x0202 
	ADD
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 10
	PUSH 20
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	SYSCALL 0x201, (2 | (1 << 16)) ; 0x0201 
	ADD
	POPN 2
	JMP LOC_2D9F8
LOC_2D9C0:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
LOC_2D9F8:
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHSTR "m035snd01"
	PUSH 230
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "CreateSpears"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 8
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 10
	PUSH 24
	PUSH 32
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	SYSCALL 0x202, (2 | (1 << 16)) ; 0x0202 
	ADD
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 10
	PUSH 20
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	SYSCALL 0x201, (2 | (1 << 16)) ; 0x0201 
	ADD
	POPN 2
	PUSHSTR "m035snd01"
	PUSH 180
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "CreateSpears"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 12
	DELAY
	INCN 4
	JMP LOC_2D85C
LOC_2DBD0:
	PUSHSTR "CreateSpear"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function SlashCallback (arg_0, arg_1) callsign 36001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_2DCFC
	INST_09 48
	JZ LOC_2DC64
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 48
	DIV
	POPN 1
LOC_2DC64:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_2DCF4
	INST_09 48
	PUSH 2
	MUL
	SETARG 48
	PUSHARG -3
	PUSHARG -2
	PUSH 13008
	PUSH 2
	PUSH 60
	PUSH 0
	CALL HitGeneral
LOC_2DCF4:
	JMP LOC_2DD48
LOC_2DCFC:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 8
	PUSH 0
	CALLBS
LOC_2DD48:
	RETN 2

}}

void function CreateSlashByTarget (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 3
	PUSH 4096
	POPN 3
	PUSHARG -5
	PUSH 46001
	PUSHARG -3
	ADD
	PUSH 128
	PUSHARG -4
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSH 192
	PUSHARG -3
	PUSH 16
	MUL
	SUB
	PUSH 80
	PUSH 180
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG -4
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 2
LOC_2DE34:
	PUSHARG 2
	PUSH 32
	CMPLE
	JZ LOC_2DEF0
	PUSHARG 3
	PUSH 49152
	CMPL
	JZ LOC_2DE90
	PUSHARG 1
	PUSHARG 3
	PUSHARG 3
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_2DE90:
	PUSHARG 1
	PUSHARG 2
	PUSH 2
	DIV
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	PUSHARG 3
	PUSH 2048
	ADD
	POPN 3
	INCN 2
	JMP LOC_2DE34
LOC_2DEF0:
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSH 24
	DELAY
	PUSHSTR "m036snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG 1
	PUSH 64
	PUSHARG -3
	PUSH 16
	MUL
	SUB
	PUSH 0
	PUSH 12
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 50331648
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 36001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 48
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -2
	DELAY
	PUSHARG 1
	PUSH 50331648
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	RETN 4

}}

void function CreateSlash (arg_0, arg_1, arg_2, arg_3, arg_4, arg_5) {
__asm{
	STACK 3
	PUSH 4096
	POPN 3
	PUSHARG -7
	PUSHARG -6
	PUSHARG -5
	PUSH 128
	PUSH 46001
	PUSHARG -4
	ADD
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 2
LOC_2E090:
	PUSHARG 2
	PUSH 32
	CMPLE
	JZ LOC_2E14C
	PUSHARG 3
	PUSH 49152
	CMPL
	JZ LOC_2E0EC
	PUSHARG 1
	PUSHARG 3
	PUSHARG 3
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
LOC_2E0EC:
	PUSHARG 1
	PUSHARG 2
	PUSH 2
	DIV
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	PUSHARG 3
	PUSH 2048
	ADD
	POPN 3
	INCN 2
	JMP LOC_2E090
LOC_2E14C:
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSH 24
	DELAY
	PUSHSTR "m036snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG 1
	PUSH 64
	PUSHARG -4
	PUSH 16
	MUL
	SUB
	PUSH 0
	PUSH 12
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG -2
	JZ LOC_2E21C
	PUSHARG 1
	PUSH 50331648
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 36001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
LOC_2E21C:
	PUSHARG 1
	PUSH 48
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -3
	DELAY
	PUSHARG 1
	PUSH 50331648
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	RETN 6

}}

void function Slash (arg_0) {
__asm{
LOC_2E270:
	STACK 8
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\036\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 1
	SETARG 48
	PUSHSTR "m036snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_2E800
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_2E448
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_2E448:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 3
	SYSCALL 0x101, (1 | (1 << 16)) ; GetObjectXY 
	POPN 7
	PUSHARG 3
	SYSCALL 0x102, (1 | (1 << 16)) ; 0x0102 
	POPN 8
	PUSHARG 1
	PUSHARG 2
	PUSH 140
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHSTR "CreateSlashByTarget"
	PUSHARG 3
	PUSH 40
	PUSH 0
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CALLBS
	PUSH 0
	POPN 4
LOC_2E534:
	PUSHARG 4
	PUSH 4
	CMPL
	JZ LOC_2E71C
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 7
	PUSHARG 8
	PUSH 6
	PUSH 5
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 6
	PUSHARG 6
	PUSH 2
	CMPG
	JZ LOC_2E66C
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 7
	PUSHARG 8
	PUSH 6
	PUSH 5
	PUSH 0
	PUSHARG 6
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 3
	PUSHSTR "CreateSlashByTarget"
	PUSHARG 3
	PUSH 40
	PUSH 0
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	CALLBS
	JMP LOC_2E70C
LOC_2E66C:
	PUSHSTR "CreateSlash"
	PUSHARG 1
	PUSH 250
	NEG
	PUSH 250
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 2
	PUSH 180
	NEG
	PUSH 180
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 40
	PUSH 0
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 1
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
LOC_2E70C:
	INCN 4
	JMP LOC_2E534
LOC_2E71C:
	PUSH 0
	POPN 4
LOC_2E72C:
	PUSHARG 4
	PUSH 3
	CMPL
	JZ LOC_2E7F8
	PUSHSTR "CreateSlash"
	PUSHARG 1
	PUSH 250
	NEG
	PUSH 250
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 2
	PUSH 180
	NEG
	PUSH 180
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 40
	PUSH 0
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	INCN 4
	JMP LOC_2E72C
LOC_2E7F8:
	JMP LOC_2ECAC
LOC_2E800:
	PUSH 0
	POPN 5
LOC_2E810:
	PUSHARG 5
	PUSH 3
	CMPL
	JZ LOC_2ECAC
	PUSHARG 5
	PUSH 0
	CMP
	JZ LOC_2E878
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	JMP LOC_2E8A0
LOC_2E878:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 3
LOC_2E8A0:
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_2E8CC
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_2E8CC:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 3
	SYSCALL 0x101, (1 | (1 << 16)) ; GetObjectXY 
	POPN 7
	PUSHARG 3
	SYSCALL 0x102, (1 | (1 << 16)) ; 0x0102 
	POPN 8
	PUSHARG 1
	PUSHARG 2
	PUSH 140
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHSTR "CreateSlashByTarget"
	PUSHARG 3
	PUSH 40
	PUSH 0
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CALLBS
	PUSH 0
	POPN 4
LOC_2E9B8:
	PUSHARG 4
	PUSH 5
	CMPL
	JZ LOC_2EBA0
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 7
	PUSHARG 8
	PUSH 6
	PUSH 5
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 6
	PUSHARG 6
	PUSH 2
	CMPG
	JZ LOC_2EAF0
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 7
	PUSHARG 8
	PUSH 6
	PUSH 5
	PUSH 0
	PUSHARG 6
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 3
	PUSHSTR "CreateSlashByTarget"
	PUSHARG 3
	PUSH 40
	PUSH 0
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 24
	CALLBS
	JMP LOC_2EB90
LOC_2EAF0:
	PUSHSTR "CreateSlash"
	PUSHARG 1
	PUSH 250
	NEG
	PUSH 250
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 2
	PUSH 180
	NEG
	PUSH 180
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 40
	PUSH 0
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 24
	PUSH 1
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
LOC_2EB90:
	INCN 4
	JMP LOC_2E9B8
LOC_2EBA0:
	PUSH 0
	POPN 4
LOC_2EBB0:
	PUSHARG 4
	PUSH 4
	CMPL
	JZ LOC_2EC7C
	PUSHSTR "CreateSlash"
	PUSHARG 1
	PUSH 250
	NEG
	PUSH 250
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 2
	PUSH 180
	NEG
	PUSH 180
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 40
	PUSH 0
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 12
	PUSH 0
	SYSCALL 0x311, (7 | (0 << 16)) ; 0x0311 
	INCN 4
	JMP LOC_2EBB0
LOC_2EC7C:
	PUSH 56
	PUSH 80
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 5
	JMP LOC_2E810
LOC_2ECAC:
	PUSHSTR "CreateSlash"
	INST_45
	PUSH 78
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function WallCallback (arg_0, arg_1) callsign 37001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_2EDA0
	INST_09 50
	JZ LOC_2ED40
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 50
	DIV
	POPN 1
LOC_2ED40:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_2ED98
	INST_09 50
	PUSH 2
	MUL
	SETARG 50
LOC_2ED98:
	JMP LOC_2EDEC
LOC_2EDA0:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_2EDEC:
	RETN 2

}}

void function CreateFireWallAttack (arg_0, arg_1) {
__asm{
	STACK 15
	PUSH 0
	POPN 2
	PUSH 0
	POPN 1
LOC_2EE1C:
	PUSHARG 1
	PUSH 10
	CMPL
	JZ LOC_2EE60
	PUSH 0
	PUSHARG 1
	SETNR 3
	INCN 1
	JMP LOC_2EE1C
LOC_2EE60:
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_2EE94
	PUSH 862
	POPN 15
	JMP LOC_2EEA4
LOC_2EE94:
	PUSH 934
	POPN 15
LOC_2EEA4:
	PUSHARG 15
	POPN 1
LOC_2EEB4:
	PUSHARG 1
	PUSH 100
	CMPGE
	JZ LOC_2EFA0
	PUSHARG -3
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	PUSHARG 2
	SETNR 3
	PUSHARG 2
	PUSHNR 3
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSHNR 3
	PUSH 37001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	INCN 2
	PUSHARG 1
	PUSH 72
	PUSH 2
	MUL
	SUB
	POPN 1
	JMP LOC_2EEB4
LOC_2EFA0:
	INST_09 49
	PUSH 0
	CMP
	JZ LOC_2EFD0
	PUSH 1
	DELAY
	JMP LOC_2EFA0
LOC_2EFD0:
	PUSH 0
	POPN 1
LOC_2EFE0:
	PUSHARG 1
	PUSHARG 2
	CMPL
	JZ LOC_2F028
	PUSHARG 1
	PUSHNR 3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	INCN 1
	JMP LOC_2EFE0
LOC_2F028:
	RETN 2

}}

void function CreateFireWall (arg_0, arg_1, arg_2) {
__asm{
	STACK 6
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHSTR "CreateFireWallAttack"
	PUSHARG -4
	PUSHARG -2
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 0
	POPN 2
LOC_2F0B0:
	PUSHARG 2
	PUSH 4
	CMPL
	JZ LOC_2F17C
	PUSHARG 1
	PUSH 47001
	PUSHARG 2
	ADD
	PUSH 0
	PUSH 34
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 4
	PUSHARG 4
	PUSH 32768
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 4
	DELAY
	PUSHARG 2
	PUSH 3
	CMPL
	JZ LOC_2F16C
	PUSHARG 4
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_2F16C:
	INCN 2
	JMP LOC_2F0B0
LOC_2F17C:
	PUSH 65536
	POPN 2
LOC_2F18C:
	PUSHARG 2
	PUSH 131072
	CMPL
	JZ LOC_2F1FC
	PUSHARG 4
	PUSH 32768
	PUSHARG 2
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 2
	DELAY
	PUSHARG 2
	PUSH 8192
	ADD
	POPN 2
	JMP LOC_2F18C
LOC_2F1FC:
	PUSH 280
	DELAY
	PUSH 1
	SETARG 49
	PUSHARG 4
	PUSH 4096
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG 4
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 3

}}

void function Wall (arg_0) {
__asm{
LOC_2F274:
	STACK 4
	PUSH 1
	SETARG 50
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\037\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	CALL GetSoldierMaxX2
	POPN 4
	PUSH 0
	SETARG 49
	PUSHARG 4
	PUSH 1
	NEG
	CMP
	JZ LOC_2F464
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_2F444
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	CALL CastFail
	JMP LOC_2F45C
LOC_2F444:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 128
	CALL CastFail
LOC_2F45C:
	JMP LOC_2FA40
LOC_2F464:
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_2F6E8
	PUSHSTR "m037snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_2F5D0
	PUSHARG 4
	PUSH 96
	PUSH 5
	MUL
	PUSH 2
	DIV
	ADD
	PUSH 422
	PUSH 20
	CALL MoveCamera
	PUSH 2
	DELAY
	PUSH 900
	POPN 3
LOC_2F518:
	PUSHARG 3
	PUSH 200
	CMPGE
	JZ LOC_2F5C8
	PUSHSTR "CreateFireWall"
	PUSHARG 4
	PUSH 96
	PUSH 3
	MUL
	PUSH 2
	DIV
	ADD
	PUSHARG 3
	PUSHARG -2
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 3
	PUSH 120
	SUB
	POPN 3
	JMP LOC_2F518
LOC_2F5C8:
	JMP LOC_2F6E0
LOC_2F5D0:
	PUSHARG 4
	PUSH 96
	PUSH 5
	MUL
	PUSH 2
	DIV
	SUB
	PUSH 422
	PUSH 20
	CALL MoveCamera
	PUSH 2
	DELAY
	PUSH 862
	POPN 3
LOC_2F630:
	PUSHARG 3
	PUSH 200
	CMPGE
	JZ LOC_2F6E0
	PUSHSTR "CreateFireWall"
	PUSHARG 4
	PUSH 96
	PUSH 3
	MUL
	PUSH 2
	DIV
	SUB
	PUSHARG 3
	PUSHARG -2
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 3
	PUSH 120
	SUB
	POPN 3
	JMP LOC_2F630
LOC_2F6E0:
	JMP LOC_2FA40
LOC_2F6E8:
	PUSHSTR "m037snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_2F8B4
	PUSHARG 4
	PUSH 96
	PUSH 5
	MUL
	PUSH 2
	DIV
	ADD
	PUSH 422
	PUSH 20
	CALL MoveCamera
	PUSH 2
	DELAY
	PUSH 900
	POPN 3
LOC_2F780:
	PUSHARG 3
	PUSH 200
	CMPGE
	JZ LOC_2F8AC
	PUSHSTR "CreateFireWall"
	PUSHARG 4
	PUSH 96
	PUSH 3
	MUL
	PUSH 2
	DIV
	ADD
	PUSHARG 3
	PUSHARG -2
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHSTR "CreateFireWall"
	PUSHARG 4
	PUSH 96
	PUSH 3
	MUL
	PUSH 2
	DIV
	ADD
	PUSH 400
	ADD
	PUSHARG 3
	PUSHARG -2
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 3
	PUSH 120
	SUB
	POPN 3
	JMP LOC_2F780
LOC_2F8AC:
	JMP LOC_2FA40
LOC_2F8B4:
	PUSHARG 4
	PUSH 96
	PUSH 5
	MUL
	PUSH 2
	DIV
	SUB
	PUSH 422
	PUSH 20
	CALL MoveCamera
	PUSH 2
	DELAY
	PUSH 862
	POPN 3
LOC_2F914:
	PUSHARG 3
	PUSH 200
	CMPGE
	JZ LOC_2FA40
	PUSHSTR "CreateFireWall"
	PUSHARG 4
	PUSH 96
	PUSH 3
	MUL
	PUSH 2
	DIV
	SUB
	PUSHARG 3
	PUSHARG -2
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHSTR "CreateFireWall"
	PUSHARG 4
	PUSH 96
	PUSH 3
	MUL
	PUSH 2
	DIV
	ADD
	PUSH 540
	SUB
	PUSHARG 3
	PUSHARG -2
	PUSH 0
	CALLBS
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 3
	PUSH 120
	SUB
	POPN 3
	JMP LOC_2F914
LOC_2FA40:
	PUSHSTR "CreateFireWall"
	INST_45
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 140
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function TwisterSwordCallback (arg_0, arg_1) callsign 38001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_2FBCC
	INST_09 51
	JZ LOC_2FB34
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 51
	DIV
	POPN 1
LOC_2FB34:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_2FBC4
	INST_09 51
	PUSH 2
	MUL
	SETARG 51
	PUSHARG -3
	PUSHARG -2
	PUSH 13008
	PUSH 2
	PUSH 60
	PUSH 0
	CALL HitGeneral
LOC_2FBC4:
	JMP LOC_2FC18
LOC_2FBCC:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 8
	PUSH 0
	CALLBS
LOC_2FC18:
	RETN 2

}}

void function CreateTwisterSwordAttack (arg_0, arg_1) {
__asm{
	STACK 27
	PUSH 0
	POPN 1
LOC_2FC38:
	PUSHARG 1
	PUSH 8
	CMPL
	JZ LOC_2FDF0
	PUSH 0
	POPN 2
LOC_2FC64:
	PUSHARG 2
	PUSH 3
	CMPL
	JZ LOC_2FDE0
	PUSHARG -3
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	PUSHARG 1
	PUSH 3
	MUL
	PUSHARG 2
	ADD
	SETNR 3
	PUSHARG 1
	PUSH 1
	AND
	PUSH 0
	CMP
	PUSHARG 2
	PUSH 2
	CMP
	ORNZ
	JZ LOC_2FD58
	PUSHARG 1
	PUSH 3
	MUL
	PUSHARG 2
	ADD
	PUSHNR 3
	PUSH 50331648
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	JMP LOC_2FD94
LOC_2FD58:
	PUSHARG 1
	PUSH 3
	MUL
	PUSHARG 2
	ADD
	PUSHNR 3
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
LOC_2FD94:
	PUSHARG 1
	PUSH 3
	MUL
	PUSHARG 2
	ADD
	PUSHNR 3
	PUSH 38001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	INCN 2
	JMP LOC_2FC64
LOC_2FDE0:
	INCN 1
	JMP LOC_2FC38
LOC_2FDF0:
	PUSH 0
	POPN 27
LOC_2FE00:
	PUSHARG 27
	PUSH 280
	CMPL
	JZ LOC_2FF34
	PUSH 0
	POPN 1
LOC_2FE2C:
	PUSHARG 1
	PUSH 8
	CMPL
	JZ LOC_2FF18
	PUSH 0
	POPN 2
LOC_2FE58:
	PUSHARG 2
	PUSH 3
	CMPL
	JZ LOC_2FF08
	PUSHARG 1
	PUSH 3
	MUL
	PUSHARG 2
	ADD
	PUSHNR 3
	PUSHARG -3
	PUSH 32
	PUSHARG 1
	MUL
	PUSHARG 27
	ADD
	PUSH 60
	PUSHARG 2
	PUSH 32
	MUL
	ADD
	PUSHARG -2
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	INCN 2
	JMP LOC_2FE58
LOC_2FF08:
	INCN 1
	JMP LOC_2FE2C
LOC_2FF18:
	PUSH 1
	DELAY
	INCN 27
	JMP LOC_2FE00
LOC_2FF34:
	PUSH 0
	POPN 1
LOC_2FF44:
	PUSHARG 1
	PUSH 24
	CMPL
	JZ LOC_2FF8C
	PUSHARG 1
	PUSHNR 3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	INCN 1
	JMP LOC_2FF44
LOC_2FF8C:
	RETN 2

}}

void function CreateTwisterSword (arg_0, arg_1, arg_2) {
__asm{
LOC_2FF94:
	STACK 70
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSH 0
	POPN 66
LOC_2FFE8:
	PUSHARG 66
	PUSH 16
	CMPL
	JZ LOC_30144
	PUSHARG 1
	PUSH 48001
	PUSHARG 66
	ADD
	PUSH 128
	PUSHARG -2
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	PUSHARG 66
	SETNR 2
	PUSHARG 66
	PUSHNR 2
	PUSHARG 1
	PUSH 64
	PUSH 16
	PUSHARG 66
	MUL
	SUB
	PUSH 0
	PUSHARG -2
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 66
	PUSHNR 2
	PUSH 40960
	PUSH 40960
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 66
	PUSHNR 2
	PUSH 128
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 66
	PUSHNR 2
	PUSH 0
	PUSHARG 66
	PUSH 4
	MOD
	PUSH 2
	MUL
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	INCN 66
	JMP LOC_2FFE8
LOC_30144:
	PUSH 0
	POPN 67
LOC_30154:
	PUSHARG 67
	PUSH 280
	CMPLE
	JZ LOC_303A4
	PUSH 0
	POPN 66
LOC_30180:
	PUSHARG 66
	PUSH 16
	CMPL
	JZ LOC_30340
	PUSHARG 66
	PUSHNR 2
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 69
	PUSHARG 69
	PUSH 0
	CMP
	JZ LOC_30218
	PUSHARG 66
	PUSHNR 2
	PUSH 128
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	DECN 69
	JMP LOC_30294
LOC_30218:
	PUSHARG 69
	PUSH 2
	NEG
	CMP
	JZ LOC_3028C
	PUSHARG 66
	PUSHNR 2
	PUSH 128
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 3
	PUSH 2
	MUL
	PUSH 1
	SUB
	POPN 69
	JMP LOC_30294
LOC_3028C:
	DECN 69
LOC_30294:
	PUSHARG 66
	PUSHNR 2
	PUSH 0
	PUSHARG 69
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 67
	PUSH 90
	CMPLE
	JZ LOC_30330
	PUSHARG 66
	PUSHNR 2
	PUSHARG 1
	PUSH 64
	PUSH 16
	PUSHARG 66
	MUL
	SUB
	PUSHARG 67
	PUSHARG -2
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
LOC_30330:
	INCN 66
	JMP LOC_30180
LOC_30340:
	PUSHARG 67
	PUSH 90
	CMP
	JZ LOC_30388
	PUSHSTR "CreateTwisterSwordAttack"
	PUSHARG 1
	PUSHARG -2
	PUSH 0
	PUSH 0
	CALLBS
LOC_30388:
	PUSH 1
	DELAY
	INCN 67
	JMP LOC_30154
LOC_303A4:
	PUSH 0
	POPN 66
LOC_303B4:
	PUSHARG 66
	PUSH 16
	CMPL
	JZ LOC_303FC
	PUSHARG 66
	PUSHNR 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	INCN 66
	JMP LOC_303B4
LOC_303FC:
	PUSHSTR "m038snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	POPN 66
LOC_30428:
	PUSHARG 66
	PUSH 8
	CMPL
	JZ LOC_30610
	PUSHARG 1
	PUSH 48017
	PUSHARG 66
	PUSH 2
	MUL
	ADD
	PUSH 128
	PUSHARG -2
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	PUSHARG 66
	SETNR 2
	PUSHARG 66
	PUSHNR 2
	PUSHARG 1
	PUSH 64
	PUSH 32
	PUSHARG 66
	MUL
	SUB
	PUSH 90
	PUSHARG -2
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 66
	PUSHNR 2
	PUSH 40960
	PUSH 40960
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 66
	PUSHNR 2
	PUSH 64
	PUSH 32
	PUSHARG 66
	MUL
	SUB
	PUSH 0
	PUSH 10
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 66
	PUSH 1
	AND
	PUSH 0
	CMP
	JZ LOC_305B8
	PUSHARG 66
	PUSHNR 2
	PUSH 50331648
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	JMP LOC_305DC
LOC_305B8:
	PUSHARG 66
	PUSHNR 2
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
LOC_305DC:
	PUSHARG 66
	PUSHNR 2
	PUSH 38001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	INCN 66
	JMP LOC_30428
LOC_30610:
	PUSH 0
	POPN 66
LOC_30620:
	PUSHARG 66
	PUSH 8
	CMPL
	JZ LOC_30678
	PUSHARG 66
	PUSHNR 2
	PUSH 48
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	INCN 66
	JMP LOC_30620
LOC_30678:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 3

}}

void function TwisterSword () {
__asm{
LOC_30694:
	STACK 3
	PUSH 1
	SETARG 51
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\038\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_30834
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_30834:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	PUSH 20
	CALL MoveCamera
	PUSHSTR "m038snd02"
	PUSH 200
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG 1
	PUSHARG 2
	PUSH 50
	CALL CreateTwisterSword
	PUSH 70
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 0

}}

void function RollTubCallback (arg_0, arg_1) callsign 39001 {
__asm{
	STACK 1
	INST_09 1
	PUSH 0
	CMP
	JZ LOC_30950
	PUSHSTR "m039snd02"
	PUSH 255
	PUSH 20
	CALL DelayAmbientSound
LOC_30950:
	PUSH 0
	POPN 1
LOC_30960:
	PUSHARG 1
	PUSH 8
	CMPL
	JZ LOC_309B8
	PUSHSTR "CreateRollTubBreak"
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	INCN 1
	JMP LOC_30960
LOC_309B8:
	PUSHARG -3
	PUSH 128
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG -3
	PUSH 251658240
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
	PUSH 1
	DELAY
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	INST_09 52
	PUSH 0
	CMP
	ORNZ
	JZ LOC_30A68
	PUSH 1
	SETARG 52
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CALL Hurt
	JMP LOC_30A88
LOC_30A68:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_30A88:
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function CreateRollTubBreak (arg_0) {
__asm{
	STACK 2
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
	PUSHARG -2
	PUSH 49002
	PUSH 49008
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSHARG 2
	PUSH 20
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 16384
	SYSCALL 0x1D, (2 | (0 << 16)) ; 0x001D 
	PUSHARG 1
	PUSHARG -2
	PUSHARG 2
	PUSH 4
	PUSH 20
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSHARG 2
	PUSH 36
	PUSH 60
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 8
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSH 8
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 1

}}

void function CreateRollTub (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSHARG -2
	DELAY
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 0
	PUSH 49001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 39001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 192
	PUSH 0
	PUSH 4
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSH 0
	POPN 3
LOC_30D08:
	PUSHARG 3
	PUSH 16
	CMPLE
	JZ LOC_30D5C
	PUSHARG 1
	PUSHARG 3
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 2
	DELAY
	INCN 3
	JMP LOC_30D08
LOC_30D5C:
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
LOC_30D78:
	PUSH 1
	DELAY
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_30DB4
	RETN 3
LOC_30DB4:
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 2
	PUSH 80
	CMPGE
	JNZ LOC_30D78
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function RollTub (arg_0) {
__asm{
LOC_30E18:
	STACK 7
	PUSH 0
	SETARG 1
	PUSH 0
	SETARG 52
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\039\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_30FC8
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_30FC8:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	SYSCALL 0x133, (0 | (1 << 16)) ; 0x0133 
	PUSH 40
	ADD
	POPN 7
	PUSHARG 1
	PUSH 96
	PUSH 9
	MUL
	ADD
	POPN 6
	PUSH 0
	POPN 4
LOC_31058:
	PUSHARG 4
	PUSHARG -2
	PUSH 1
	ADD
	CMPL
	JZ LOC_312B8
	PUSHARG 1
	PUSH 9
	PUSH 96
	MUL
	SUB
	POPN 5
LOC_310A8:
	PUSHARG 5
	PUSHARG 6
	CMPLE
	JZ LOC_3118C
	PUSHARG 4
	PUSH 0
	CMP
	JZ LOC_31128
	PUSHSTR "CreateRollTub"
	PUSHARG 5
	PUSHARG 7
	PUSH 52
	PUSH 57
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CALLBS
	JMP LOC_31168
LOC_31128:
	PUSHSTR "CreateRollTub"
	PUSHARG 5
	PUSHARG 7
	PUSH 2
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CALLBS
LOC_31168:
	PUSHARG 5
	PUSH 96
	ADD
	POPN 5
	JMP LOC_310A8
LOC_3118C:
	PUSH 4
	DELAY
	PUSHARG 4
	PUSH 0
	CMP
	JZ LOC_31250
	PUSHARG 1
	PUSH 9
	PUSH 96
	MUL
	SUB
	PUSHARG 7
	PUSH 200
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSH 15
	DELAY
	PUSHARG 1
	PUSHARG 2
	PUSH 140
	SUB
	PUSH 40
	CALL MoveCamera
	PUSHSTR "m039snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_31288
LOC_31250:
	PUSHARG 4
	PUSH 2
	CMP
	JZ LOC_31288
	PUSHSTR "m039snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
LOC_31288:
	PUSH 10
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 4
	JMP LOC_31058
LOC_312B8:
	PUSHSTR "CreateRollTub"
	INST_45
	PUSHSTR "CreateRollTubBreak"
	INST_45
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function EarthquakeCallback (arg_0, arg_1) callsign 40001 {
__asm{
	RETN 2

}}

void function CreateQuakeSmoke (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 1
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	PUSH 50002
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 0
	PUSHARG -3
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG -2
	PUSH 4
	SUB
	DELAY
	PUSHARG 1
	PUSH 512
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSH 4
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 5

}}

void function CreateQuakeStone (arg_0, arg_1, arg_2) {
__asm{
	STACK 2
	PUSHARG -2
	DELAY
	PUSH 0
	POPN 2
LOC_3140C:
	PUSHARG 2
	PUSH 4
	CMPL
	JZ LOC_31518
	PUSHSTR "CreateQuakeSmoke"
	PUSHARG -4
	PUSH 30
	NEG
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -3
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 0
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 8
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 2
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 2
	JMP LOC_3140C
LOC_31518:
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	PUSH 128
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSH 50001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 33554432
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 40001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSH 0
	POPN 2
LOC_315BC:
	PUSHARG 2
	PUSH 70
	CMPL
	JZ LOC_316E4
	PUSH 1
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 1
	CMP
	JZ LOC_316C8
	PUSHSTR "CreateQuakeSmoke"
	PUSHARG -4
	PUSH 30
	NEG
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -3
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSH 0
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 8
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_316C8:
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_315BC
LOC_316E4:
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function ShakeCamera (arg_0, arg_1, arg_2) {
__asm{
	STACK 1
	PUSH 0
	POPN 1
LOC_31728:
	PUSHARG 1
	PUSHARG -2
	CMPL
	JZ LOC_31810
	PUSHARG 1
	PUSH 3
	MOD
	PUSH 2
	CMP
	JZ LOC_317D0
	PUSHARG -4
	PUSH 15
	NEG
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG -3
	PUSH 15
	NEG
	PUSH 15
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
LOC_317D0:
	PUSH 1
	DELAY
	INST_09 53
	PUSH 1
	CMP
	JZ LOC_31800
	JMP LOC_31810
LOC_31800:
	INCN 1
	JMP LOC_31728
LOC_31810:
	RETN 3

}}

void function QuakeSound () {
__asm{
	STACK 1
	PUSH 0
	POPN 1
	PUSHSTR "m040snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
LOC_3184C:
	INST_09 53
	PUSH 0
	CMP
	JZ LOC_318D8
	PUSH 1
	DELAY
	INCN 1
	PUSHARG 1
	PUSH 99
	PUSH 20
	SUB
	CMPG
	JZ LOC_318D0
	PUSHSTR "m040snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	POPN 1
LOC_318D0:
	JMP LOC_3184C
LOC_318D8:
	RETN 0

}}

void function Earthquake () {
__asm{
LOC_318E0:
	STACK 4
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\040\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_31A70
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_31A70:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	PUSH 20
	CALL MoveCamera
	PUSH 10
	DELAY
	PUSH 0
	SETARG 53
	PUSHSTR "QuakeSound"
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "ShakeCamera"
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	PUSH 9999
	PUSH 0
	CALLBS
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	PUSH 2
	DIV
	PUSH 0
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 4
LOC_31BA8:
	PUSH 1
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG 4
	PUSH 3
	MOD
	PUSH 0
	CMP
	JZ LOC_31C20
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	JMP LOC_31C48
LOC_31C20:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 3
LOC_31C48:
	PUSHARG 3
	PUSH 0
	CMP
	PUSHARG 3
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	ORZ
	JZ LOC_31D1C
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	PUSH 10
	PUSH 40
	NEG
	PUSH 40
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	ADD
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	PUSH 10
	PUSH 30
	NEG
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	ADD
	POPN 2
	JMP LOC_31D54
LOC_31D1C:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
LOC_31D54:
	PUSHSTR "CreateQuakeStone"
	PUSHARG 1
	PUSHARG 2
	PUSH 2
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CALLBS
	DECN 4
	PUSHARG 4
	PUSH 0
	CMPG
	JNZ LOC_31BA8
	PUSHSTR "CreateQuakeStone"
	INST_45
	PUSH 28
	DELAY
	PUSH 1
	SETARG 53
	PUSH 60
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 0

}}

void function InterceptorCallback (arg_0, arg_1) callsign 41001 {
__asm{
	STACK 3
	PUSHSTR "Blood"
	PUSHARG -2
	PUSH 16
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_31EF4
	INST_09 54
	JZ LOC_31E94
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 54
	DIV
	POPN 3
LOC_31E94:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 3
	CALL Hurt
	PUSHARG 3
	PUSH 0
	CMPG
	JZ LOC_31EEC
	INST_09 54
	PUSH 2
	MUL
	SETARG 54
LOC_31EEC:
	JMP LOC_31F14
LOC_31EF4:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_31F14:
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 1
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPLE
	JZ LOC_31FB4
	PUSHARG -3
	PUSH 1
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 2
	PUSHARG -3
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSH 0
	PUSHARG 2
	INST_52 55
	JMP LOC_31FD8
LOC_31FB4:
	PUSHARG -3
	PUSH 0
	PUSHARG 1
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
LOC_31FD8:
	RETN 2

}}

void function CreateInterceptor (arg_0, arg_1, arg_2, arg_3) {
__asm{
LOC_31FE0:
	STACK 1
	PUSHARG -2
	INST_4F 55
	PUSH 0
	CMPZ
	JZ LOC_32014
	RETN 4
LOC_32014:
	PUSHARG -5
	SYSCALL 0x103, (1 | (1 << 16)) ; BattleXToScreenX 
	POPN -5
	PUSHARG -4
	SYSCALL 0x103, (1 | (1 << 16)) ; BattleXToScreenX 
	POPN -4
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	PUSHARG -3
	PUSH 51001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 41001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 0
	PUSH 3
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 1
	PUSH 1
	PUSHARG -2
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHARG 1
	PUSHARG -2
	INST_52 55
	RETN 4

}}

void function MakeInterceptorSound () {
__asm{
	STACK 1
	PUSH 0
	POPN 1
LOC_3214C:
	PUSHARG 1
	PUSH 5
	CMPL
	JZ LOC_321B8
	PUSHSTR "m041snd01"
	PUSH 128
	PUSHARG 1
	PUSH 15
	MUL
	ADD
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 12
	DELAY
	INCN 1
	JMP LOC_3214C
LOC_321B8:
	RETN 0

}}

void function Interceptor (arg_0) {
__asm{
LOC_321C0:
	STACK 5
	PUSH 1
	SETARG 54
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\041\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 12
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHSTR "m041snd02"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	SYSCALL 0x12D, (0 | (1 << 16)) ; GetBattleWidth 
	POPN 4
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_326B0
	PUSHARG -2
	JCOND 0, LOC_3238C
	JCOND 1, LOC_32418
	POP
	JMP LOC_32540
LOC_3238C:
	PUSH 0
	POPN 3
LOC_3239C:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_32410
	PUSHARG 4
	PUSH 2
	SUB
	PUSHARG 3
	PUSH 128
	PUSHARG 3
	CALL CreateInterceptor
	PUSHARG 3
	PUSH 2
	ADD
	POPN 3
	JMP LOC_3239C
LOC_32410:
	JMP LOC_32640
LOC_32418:
	PUSH 0
	POPN 3
LOC_32428:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_3249C
	PUSHARG 4
	PUSH 2
	SUB
	PUSHARG 3
	PUSH 128
	PUSHARG 3
	CALL CreateInterceptor
	PUSHARG 3
	PUSH 2
	ADD
	POPN 3
	JMP LOC_32428
LOC_3249C:
	PUSH 1
	POPN 3
LOC_324AC:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_32538
	PUSHARG 4
	PUSH 3
	SUB
	PUSHARG 3
	PUSH 128
	PUSH 15
	PUSHARG 3
	ADD
	PUSH 1
	SUB
	CALL CreateInterceptor
	PUSHARG 3
	PUSH 2
	ADD
	POPN 3
	JMP LOC_324AC
LOC_32538:
	JMP LOC_32640
LOC_32540:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x138, (1 | (0 << 16)) ; 0x0138 
	PUSH 0
	POPN 3
LOC_32570:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_325C4
	PUSHARG 4
	PUSHARG 3
	PUSH 128
	PUSHARG 3
	CALL CreateInterceptor
	INCN 3
	JMP LOC_32570
LOC_325C4:
	PUSH 0
	POPN 3
LOC_325D4:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_32640
	PUSHARG 4
	PUSH 1
	ADD
	PUSHARG 3
	PUSH 128
	PUSH 15
	PUSHARG 3
	ADD
	CALL CreateInterceptor
	INCN 3
	JMP LOC_325D4
LOC_32640:
	PUSHSTR "MakeInterceptorSound"
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	PUSH 280
	SUB
	PUSHARG 2
	PUSH 120
	SUB
	PUSH 40
	CALL MoveCamera
	JMP LOC_329E4
LOC_326B0:
	PUSHARG -2
	JCOND 0, LOC_326DC
	JCOND 1, LOC_32768
	POP
	JMP LOC_32884
LOC_326DC:
	PUSH 0
	POPN 3
LOC_326EC:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_32760
	PUSH 1
	PUSHARG 3
	PUSH 0
	PUSH 30
	PUSHARG 3
	ADD
	CALL CreateInterceptor
	PUSHARG 3
	PUSH 2
	ADD
	POPN 3
	JMP LOC_326EC
LOC_32760:
	JMP LOC_3298C
LOC_32768:
	PUSH 0
	POPN 3
LOC_32778:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_327EC
	PUSH 1
	PUSHARG 3
	PUSH 0
	PUSH 30
	PUSHARG 3
	ADD
	CALL CreateInterceptor
	PUSHARG 3
	PUSH 2
	ADD
	POPN 3
	JMP LOC_32778
LOC_327EC:
	PUSH 1
	POPN 3
LOC_327FC:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_3287C
	PUSH 2
	PUSHARG 3
	PUSH 0
	PUSH 45
	PUSHARG 3
	ADD
	PUSH 1
	SUB
	CALL CreateInterceptor
	PUSHARG 3
	PUSH 2
	ADD
	POPN 3
	JMP LOC_327FC
LOC_3287C:
	JMP LOC_3298C
LOC_32884:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x138, (1 | (0 << 16)) ; 0x0138 
	PUSH 0
	POPN 3
LOC_328B4:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_32918
	PUSH 1
	NEG
	PUSHARG 3
	PUSH 0
	PUSH 30
	PUSHARG 3
	ADD
	CALL CreateInterceptor
	INCN 3
	JMP LOC_328B4
LOC_32918:
	PUSH 0
	POPN 3
LOC_32928:
	PUSHARG 3
	PUSH 15
	CMPL
	JZ LOC_3298C
	PUSH 2
	NEG
	PUSHARG 3
	PUSH 0
	PUSH 45
	PUSHARG 3
	ADD
	CALL CreateInterceptor
	INCN 3
	JMP LOC_32928
LOC_3298C:
	PUSHSTR "MakeInterceptorSound"
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 280
	PUSHARG 2
	PUSH 120
	SUB
	PUSH 40
	CALL MoveCamera
LOC_329E4:
	PUSH 60
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSH 30
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function XCallDragonCallback (arg_0, arg_1) callsign 42001 {
__asm{
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	INST_09 116
	PUSH 0
	CMP
	ORNZ
	JZ LOC_32B20
	PUSHARG -3
	PUSHARG -2
	PUSH 2
	CALL Hurt
	PUSH 1
	SETARG 116
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
	JMP LOC_32B6C
LOC_32B20:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_32B6C:
	RETN 2

}}

void function Xsc3601 (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSH 10
	PUSH 50
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	PUSHARG -5
	PUSH 28001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSH 60
	POPN 2
LOC_32BE8:
	PUSHARG 2
	PUSH 0
	CMPG
	JZ LOC_32C54
	INCN -2
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	DECN 2
	PUSH 1
	DELAY
	JMP LOC_32BE8
LOC_32C54:
	PUSH 30
	DELAY
	PUSHSTR "Xsc3602"
	PUSHARG -6
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	CALLBS
	PUSH 0
	POPN 2
LOC_32C9C:
	PUSHARG 2
	PUSH 10
	CMPL
	JZ LOC_32D10
	PUSHARG 1
	PUSH 0
	PUSH 65536
	PUSHARG 2
	PUSH 65536
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_32C9C
LOC_32D10:
	PUSHARG 2
	PUSH 30
	CMPL
	JZ LOC_32DD8
	PUSHARG -2
	PUSHARG 2
	PUSH 10
	MUL
	ADD
	POPN -2
	PUSHARG 1
	PUSH 0
	PUSH 65536
	PUSHARG 2
	PUSH 65536
	MUL
	ADD
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_32D10
LOC_32DD8:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 5

}}

void function Xsc3602 (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 6
	PUSHARG -5
	JCOND 0, LOC_32E28
	JCOND 1, LOC_32E40
	POP
	JMP LOC_32E58
LOC_32E28:
	PUSH 10
	POPN 5
	JMP LOC_32E68
LOC_32E40:
	PUSH 20
	POPN 5
	JMP LOC_32E68
LOC_32E58:
	PUSH 20
	POPN 5
LOC_32E68:
	PUSH 0
	POPN 1
LOC_32E78:
	PUSHARG 1
	PUSHARG 5
	CMPL
	JZ LOC_32FDC
	PUSHARG -4
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	PUSHARG -3
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 3
	PUSHARG 2
	PUSHARG 3
	PUSHARG -2
	PUSH 20
	ADD
	PUSH 0
	PUSH 28002
	PUSH 28004
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 6
	PUSHARG 6
	PUSH 0
	PUSH 10
	PUSH 30
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHSTR "m016a"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	PUSH 5
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 1
	JMP LOC_32E78
LOC_32FDC:
	PUSH 15
	DELAY
	RETN 4

}}

void function Xsc3603 (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 3
	PUSHARG -4
	PUSHARG -3
	PUSH 320
	PUSH 360
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 28012
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
	PUSH 4
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSH 2
	PUSH 3
	PUSHARG -5
	MUL
	ADD
	POPN 1
LOC_3308C:
	PUSHARG 1
	DECN 1
	PUSH 0
	CMPG
	JZ LOC_3318C
	PUSHARG -4
	PUSH 320
	NEG
	PUSH 320
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	PUSHARG -3
	PUSH 100
	NEG
	PUSH 300
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 3
	PUSHARG 2
	PUSHARG 3
	PUSH 320
	PUSH 360
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 28012
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
	PUSH 4
	PUSH 10
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	JMP LOC_3308C
LOC_3318C:
	RETN 4

}}

void function Xsc2512 (arg_0) {
__asm{
	STACK 2
	PUSH 16384
	POPN 1
	PUSHARG -2
	PUSH 4
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 2
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG -2
	PUSH 8192
	SYSCALL 0x21, (2 | (0 << 16)) ; 0x0021 
	PUSH 30
	PUSH 40
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 2
LOC_3323C:
	PUSHARG 2
	DECN 2
	PUSH 0
	CMPG
	JZ LOC_332B4
	PUSHARG -2
	PUSHARG 1
	PUSHARG 1
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 256
	SUB
	POPN 1
	PUSH 1
	DELAY
	JMP LOC_3323C
LOC_332B4:
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 1

}}

void function Xsc3604 () callsign 42002 {
__asm{
	STACK 3
	SYSCALL 0xB, (0 | (1 << 16)) ; 0x000B 
	POPN 3
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x8, (1 | (0 << 16)) ; 0x0008 
	PUSHSTR "MovingShadow"
	PUSHARG 3
	INST_09 115
	PUSH 28011
	PUSH 0
	PUSH 42001
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "MovingShadow"
	PUSHARG 3
	INST_09 115
	PUSH 28011
	PUSH 128
	PUSH 42001
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "MovingShadow"
	PUSHARG 3
	INST_09 115
	PUSH 28011
	PUSH 64
	PUSH 42001
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "MovingShadow"
	PUSHARG 3
	INST_09 115
	PUSH 28011
	PUSH 192
	PUSH 42001
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHARG 3
	PUSH 0
	PUSH 0
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
	PUSHARG 3
	PUSH 0
	SYSCALL 0x1E, (2 | (0 << 16)) ; 0x001E 
	PUSH 0
	POPN 2
LOC_33440:
	PUSHARG 2
	PUSH 20
	CMPL
	JZ LOC_33504
	PUSHARG 3
	PUSH 10003
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 16384
	PUSH 16384
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "Xsc2512"
	PUSHARG 1
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	INCN 2
	JMP LOC_33440
LOC_33504:
	PUSHARG 1
	PUSHSTR "m018snd03"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	RETN 0

}}

void function XCallDragon (arg_0) {
__asm{
	STACK 13
	PUSH 0
	SETARG 116
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_335B4
	PUSH 0
	POPN 10
	JMP LOC_335C4
LOC_335B4:
	PUSH 128
	POPN 10
LOC_335C4:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHSTR "m018snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	JCOND 0, LOC_33660
	JCOND 1, LOC_336B4
	POP
	JMP LOC_33708
LOC_33660:
	PUSHSTR "Xsc3602"
	PUSHARG -2
	PUSHARG 1
	PUSHARG 2
	PUSHARG 3
	CALLBS
	PUSH 50
	POPN 11
	PUSH 110
	SETARG 115
	JMP LOC_33770
LOC_336B4:
	PUSHSTR "Xsc3602"
	PUSHARG -2
	PUSHARG 1
	PUSHARG 2
	PUSHARG 3
	CALLBS
	PUSH 100
	POPN 11
	PUSH 220
	SETARG 115
	JMP LOC_33770
LOC_33708:
	PUSHSTR "Xsc3601"
	PUSHARG -2
	PUSHARG 10
	PUSHARG 1
	PUSHARG 2
	PUSHARG 3
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 100
	PUSH 95
	ADD
	POPN 11
	PUSH 330
	SETARG 115
LOC_33770:
	PUSH 0
	POPN 4
LOC_33780:
	PUSHARG 4
	PUSHARG 11
	CMPL
	JZ LOC_33B8C
	PUSH 1
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 12
	PUSH 0
	POPN 5
LOC_337D0:
	PUSHARG 5
	PUSHARG 12
	CMPL
	JZ LOC_33984
	PUSHARG 1
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 7
	PUSHARG 2
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 8
	PUSHARG -2
	PUSH 2
	CMP
	JZ LOC_33928
	PUSHARG 7
	PUSH 48
	SUB
	PUSHARG 8
	PUSHARG 9
	PUSH 0
	PUSH 28006
	PUSH 28007
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
	PUSHARG 7
	PUSH 48
	ADD
	PUSHARG 8
	PUSHARG 9
	PUSH 0
	PUSH 28006
	PUSH 28007
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
	JMP LOC_33974
LOC_33928:
	PUSHARG 7
	PUSHARG 8
	PUSHARG 9
	PUSH 0
	PUSH 28006
	PUSH 28007
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POP
LOC_33974:
	INCN 5
	JMP LOC_337D0
LOC_33984:
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	CMP
	JZ LOC_33ACC
	PUSHARG 1
	PUSH 48
	NEG
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 7
	PUSHARG 2
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 8
	PUSHARG 7
	PUSHARG 8
	PUSHARG 9
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 28008
	PUSH 28009
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 13
	PUSHARG 13
	PUSH 10
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 10
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x17, (3 | (0 << 16)) ; 0x0017 
LOC_33ACC:
	PUSH 1
	DELAY
	PUSHARG 4
	JCOND 49, LOC_33B10
	JCOND 99, LOC_33B34
	JCOND 149, LOC_33B58
	POP
	JMP LOC_33B7C
LOC_33B10:
	PUSHSTR "m018snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_33B7C
LOC_33B34:
	PUSHSTR "m018snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_33B7C
LOC_33B58:
	PUSHSTR "m018snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	JMP LOC_33B7C
LOC_33B7C:
	INCN 4
	JMP LOC_33780
LOC_33B8C:
	PUSHARG -2
	PUSH 1
	CMPG
	JZ LOC_33BBC
	PUSHSTR "Xsc3601"
	INST_45
	JMP LOC_33BC8
LOC_33BBC:
	PUSHSTR "Xsc3602"
	INST_45
LOC_33BC8:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 13
	PUSHARG 13
	PUSH 0
	CMP
	JZ LOC_33C1C
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 13
LOC_33C1C:
	PUSHARG 13
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 13
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 13
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHARG 2
	PUSH 240
	CMPG
	JZ LOC_33CC0
	PUSHARG 1
	PUSHARG 2
	PUSH 240
	SUB
	PUSH 20
	CALL MoveCamera
	JMP LOC_33CE0
LOC_33CC0:
	PUSHARG 1
	PUSH 0
	PUSH 20
	CALL MoveCamera
LOC_33CE0:
	PUSHARG 13
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_33D5C
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 13
	PUSHARG 13
	PUSH 0
	CMP
	JZ LOC_33D5C
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 13
LOC_33D5C:
	PUSHARG 13
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 13
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 13
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 3
	PUSHSTR "Xsc3603"
	PUSHARG -2
	PUSHARG 1
	PUSHARG 2
	PUSHARG 3
	CALLBS
	PUSHSTR "Xsc3603"
	INST_45
	PUSH 65
	DELAY
	RETN 1

}}

void function XFireCowCallback (arg_0, arg_1) callsign 42003 {
__asm{
	STACK 2
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_33EFC
	PUSHARG -3
	PUSH 2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	INST_09 117
	JZ LOC_33E70
	PUSH 2
	INST_09 117
	DIV
	POPN 2
LOC_33E70:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 2
	CALL Hurt
	PUSHARG 2
	PUSH 0
	CMPG
	JZ LOC_33EF4
	INST_09 117
	PUSH 2
	MUL
	SETARG 117
	PUSHSTR "LockTargetTime2"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_33EF4:
	JMP LOC_33F74
LOC_33EFC:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
	PUSHSTR "Blood"
	PUSHARG -2
	PUSH 16
	PUSH 0
	PUSH 0
	CALLBS
LOC_33F74:
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 1
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPLE
	JZ LOC_33FE8
	PUSHARG -3
	PUSH 2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_3400C
LOC_33FE8:
	PUSHARG -3
	PUSH 0
	PUSHARG 1
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
LOC_3400C:
	RETN 2

}}

void function XAttachFireToCow (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -3
	PUSH 37002
	PUSHARG -2
	PUSH 50
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 131072
	PUSH 131072
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 12
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSHARG -3
	PUSH 37002
	PUSHARG -2
	PUSH 50
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSH 131072
	PUSH 131072
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 2
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 12
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
LOC_3413C:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_34298
	PUSHARG 1
	PUSHARG -3
	PUSHARG -2
	PUSH 24
	PUSH 50
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSHARG 2
	PUSHARG -3
	PUSHARG -2
	PUSH 128
	SUB
	PUSH 20
	PUSH 50
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 2
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	PUSH 1
	DELAY
	JMP LOC_3413C
LOC_34298:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function XCreateFireCow (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 3
	PUSHARG -6
	PUSH 8
	PUSH 6
	NEG
	PUSH 6
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	ADD
	PUSHARG -5
	PUSH 8
	PUSH 8
	NEG
	PUSH 8
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	ADD
	PUSH 0
	PUSHARG -4
	PUSH 37001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSH 8
	PUSH 2
	NEG
	PUSH 2
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 42003
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 0
	PUSH 8
	PUSH 4
	NEG
	PUSH 4
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSHSTR "XAttachFireToCow"
	PUSHARG 1
	PUSHARG -4
	PUSH 128
	ADD
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 1
	POPN 3
LOC_34490:
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_34668
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_34544
	PUSHARG 2
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	PUSH 100
	SUB
	CMPG
	JZ LOC_3453C
	PUSHARG 1
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_34668
LOC_3453C:
	JMP LOC_3458C
LOC_34544:
	PUSHARG 2
	PUSH 100
	CMPL
	JZ LOC_3458C
	PUSHARG 1
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_34668
LOC_3458C:
	PUSH 1
	DELAY
	INCN 3
	PUSHARG 3
	PUSH 7
	AND
	PUSH 0
	CMP
	JZ LOC_34618
	PUSHARG 1
	PUSH 0
	PUSH 8
	PUSH 3
	NEG
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	MUL
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_34618:
	PUSHARG 3
	PUSH 500
	CMPG
	JZ LOC_34660
	PUSHARG 1
	PUSH 16
	PUSH 2
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	JMP LOC_34668
LOC_34660:
	JMP LOC_34490
LOC_34668:
	RETN 5

}}

void function XFireCow (arg_0) {
__asm{
	STACK 5
	PUSH 1
	SETARG 117
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_34708
	PUSH 1
	NEG
	POPN 4
	PUSH 0
	POPN 3
	JMP LOC_34728
LOC_34708:
	PUSH 1
	POPN 4
	PUSH 128
	POPN 3
LOC_34728:
	PUSHINV 5 ; INTV_IS_RIGHT
	CALL GetSoldierMaxX
	POPN 5
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_34764
	JMP LOC_34764
LOC_34764:
	PUSH 15
	DELAY
	PUSHSTR "m027snd01"
	PUSH 180
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "m027snd02"
	PUSH 180
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_34958
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 75
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 75
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 225
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSHARG -2
	PUSH 1
	ADD
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 225
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_3503C
LOC_34958:
	PUSHARG -2
	PUSH 1
	CMP
	JZ LOC_34C1C
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 350
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 250
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 150
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSHARG -2
	PUSH 1
	ADD
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 150
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 250
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 350
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	JMP LOC_3503C
LOC_34C1C:
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 400
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 320
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 240
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 160
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 80
	ADD
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSHARG -2
	PUSH 1
	ADD
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 80
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 160
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 240
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 320
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSHSTR "XCreateFireCow"
	PUSHARG 5
	PUSH 1200
	PUSHARG 4
	MUL
	ADD
	PUSH 562
	PUSH 400
	SUB
	PUSHARG 3
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
LOC_3503C:
	PUSH 110
	PUSH 160
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	PUSHSTR "m027snd02"
	PUSH 210
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 10
	DELAY
	PUSHSTR "m027snd01"
	PUSH 160
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "XCreateFireCow"
	INST_45
	PUSH 60
	DELAY
	RETN 1

}}

void function XSparkCallback (arg_0, arg_1) callsign 42004 {
__asm{
	STACK 2
	PUSHARG -3
	PUSH 0
	SYSCALL 0x2F, (2 | (1 << 16)) ; GetCallbackContext 
	POPN 1
	PUSHARG 1
	PUSH 4660
	CMP
	JZ LOC_35120
	PUSH 2
	POPN 2
	JMP LOC_35130
LOC_35120:
	PUSH 2
	POPN 2
LOC_35130:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 2
	CALL Hurt
	PUSHSTR "SmallFireBall3"
	PUSHARG -3
	PUSHARG -2
	PUSH 20
	PUSH 0
	CALLBS
	RETN 2

}}

void function XDecreaseHP () {
__asm{
	STACK 1
	PUSH 1
	POPN 1
LOC_3519C:
	PUSHARG 1
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	PUSH 4
	SUB
	CMPLE
	JZ LOC_35204
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 0
	PUSH 1
	SYSCALL 0x125, (3 | (0 << 16)) ; 0x0125 
	PUSH 4
	DELAY
	INCN 1
	JMP LOC_3519C
LOC_35204:
	RETN 0

}}

void function XCreateSparkleCenter (arg_0, arg_1) {
__asm{
	STACK 6
	PUSHARG -2
	DELAY
	PUSHARG -3
	PUSH 42001
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 73728
	PUSH 73728
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 1
	SYSCALL 0x107, (1 | (1 << 16)) ; 0x0107 
	POPN 6
	PUSH 60
	PUSH 80
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
	PUSH 0
	POPN 2
LOC_35300:
	PUSHARG 2
	PUSHARG 3
	PUSH 4
	DIV
	CMPL
	JZ LOC_353B8
	PUSH 6
	DELAY
	PUSHARG 1
	PUSHARG 4
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	PUSHARG 5
	PUSHARG 6
	PUSH 16
	NEG
	PUSH 16
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	INCN 2
	JMP LOC_35300
LOC_353B8:
	PUSHARG 1
	PUSHARG 4
	PUSHARG 5
	PUSHARG 6
	SYSCALL 0x14, (4 | (0 << 16)) ; 0x0014 
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function XCreateSparkle (arg_0) {
__asm{
LOC_35410:
	STACK 4
	PUSHSTR "m032snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG -2
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN -2
	PUSHARG -2
	PUSH 42004
	PUSH 0
	PUSH 48
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSH 42004
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 0
	PUSH 4660
	SYSCALL 0x2E, (3 | (0 << 16)) ; SetCallbackContext 
	PUSH 4
	DELAY
	PUSHARG 1
	PUSH 8
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -2
	PUSH 42002
	PUSH 0
	PUSH 48
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHSTR "XCreateSparkleCenter"
	PUSHARG 1
	PUSH 0
	PUSH 1
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XCreateSparkleCenter"
	PUSHARG 1
	PUSH 20
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XCreateSparkleCenter"
	PUSHARG 1
	PUSH 20
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XCreateSparkleCenter"
	PUSHARG 1
	PUSH 20
	PUSH 48
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XDecreaseHP"
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XCreateSparkleCenter"
	INST_45
	PUSHSTR "m032snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHARG 1
	PUSH 42003
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSH 4096
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSH 0
	POPN 4
LOC_35768:
	PUSHARG 4
	PUSH 256
	CMPL
	JZ LOC_357F4
	PUSHSTR "LockByCenter"
	PUSHARG -2
	PUSH 2501
	PUSHARG 4
	PUSH 52
	PUSH 2
	PUSH 33554432
	PUSH 42004
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
	PUSHARG 4
	PUSH 32
	ADD
	POPN 4
	JMP LOC_35768
LOC_357F4:
	PUSH 0
	POPN 4
LOC_35804:
	PUSHARG 4
	PUSH 256
	CMPL
	JZ LOC_35890
	PUSHSTR "LockByCenter"
	PUSHARG -2
	PUSH 2501
	PUSHARG 4
	PUSH 110
	PUSH 2
	PUSH 33554432
	PUSH 42004
	SYSCALL 0x312, (8 | (0 << 16)) ; 0x0312 
	PUSHARG 4
	PUSH 32
	ADD
	POPN 4
	JMP LOC_35804
LOC_35890:
	PUSH 2
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_358C0:
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_358F0
	PUSH 1
	DELAY
	JMP LOC_358C0
LOC_358F0:
	PUSH 8
	DELAY
	PUSHARG 2
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 1

}}

void function XSparkle (arg_0) {
__asm{
	STACK 3
	PUSH 260
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 5
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 3
	CALL XCreateSparkle
	PUSH 60
	DELAY
	RETN 1

}}

void function MoveEnemyDelay (arg_0, arg_1) {
__asm{
	STACK 2
	PUSHARG -2
	DELAY
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSHARG -3
	CALL MoveCamera
	RETN 2

}}

void function FinalX1 () {
__asm{
LOC_35A84:
	STACK 2
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\032\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\027\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\018\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHSTR "XCallDragon"
	PUSH 2
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XFireCow"
	PUSH 2
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XSparkle"
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "MoveEnemyDelay"
	PUSH 40
	PUSH 300
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XCallDragon"
	INST_45
	PUSHSTR "XFireCow"
	INST_45
	PUSHSTR "XSparkle"
	INST_45
	PUSH 20
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 0

}}

void function XFirePillarCallback (arg_0, arg_1) callsign 43001 {
__asm{
	STACK 1
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_35DDC
	INST_09 118
	JZ LOC_35D44
	PUSH 2
	INST_09 118
	DIV
	POPN 1
LOC_35D44:
	PUSHARG -3
	PUSHARG -2
	PUSHARG 1
	CALL Hurt
	PUSHARG 1
	PUSH 0
	CMPG
	JZ LOC_35DD4
	INST_09 118
	PUSH 2
	MUL
	SETARG 118
	PUSHARG -3
	PUSHARG -2
	PUSH 11002
	PUSH 1
	PUSH 48
	PUSH 0
	CALL HitGeneral
LOC_35DD4:
	JMP LOC_35E28
LOC_35DDC:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
	PUSHSTR "FireMan"
	PUSHARG -2
	PUSH 10015
	PUSH 60
	PUSH 0
	CALLBS
LOC_35E28:
	RETN 2

}}

void function XCreateFirePillarSource (arg_0, arg_1, arg_2) {
__asm{
	STACK 2
	PUSHARG -4
	PUSH 41001
	PUSH 0
	PUSH 8
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -4
	PUSHARG -2
	PUSHARG -3
	PUSH 8
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHSTR "m031snd03"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 8
	DELAY
	PUSHARG -3
	POPN 2
LOC_35ED8:
	PUSHARG 2
	PUSH 0
	CMPG
	JZ LOC_35F80
	PUSHARG 1
	PUSHARG -4
	PUSHARG -2
	PUSHARG 2
	PUSH 8
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG -2
	PUSH 1
	ADD
	PUSH 255
	AND
	POPN -2
	PUSHARG 2
	PUSH 8
	SUB
	POPN 2
	JMP LOC_35ED8
LOC_35F80:
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 3

}}

void function XCreateFirePillarLight (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
LOC_35FAC:
	STACK 3
	PUSHARG -6
	PUSH 41009
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSH 43001
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 32768
	PUSH 24576
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -6
	PUSH 41010
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 3
	PUSHARG 3
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 3
	PUSH 32768
	PUSH 16384
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 0
	POPN 2
LOC_36120:
	PUSHARG 2
	PUSHARG -2
	CMPL
	JZ LOC_362A8
	PUSHARG -5
	PUSH 4
	ADD
	PUSH 255
	AND
	POPN -5
	PUSHARG -4
	PUSH 6
	ADD
	POPN -4
	PUSH 1
	DELAY
	PUSHARG 1
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 3
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG -3
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 2
	PUSHARG -2
	PUSH 16
	SUB
	CMP
	JZ LOC_36298
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 3
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_36298:
	INCN 2
	JMP LOC_36120
LOC_362A8:
	RETN 5

}}

void function XCreateFirePillarBomb (arg_0, arg_1, arg_2, arg_3) {
__asm{
	STACK 2
	PUSHARG -5
	PUSH 2501
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN -5
	PUSHARG -5
	PUSH 41008
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG 1
	PUSH 32768
	PUSH 65536
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG 1
	PUSHARG -2
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSHARG 1
	PUSHARG -2
	CALL XCreateFirePillarLight
	PUSHARG -5
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 4

}}

void function XCreateFirePillar (arg_0, arg_1) {
__asm{
LOC_363E8:
	STACK 6
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 2501
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSH 0
	PUSH 255
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 3
	PUSH 0
	POPN 2
LOC_36460:
	PUSHARG 2
	PUSH 4
	CMPL
	JZ LOC_364E0
	PUSHSTR "XCreateFirePillarSource"
	PUSHARG 1
	PUSH 320
	PUSHARG 3
	PUSH 0
	CALLBS
	PUSHARG 3
	PUSH 64
	ADD
	PUSH 255
	AND
	POPN 3
	INCN 2
	JMP LOC_36460
LOC_364E0:
	PUSHSTR "XCreateFirePillarSource"
	INST_45
	PUSH 8
	DELAY
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 2501
	PUSH 0
	PUSH 60
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	ADD
	PUSHARG -2
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	SUB
	PUSHARG -2
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 50
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 50
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	ADD
	PUSHARG -2
	PUSH 50
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	ADD
	PUSHARG -2
	PUSH 50
	SUB
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	SUB
	PUSHARG -2
	PUSH 50
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 60
	SUB
	PUSHARG -2
	PUSH 50
	SUB
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	ADD
	PUSHARG -2
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	SUB
	PUSHARG -2
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 100
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSHARG -2
	PUSH 100
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	ADD
	PUSHARG -2
	PUSH 100
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	ADD
	PUSHARG -2
	PUSH 100
	SUB
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	SUB
	PUSHARG -2
	PUSH 100
	ADD
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG -3
	PUSH 120
	SUB
	PUSHARG -2
	PUSH 100
	SUB
	PUSH 2501
	PUSH 60
	PUSH 2
	PUSH 43001
	PUSH 2
	PUSH 3
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "m031snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	POPN 2
LOC_36C6C:
	PUSHARG 2
	PUSH 4
	CMPL
	JZ LOC_36D18
	PUSHARG 1
	PUSH 41002
	PUSHARG 2
	ADD
	PUSH 0
	PUSH 12
	NEG
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 4
	PUSH 4
	DELAY
	PUSHARG 2
	PUSH 3
	CMPL
	JZ LOC_36D08
	PUSHARG 4
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_36D08:
	INCN 2
	JMP LOC_36C6C
LOC_36D18:
	PUSH 65536
	POPN 2
LOC_36D28:
	PUSHARG 2
	PUSH 131072
	CMPL
	JZ LOC_36D98
	PUSHARG 4
	PUSH 65536
	PUSHARG 2
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 2
	DELAY
	PUSHARG 2
	PUSH 8192
	ADD
	POPN 2
	JMP LOC_36D28
LOC_36D98:
	PUSH 40
	DELAY
	PUSHSTR "m031snd02"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "XCreateFirePillarBomb"
	PUSHARG 4
	PUSH 32
	PUSH 10
	PUSH 70
	CALLBS
	PUSHSTR "XCreateFirePillarBomb"
	PUSHARG 4
	PUSH 96
	PUSH 10
	PUSH 70
	CALLBS
	PUSHSTR "XCreateFirePillarBomb"
	PUSHARG 4
	PUSH 160
	PUSH 10
	PUSH 70
	CALLBS
	PUSHSTR "XCreateFirePillarBomb"
	PUSHARG 4
	PUSH 224
	PUSH 10
	PUSH 70
	CALLBS
	PUSHARG 4
	PUSH 4096
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSHARG 4
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function XFirePillar (arg_0) {
__asm{
	STACK 3
	PUSH 1
	SETARG 118
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x129, (1 | (1 << 16)) ; 0x0129 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_36F70
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_36F70:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 180
	SUB
	PUSH 60
	CALL MoveCamera
	PUSHARG 1
	PUSHARG 2
	CALL XCreateFirePillar
	PUSHSTR "XCreateFirePillarBomb"
	INST_45
	PUSH 60
	DELAY
	RETN 1

}}

void function XTaiChiCallback (arg_0, arg_1) callsign 43002 {
__asm{
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	JZ LOC_370B8
	INST_09 119
	PUSH 4
	CMPL
	JZ LOC_37094
	PUSHARG -3
	PUSHARG -2
	PUSH 2
	INST_09 119
	DIV
	CALL Hurt
	INST_09 119
	PUSH 2
	MUL
	SETARG 119
	JMP LOC_370B0
LOC_37094:
	PUSHARG -3
	PUSH 16777216
	SYSCALL 0x2B, (2 | (0 << 16)) ; 0x002B 
LOC_370B0:
	JMP LOC_370D8
LOC_370B8:
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	CALL Hurt
LOC_370D8:
	RETN 2

}}

void function XCreateTaiChiBomb (arg_0, arg_1) {
__asm{
	STACK 3
	PUSH 8
	DELAY
	PUSHARG -3
	PUSH 35002
	PUSH 0
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG 1
	PUSH 4096
	PUSH 4096
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSHARG -2
	JZ LOC_371A0
	PUSHARG 1
	PUSH 43002
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHARG 1
	PUSH 33554432
	PUSH 16777216
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
LOC_371A0:
	PUSHARG 1
	PUSH 4096
	NEG
	SYSCALL 0x25, (2 | (0 << 16)) ; 0x0025 
	PUSH 20
	DELAY
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 3
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	ADD
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	SUB
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 50
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 50
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	ADD
	PUSHARG 3
	PUSH 50
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	ADD
	PUSHARG 3
	PUSH 50
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	SUB
	PUSHARG 3
	PUSH 50
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 64
	SUB
	PUSHARG 3
	PUSH 50
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	ADD
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	SUB
	PUSHARG 3
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 100
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 100
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	ADD
	PUSHARG 3
	PUSH 100
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	ADD
	PUSHARG 3
	PUSH 100
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	SUB
	PUSHARG 3
	PUSH 100
	ADD
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSH 128
	SUB
	PUSHARG 3
	PUSH 100
	SUB
	PUSH 2501
	PUSH 0
	PUSH 20
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSHSTR "LockTargetXY"
	PUSHARG 2
	PUSHARG 3
	PUSH 150
	ADD
	PUSH 2501
	PUSH 0
	PUSH 16
	PUSH 43002
	PUSH 0
	PUSH 0
	PUSH 33554432
	SYSCALL 0x314, (10 | (0 << 16)) ; 0x0314 
	PUSH 20
	DELAY
	PUSHARG 1
	PUSH 16
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
	RETN 2

}}

void function XCreateTaichi (arg_0, arg_1) {
__asm{
	STACK 3
	PUSHARG -3
	PUSHARG -2
	PUSH 0
	PUSH 0
	PUSH 35001
	SYSCALL 0x10, (5 | (1 << 16)) ; CreateObjectRaw 
	POPN 1
	PUSHARG 1
	PUSH 2
	SYSCALL 0x31, (2 | (0 << 16)) ; 0x0031 
	PUSHARG 1
	PUSH 98304
	PUSH 98304
	SYSCALL 0x1B, (3 | (0 << 16)) ; 0x001B 
	PUSH 0
	POPN 2
LOC_37A18:
	PUSHARG 2
	PUSH 16
	CMPLE
	JZ LOC_37A6C
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	INCN 2
	JMP LOC_37A18
LOC_37A6C:
	PUSHSTR "m025snd01"
	PUSH 220
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSH 0
	POPN 2
LOC_37A98:
	PUSHARG 2
	PUSH 3
	CMPL
	JZ LOC_37B14
	PUSHSTR "XCreateTaiChiBomb"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	CMP
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 10
	PUSHARG 2
	SUB
	DELAY
	INCN 2
	JMP LOC_37A98
LOC_37B14:
	PUSH 30
	DELAY
	PUSH 16
	POPN 2
LOC_37B30:
	PUSHARG 2
	PUSH 0
	CMPGE
	JZ LOC_37B84
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 1
	DELAY
	DECN 2
	JMP LOC_37B30
LOC_37B84:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 2

}}

void function XTaiChi (arg_0) {
__asm{
	STACK 15
	PUSH 1
	SETARG 119
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSH 0
	POPN 4
LOC_37C00:
	PUSHARG 4
	PUSHARG -2
	PUSH 1
	ADD
	CMPL
	JZ LOC_388C8
	PUSH 0
	POPN 5
LOC_37C38:
	PUSHARG 5
	PUSH 5
	CMPL
	JZ LOC_388AC
	PUSHARG 5
	PUSH 0
	CMP
	JZ LOC_37D24
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	SYSCALL 0x10D, (1 | (1 << 16)) ; GetRandomSoldierHandleFromAlive 
	POPN 3
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_37CC4
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	POPN 3
LOC_37CC4:
	PUSHARG 3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 6
	PUSHARG 3
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 7
	PUSHARG 6
	POPN 1
	PUSHARG 7
	POPN 2
	JMP LOC_38850
LOC_37D24:
	PUSHARG 5
	PUSH 1
	CMP
	JZ LOC_37FF8
	PUSHARG 6
	PUSH 200
	PUSH 260
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 1
	PUSHARG 7
	PUSH 220
	PUSH 270
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	PUSHARG 1
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 9
	PUSHARG 2
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 10
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMPG
	JZ LOC_37FF0
	PUSH 0
	POPN 12
LOC_37E4C:
	PUSHARG 12
	PUSHARG 8
	PUSH 2
	DIV
	CMPL
	JZ LOC_37FF0
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	PUSH 0
	PUSHARG 8
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 11
	PUSHARG 11
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	JZ LOC_37FE0
	PUSHARG 11
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 13
	PUSHARG 11
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 14
	PUSHARG 13
	PUSHARG 6
	SUB
	PUSHARG 13
	PUSHARG 6
	SUB
	MUL
	PUSHARG 14
	PUSHARG 7
	SUB
	PUSHARG 14
	PUSHARG 7
	SUB
	MUL
	ADD
	POPN 15
	PUSHARG 15
	PUSH 72200
	CMPGE
	JZ LOC_37FE0
	PUSHARG 13
	POPN 1
	PUSHARG 14
	POPN 2
	JMP LOC_37FF0
LOC_37FE0:
	INCN 12
	JMP LOC_37E4C
LOC_37FF0:
	JMP LOC_38850
LOC_37FF8:
	PUSHARG 5
	PUSH 2
	CMP
	JZ LOC_382CC
	PUSHARG 6
	PUSH 200
	PUSH 260
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 1
	PUSHARG 7
	PUSH 220
	PUSH 270
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 2
	PUSHARG 1
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 9
	PUSHARG 2
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 10
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMPG
	JZ LOC_382C4
	PUSH 0
	POPN 12
LOC_38120:
	PUSHARG 12
	PUSHARG 8
	PUSH 2
	DIV
	CMPL
	JZ LOC_382C4
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	PUSH 0
	PUSHARG 8
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 11
	PUSHARG 11
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	JZ LOC_382B4
	PUSHARG 11
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 13
	PUSHARG 11
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 14
	PUSHARG 13
	PUSHARG 6
	SUB
	PUSHARG 13
	PUSHARG 6
	SUB
	MUL
	PUSHARG 14
	PUSHARG 7
	SUB
	PUSHARG 14
	PUSHARG 7
	SUB
	MUL
	ADD
	POPN 15
	PUSHARG 15
	PUSH 72200
	CMPGE
	JZ LOC_382B4
	PUSHARG 13
	POPN 1
	PUSHARG 14
	POPN 2
	JMP LOC_382C4
LOC_382B4:
	INCN 12
	JMP LOC_38120
LOC_382C4:
	JMP LOC_38850
LOC_382CC:
	PUSHARG 5
	PUSH 3
	CMP
	JZ LOC_385A0
	PUSHARG 6
	PUSH 200
	PUSH 260
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 1
	PUSHARG 7
	PUSH 220
	PUSH 270
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	ADD
	POPN 2
	PUSHARG 1
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 9
	PUSHARG 2
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 10
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMPG
	JZ LOC_38598
	PUSH 0
	POPN 12
LOC_383F4:
	PUSHARG 12
	PUSHARG 8
	PUSH 2
	DIV
	CMPL
	JZ LOC_38598
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	PUSH 0
	PUSHARG 8
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 11
	PUSHARG 11
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	JZ LOC_38588
	PUSHARG 11
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 13
	PUSHARG 11
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 14
	PUSHARG 13
	PUSHARG 6
	SUB
	PUSHARG 13
	PUSHARG 6
	SUB
	MUL
	PUSHARG 14
	PUSHARG 7
	SUB
	PUSHARG 14
	PUSHARG 7
	SUB
	MUL
	ADD
	POPN 15
	PUSHARG 15
	PUSH 72200
	CMPGE
	JZ LOC_38588
	PUSHARG 13
	POPN 1
	PUSHARG 14
	POPN 2
	JMP LOC_38598
LOC_38588:
	INCN 12
	JMP LOC_383F4
LOC_38598:
	JMP LOC_38850
LOC_385A0:
	PUSHARG 6
	PUSH 200
	PUSH 260
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 1
	PUSHARG 7
	PUSH 220
	PUSH 270
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SUB
	POPN 2
	PUSHARG 1
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 9
	PUSHARG 2
	SYSCALL 0x108, (1 | (1 << 16)) ; ScreenXToBattleX 
	POPN 10
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	SYSCALL 0x12A, (5 | (1 << 16)) ; 0x012A 
	POPN 8
	PUSHARG 8
	PUSH 0
	CMPG
	JZ LOC_38850
	PUSH 0
	POPN 12
LOC_386AC:
	PUSHARG 12
	PUSHARG 8
	PUSH 2
	DIV
	CMPL
	JZ LOC_38850
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	XOR
	PUSHARG 9
	PUSHARG 10
	PUSH 3
	PUSH 3
	PUSH 0
	PUSHARG 8
	PUSH 1
	SUB
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	SYSCALL 0x12B, (6 | (1 << 16)) ; 0x012B 
	POPN 11
	PUSHARG 11
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMPZ
	JZ LOC_38840
	PUSHARG 11
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 13
	PUSHARG 11
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 14
	PUSHARG 13
	PUSHARG 6
	SUB
	PUSHARG 13
	PUSHARG 6
	SUB
	MUL
	PUSHARG 14
	PUSHARG 7
	SUB
	PUSHARG 14
	PUSHARG 7
	SUB
	MUL
	ADD
	POPN 15
	PUSHARG 15
	PUSH 72200
	CMPGE
	JZ LOC_38840
	PUSHARG 13
	POPN 1
	PUSHARG 14
	POPN 2
	JMP LOC_38850
LOC_38840:
	INCN 12
	JMP LOC_386AC
LOC_38850:
	PUSHSTR "XCreateTaichi"
	PUSHARG 1
	PUSHARG 2
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 8
	PUSH 12
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	DELAY
	INCN 5
	JMP LOC_37C38
LOC_388AC:
	PUSH 45
	DELAY
	INCN 4
	JMP LOC_37C00
LOC_388C8:
	PUSHSTR "XCreateTaichi"
	INST_45
	PUSH 60
	DELAY
	RETN 1

}}

void function XDuplicatorCallback (arg_0, arg_1) callsign 43003 {
__asm{
	STACK 1
	PUSHARG -3
	PUSHARG -2
	PUSHINV 4 ; INTV_MAGIC_ATTACK_VALUE
	CALL Hurt
	PUSHARG -2
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	CMP
	PUSHARG -2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	CMP
	ORZ
	JZ LOC_38A58
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSH 4
	DELAY
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSH 4
	DELAY
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSH 4
	DELAY
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	PUSH 4
	DELAY
	PUSHSTR "SmallFireBall"
	PUSHARG -3
	PUSHARG -2
	PUSH 12
	PUSH 0
	CALLBS
	JMP LOC_38A84
LOC_38A58:
	PUSHSTR "Blood"
	PUSHARG -2
	PUSH 16
	PUSH 0
	PUSH 0
	CALLBS
LOC_38A84:
	RETN 2

}}

void function XTraceDuplicator (arg_0, arg_1) {
__asm{
	STACK 4
	PUSH 0
	POPN 4
LOC_38AA4:
	PUSHARG -3
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_38C50
	PUSH 1
	DELAY
	PUSHARG -2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_38AFC
	JMP LOC_38C50
LOC_38AFC:
	PUSHARG -3
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHARG -2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 2
	PUSHARG 2
	PUSHARG 1
	SUB
	POPN 3
	PUSHARG 3
	PUSH 0
	CMPL
	JZ LOC_38B80
	PUSHARG 3
	NEG
	POPN 3
LOC_38B80:
	PUSHARG 3
	PUSH 360
	CMPL
	PUSHARG 4
	PUSH 2
	CMPL
	ORNZ
	JZ LOC_38BE8
	PUSHARG -3
	PUSH 4
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 2
	POPN 4
	JMP LOC_38C48
LOC_38BE8:
	PUSHARG 3
	PUSH 1080
	CMPL
	PUSHARG 4
	PUSH 1
	CMPL
	ORNZ
	JZ LOC_38C48
	PUSHARG -3
	PUSH 2
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 1
	POPN 4
LOC_38C48:
	JMP LOC_38AA4
LOC_38C50:
	RETN 2

}}

void function XMoveDuplicator (arg_0, arg_1, arg_2) {
__asm{
	STACK 3
	PUSHARG -4
	SYSCALL 0x1A, (1 | (1 << 16)) ; 0x001A 
	POPN 3
	PUSHARG -4
	PUSHARG -3
	PUSHARG 3
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG -4
	PUSHARG 3
	PUSH 48
	PUSH 64
	ADD
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSHARG -2
	POPN 1
LOC_38D00:
	PUSHARG 2
	PUSHARG -4
	PUSHARG 3
	PUSH 48
	PUSH 64
	ADD
	PUSH 0
	SYSCALL 0x15, (5 | (0 << 16)) ; 0x0015 
	PUSH 1
	DELAY
	PUSHARG -4
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	ZERO
	JZ LOC_38D74
	JMP LOC_38D98
LOC_38D74:
	DECN 1
	PUSHARG 1
	PUSH 0
	CMPGE
	JNZ LOC_38D00
LOC_38D98:
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 3

}}

void function XProduceDuplicator (arg_0, arg_1, arg_2, arg_3) {
__asm{
LOC_38DB4:
	PUSHARG -5
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_38E2C
	PUSHSTR "XDuplicatorShadow"
	PUSHARG -5
	PUSHARG -4
	PUSHARG -3
	PUSHARG -2
	PUSH 8
	SUB
	PUSH 14
	SYSCALL 0x310, (6 | (0 << 16)) ; 0x0310 
	PUSH 8
	DELAY
	JMP LOC_38DB4
LOC_38E2C:
	RETN 4

}}

void function XDuplicatorShadow (arg_0, arg_1, arg_2, arg_3, arg_4) {
__asm{
	STACK 2
	PUSHARG -2
	PUSH 0
	CMP
	JZ LOC_38E60
	RETN 5
LOC_38E60:
	PUSHARG -6
	PUSHARG -5
	PUSHARG -4
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 1
	PUSHARG -4
	PUSH 0
	CMP
	JZ LOC_38EE8
	PUSHARG 1
	PUSH 8
	NEG
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
	JMP LOC_38F14
LOC_38EE8:
	PUSHARG 1
	PUSH 8
	PUSH 0
	PUSH 0
	SYSCALL 0x28, (4 | (0 << 16)) ; 0x0028 
LOC_38F14:
	PUSHARG 1
	PUSHARG -4
	PUSH 0
	PUSHARG -3
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 1
	PUSH 262144
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 1
	PUSHARG -2
	SYSCALL 0x27, (2 | (0 << 16)) ; 0x0027 
	PUSH 2
	DELAY
	PUSHARG 1
	PUSH 20
	PUSH 1
	SYSCALL 0x26, (3 | (0 << 16)) ; 0x0026 
LOC_38FA8:
	PUSHARG -6
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	JZ LOC_39008
	PUSHARG 1
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	PUSH 0
	CMP
	JZ LOC_38FF4
	RETN 5
LOC_38FF4:
	PUSH 1
	DELAY
	JMP LOC_38FA8
LOC_39008:
	PUSHARG 1
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
	RETN 5

}}

void function XDuplicator (arg_0) {
__asm{
	STACK 10
	PUSH 0
	POPN 10
	PUSH 0
	PUSH 3
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	PUSH 3
	CMP
	JZ LOC_39090
	PUSH 0
	PUSH 90
	SYSCALL 0x303, (2 | (1 << 16)) ; Rand 
	POPN 10
LOC_39090:
	PUSH 1
	PUSH 2
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMPZ
	MUL
	SUB
	POPN 9
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_390F8
	PUSH 0
	POPN 8
	JMP LOC_39108
LOC_390F8:
	PUSH 128
	POPN 8
LOC_39108:
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 5
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 7
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSHSTR "att07"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 22002
	PUSHARG 8
	PUSH 0
	SYSCALL 0x11, (4 | (1 << 16)) ; CreateObjectBelongTo 
	POPN 2
	PUSHARG 2
	PUSHARG 8
	PUSH 0
	PUSH 16
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 2
	PUSH 16777216
	PUSH 33554432
	ADD
	SYSCALL 0x29, (2 | (0 << 16)) ; SetObjectFlags 
	PUSHARG 2
	PUSH 43003
	SYSCALL 0x2C, (2 | (0 << 16)) ; SetCallbackProcedure 
	PUSHSTR "ProduceShadowTime"
	PUSHARG 2
	PUSH 9999
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XMoveDuplicator"
	PUSHARG 2
	PUSH 22001
	PUSH 9999
	PUSH 0
	CALLBS
	PUSH 16
	POPN 5
	PUSH 1
	POPN 4
	PUSH 0
	POPN 3
	PUSHSTR "XTraceDuplicator"
	PUSHARG 2
	PUSHINV 3 ; INTV_DEFENDER_MAJOR
	PUSH 0
	PUSH 0
	CALLBS
LOC_392BC:
	PUSHARG 2
	PUSHARG 8
	PUSH 0
	PUSHARG 5
	PUSH 16
	DIV
	SYSCALL 0x18, (4 | (0 << 16)) ; 0x0018 
	PUSHARG 5
	PUSH 24
	PUSH 16
	MUL
	CMPL
	JZ LOC_39354
	PUSHARG 5
	PUSHARG 4
	ADD
	POPN 5
	PUSHARG 4
	PUSH 1
	ADD
	POPN 4
LOC_39354:
	PUSHARG 3
	PUSH 1
	AND
	PUSH 0
	CMP
	JZ LOC_393E8
	PUSHARG 5
	PUSH 255
	CMPL
	JZ LOC_393C4
	PUSHARG 2
	PUSHSTR "m012snd01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
	JMP LOC_393E8
LOC_393C4:
	PUSHARG 2
	PUSHSTR "m012snd01"
	PUSH 255
	SYSCALL 0x300, (3 | (0 << 16)) ; PlaySound 
LOC_393E8:
	INCN 3
	PUSH 1
	DELAY
	PUSHARG 2
	SYSCALL 0x12, (1 | (1 << 16)) ; IsObjectExist 
	POPN 1
	PUSHARG 2
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 6
	PUSHARG 6
	PUSH 50
	CMPLE
	PUSHARG 6
	SYSCALL 0x132, (0 | (1 << 16)) ; 0x0132 
	PUSH 51
	SUB
	CMPGE
	ORZ
	JZ LOC_3948C
	PUSHARG 2
	SYSCALL 0x13, (1 | (0 << 16)) ; FreeObjectByHandle 
LOC_3948C:
	PUSHARG 1
	JNZ LOC_392BC
	PUSH 60
	DELAY
	RETN 1

}}

void function FinalX2 () {
__asm{
LOC_394B0:
	STACK 2
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\012\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\025\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\031\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 1
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 1
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 2
	PUSHARG 1
	PUSHARG 2
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 15
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 20
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSHSTR "XDuplicator"
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSH 20
	DELAY
	PUSHSTR "XFirePillar"
	PUSH 0
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XTaiChi"
	PUSH 2
	PUSH 0
	PUSH 0
	PUSH 0
	CALLBS
	PUSHSTR "XDuplicator"
	INST_45
	PUSHSTR "XFirePillar"
	INST_45
	PUSHSTR "XTaiChi"
	INST_45
	PUSH 10
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 0

}}

void function XProduceSoldier (arg_0, arg_1) {
__asm{
	STACK 7
	PUSH 0
	POPN 4
	PUSH 0
	POPN 1
	SYSCALL 0x12D, (0 | (1 << 16)) ; GetBattleWidth 
	POPN 6
	SYSCALL 0x12E, (0 | (1 << 16)) ; GetBattleHeight 
	POPN 7
LOC_39750:
	PUSHARG 7
	PUSH 2
	DIV
	POPN 2
LOC_3976C:
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_397B4
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
	JMP LOC_397F0
LOC_397B4:
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 2
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
LOC_397F0:
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_39924
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_39888
	PUSHARG -3
	PUSHARG 1
	PUSHARG 2
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
	JMP LOC_398F8
LOC_39888:
	PUSHARG -3
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 2
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
LOC_398F8:
	INCN 4
	PUSHARG 4
	PUSHARG -2
	CMPGE
	JZ LOC_39924
	RETN 2
LOC_39924:
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 1
	CMP
	JZ LOC_39984
	PUSHARG 1
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
	JMP LOC_399D8
LOC_39984:
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x113, (2 | (1 << 16)) ; GetSoldierHandle 
	POPN 3
LOC_399D8:
	PUSHARG 3
	PUSH 0
	CMP
	JZ LOC_39B3C
	PUSHARG -3
	PUSH 1
	CMP
	JZ LOC_39A88
	PUSHARG -3
	PUSHARG 1
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
	JMP LOC_39B10
LOC_39A88:
	PUSHARG -3
	PUSHARG 6
	PUSH 1
	SUB
	PUSHARG 1
	SUB
	PUSHARG 7
	PUSH 1
	SUB
	PUSHARG 2
	SUB
	SYSCALL 0x119, (3 | (1 << 16)) ; 0x0119 
	POPN 5
	PUSHSTR "StepShow"
	PUSHARG 5
	PUSH 10
	PUSH 0
	PUSH 0
	CALLBS
LOC_39B10:
	INCN 4
	PUSHARG 4
	PUSHARG -2
	CMPGE
	JZ LOC_39B3C
	RETN 2
LOC_39B3C:
	DECN 2
	PUSHARG 2
	PUSH 0
	CMPG
	JNZ LOC_3976C
	INCN 1
	PUSHARG 1
	PUSHARG 6
	CMPLE
	JNZ LOC_39750
	RETN 2

}}

void function XMoreSoldier (arg_0) {
__asm{
LOC_39B8C:
	STACK 8
	PUSHSTR "magic\\000\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	PUSHSTR "magic\\002\\*"
	SYSCALL 0x7, (1 | (0 << 16)) ; BatchLoadShape 
	SYSCALL 0x131, (0 | (0 << 16)) ; DisablePlayMagic 
	PUSH 8
	PUSH 5
	CALL DownBrightness
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	POPN 1
	PUSHINV 5 ; INTV_IS_RIGHT
	POPN 3
	PUSHARG 1
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHARG 1
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	SYSCALL 0x100, (2 | (0 << 16)) ; SetViewCamera 
	PUSHARG 1
	PUSH 2
	SYSCALL 0x121, (2 | (0 << 16)) ; AddAttackCounter 
	PUSH 20
	DELAY
	PUSHARG 3
	PUSH 1
	CMP
	JZ LOC_39CBC
	PUSH 0
	POPN 2
	JMP LOC_39CCC
LOC_39CBC:
	PUSH 128
	POPN 2
LOC_39CCC:
	PUSH 200
	PUSHARG 3
	SYSCALL 0x10C, (1 | (1 << 16)) ; GetSoldierCount 
	SUB
	POPN 7
	PUSHARG 7
	PUSH 0
	CMPL
	JZ LOC_39D20
	PUSH 0
	POPN 7
LOC_39D20:
	PUSHARG 7
	PUSHARG -2
	CMPG
	JZ LOC_39D4C
	PUSHARG -2
	POPN 7
LOC_39D4C:
	PUSHARG 7
	PUSH 0
	CMPZ
	JZ LOC_39F0C
	PUSHSTR "XProduceSoldier"
	PUSHARG 3
	PUSHARG 7
	PUSH 0
	PUSH 0
	CALLBS
	PUSHARG 1
	PUSH 32768
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSH 24
	DELAY
	PUSHARG 1
	PUSH 65536
	SYSCALL 0x120, (2 | (0 << 16)) ; SetObjectAnimate 
	PUSHARG 1
	PUSH 0
	SYSCALL 0x128, (2 | (0 << 16)) ; SetOverehelming? 
	PUSH 6
	DELAY
	PUSHSTR "m002snd01"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHSTR "m002snd03"
	PUSH 255
	SYSCALL 0x301, (2 | (0 << 16)) ; PlaySound1 
	PUSHINV 5 ; INTV_IS_RIGHT
	PUSH 0
	CMP
	JZ LOC_39E7C
	PUSH 6576
	PUSH 0
	PUSH 40
	CALL MoveCamera
	JMP LOC_39E9C
LOC_39E7C:
	PUSH 240
	PUSH 0
	PUSH 40
	CALL MoveCamera
LOC_39E9C:
	PUSH 100
	DELAY
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x105, (1 | (1 << 16)) ; GetObjectScreenX 
	POPN 4
	PUSHINV 2 ; INTV_ATTACKER_MAJOR
	SYSCALL 0x106, (1 | (1 << 16)) ; GetObjectScreenY 
	POPN 5
	PUSHARG 4
	PUSHARG 5
	PUSH 120
	SUB
	PUSH 20
	CALL MoveCamera
LOC_39F0C:
	PUSH 20
	DELAY
	PUSH 16
	PUSH 5
	CALL RaiseBrightness
	SYSCALL 0x110, (0 | (0 << 16)) ; EnablePlayMagic 
	RETN 1

}}

void function F103 () callsign 103 {
__asm{
	INST_09 120
	PUSH 501
	CMPL
	JZ LOC_39F70
	PUSH 501
	SETARG 120
LOC_39F70:
	INST_09 121
	SETINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 120
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x1, (4 | (0 << 16)) ; 0x0001 
	RETN 0

}}

void function F104 () callsign 104 {
__asm{
	INST_09 120
	PUSH 501
	CMPL
	JZ LOC_39FE8
	PUSH 501
	SETARG 120
	JMP LOC_39FF0
LOC_39FE8:
	INCARG 120
LOC_39FF0:
	INST_09 120
	PUSH 610
	CMPG
	JZ LOC_3A01C
	PUSH 501
	SETARG 120
LOC_3A01C:
	INST_09 120
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x1, (4 | (0 << 16)) ; 0x0001 
	RETN 0

}}

void function F100 () callsign 100 {
__asm{
	INST_09 120
	PUSH 501
	CMPL
	JZ LOC_3A07C
	PUSH 501
	SETARG 120
LOC_3A07C:
	INST_09 121
	SETINV 4 ; INTV_MAGIC_ATTACK_VALUE
	INST_09 120
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x1, (4 | (0 << 16)) ; 0x0001 
	RETN 0

}}

void function F200 () callsign 200 {
__asm{
	INST_09 120
	PUSH 501
	CMPL
	JZ LOC_3A0F4
	PUSH 501
	SETARG 120
	JMP LOC_3A0FC
LOC_3A0F4:
	INCARG 120
LOC_3A0FC:
	INST_09 120
	PUSH 610
	CMPG
	JZ LOC_3A128
	PUSH 501
	SETARG 120
LOC_3A128:
	INST_09 120
	PUSH 0
	PUSH 0
	PUSH 0
	SYSCALL 0x1, (4 | (0 << 16)) ; 0x0001 
	RETN 0

}}

void function F9999 (arg_0, arg_1) callsign 9999 {
__asm{
	PUSHARG -2
	SETARG 121
	PUSHARG -3
	SETARG 120
	RETN 2

}}

void function InitializeBattle () {
__asm{
	STACK 1
	INST_09 120
	PUSH 0
	CMP
	JZ LOC_3A1B8
	PUSH 501
	SETARG 120
LOC_3A1B8:
	PUSH 0
	SETARG 3
	PUSH 0
	SETARG 1
	PUSH 0
	PUSH 0
	INST_52 28
	PUSH 0
	PUSH 1
	INST_52 28
	PUSH 0
	PUSH 0
	INST_52 35
	PUSH 0
	PUSH 1
	INST_52 35
	PUSH 0
	POPN 1
LOC_3A248:
	PUSHARG 1
	PUSH 60
	CMPL
	JZ LOC_3A28C
	PUSH 0
	PUSHARG 1
	INST_52 55
	INCN 1
	JMP LOC_3A248
LOC_3A28C:
	RETN 0

}}

void function Magic1 () callsign 501 {
__asm{
	PUSH 0
	CALL Heal
	RETN 0

}}

void function Magic2 () callsign 502 {
__asm{
	PUSH 0
	PUSH 1
	CALL ShootObject
	RETN 0

}}

void function Magic3 () callsign 503 {
__asm{
	PUSH 17
	PUSH 1
	CALL ArrowSupport
	RETN 0

}}

void function Magic4 () callsign 504 {
__asm{
	PUSH 0
	CALL Spout
	RETN 0

}}

void function Magic5 () callsign 505 {
__asm{
	PUSH 0
	CALL Powder
	RETN 0

}}

void function Magic6 () callsign 506 {
__asm{
	PUSH 0
	CALL RollTub
	RETN 0

}}

void function Magic7 () callsign 507 {
__asm{
	PUSH 0
	CALL OnFire
	RETN 0

}}

void function Magic8 () callsign 508 {
__asm{
	PUSH 18
	PUSH 160
	PUSH 18003
	CALL ExplodeRound
	RETN 0

}}

void function Magic9 () callsign 509 {
__asm{
	PUSH 17
	PUSH 0
	CALL MoreSoldier
	RETN 0

}}

void function Magic10 () callsign 510 {
__asm{
	PUSH 20
	PUSH 0
	CALL Thunder
	RETN 0

}}

void function Magic11 () callsign 511 {
__asm{
	PUSH 9
	PUSH 1
	CALL Thunder
	RETN 0

}}

void function Magic12 () callsign 512 {
__asm{
	PUSH 0
	CALL FireDragon
	RETN 0

}}

void function Magic13 () callsign 513 {
__asm{
	PUSH 0
	CALL Interceptor
	RETN 0

}}

void function Magic14 () callsign 514 {
__asm{
	PUSH 1
	PUSH 0
	CALL ShootObject
	RETN 0

}}

void function Magic15 () callsign 515 {
__asm{
	PUSH 29
	PUSH 1
	CALL ArrowSupport
	RETN 0

}}

void function Magic16 () callsign 516 {
__asm{
	PUSH 1
	CALL Spout
	RETN 0

}}

void function Magic17 () callsign 517 {
__asm{
	PUSH 1
	CALL Powder
	RETN 0

}}

void function Magic18 () callsign 518 {
__asm{
	PUSH 1
	CALL RollTub
	RETN 0

}}

void function Magic19 () callsign 519 {
__asm{
	PUSH 32
	PUSH 240
	PUSH 18003
	CALL ExplodeRound
	RETN 0

}}

void function Magic20 () callsign 520 {
__asm{
	PUSH 1
	CALL FireDragon
	RETN 0

}}

void function Magic21 () callsign 521 {
__asm{
	PUSH 1
	CALL OnFire
	RETN 0

}}

void function Magic22 () callsign 522 {
__asm{
	PUSH 16
	PUSH 1
	CALL Thunder
	RETN 0

}}

void function Magic23 () callsign 523 {
__asm{
	PUSH 32
	PUSH 0
	CALL MoreSoldier
	RETN 0

}}

void function Magic24 () callsign 524 {
__asm{
	PUSH 25
	PUSH 0
	CALL BackSoldier
	RETN 0

}}

void function Magic25 () callsign 525 {
__asm{
	PUSH 62
	PUSH 0
	CALL Thunder
	RETN 0

}}

void function Magic26 () callsign 526 {
__asm{
	PUSH 2
	CALL CallDragon
	RETN 0

}}

void function Magic27 () callsign 527 {
__asm{
	PUSH 1
	CALL Interceptor
	RETN 0

}}

void function Magic28 () callsign 528 {
__asm{
	PUSH 2
	CALL FireDragon
	RETN 0

}}

void function Magic29 () callsign 529 {
__asm{
	PUSH 2
	CALL OnFire
	RETN 0

}}

void function Magic30 () callsign 530 {
__asm{
	PUSH 2
	CALL Powder
	RETN 0

}}

void function Magic31 () callsign 531 {
__asm{
	PUSH 48
	PUSH 380
	PUSH 18003
	CALL ExplodeRound
	RETN 0

}}

void function Magic32 () callsign 532 {
__asm{
	PUSH 2
	CALL Spout
	RETN 0

}}

void function Magic33 () callsign 533 {
__asm{
	PUSH 35
	PUSH 0
	CALL BackSoldier
	RETN 0

}}

void function Magic34 () callsign 534 {
__asm{
	PUSH 66
	PUSH 1
	CALL ArrowSupport
	RETN 0

}}

void function Magic35 () callsign 535 {
__asm{
	PUSH 3
	CALL RollTub
	RETN 0

}}

void function Magic36 () callsign 536 {
__asm{
	PUSH 3
	CALL FireDragon
	RETN 0

}}

void function Magic37 () callsign 537 {
__asm{
	CALL BigThunder
	RETN 0

}}

void function Magic38 () callsign 538 {
__asm{
	PUSH 40
	PUSH 1
	CALL Thunder
	RETN 0

}}

void function Magic39 () callsign 539 {
__asm{
	PUSH 2
	CALL Interceptor
	RETN 0

}}

void function Magic40 () callsign 540 {
__asm{
	CALL Earthquake
	RETN 0

}}

void function Magic41 () callsign 541 {
__asm{
	PUSH 45
	PUSH 0
	CALL BackSoldier
	RETN 0

}}

void function Magic42 () callsign 542 {
__asm{
	PUSH 4
	CALL FireDragon
	RETN 0

}}

void function Magic43 () callsign 543 {
__asm{
	PUSH 0
	CALL Sparkle
	RETN 0

}}

void function Magic44 () callsign 544 {
__asm{
	CALL FinalX1
	RETN 0

}}

void function Magic45 () callsign 545 {
__asm{
	PUSH 8
	PUSH 0
	CALL ArrowSupport
	RETN 0

}}

void function Magic46 () callsign 546 {
__asm{
	PUSH 0
	CALL RunningBow
	RETN 0

}}

void function Magic47 () callsign 547 {
__asm{
	PUSH 0
	PUSH 0
	PUSH 9
	CALL StoneEmitter
	RETN 0

}}

void function Magic48 () callsign 548 {
__asm{
	PUSH 0
	CALL ConvexStone
	RETN 0

}}

void function Magic49 () callsign 549 {
__asm{
	PUSH 0
	PUSH 0
	CALL FireRing
	RETN 0

}}

void function Magic50 () callsign 550 {
__asm{
	PUSH 0
	CALL HalfMoon
	RETN 0

}}

void function Magic51 () callsign 551 {
__asm{
	PUSH 0
	CALL Ice
	RETN 0

}}

void function Magic52 () callsign 552 {
__asm{
	PUSH 0
	PUSH 0
	CALL ShootObject
	RETN 0

}}

void function Magic53 () callsign 553 {
__asm{
	PUSH 0
	CALL Slash
	RETN 0

}}

void function Magic54 () callsign 554 {
__asm{
	PUSH 0
	CALL Tornado
	RETN 0

}}

void function Magic55 () callsign 555 {
__asm{
	PUSH 0
	CALL RollDown
	RETN 0

}}

void function Magic56 () callsign 556 {
__asm{
	PUSH 2
	PUSH 0
	PUSH 19002
	CALL EightWayFire
	RETN 0

}}

void function Magic57 () callsign 557 {
__asm{
	PUSH 0
	CALL TaiChi
	RETN 0

}}

void function Magic58 () callsign 558 {
__asm{
	PUSH 2
	PUSH 0
	CALL ShootObject
	RETN 0

}}

void function Magic59 () callsign 559 {
__asm{
	PUSH 0
	CALL FireCow
	RETN 0

}}

void function Magic60 () callsign 560 {
__asm{
	PUSH 0
	CALL FireWork
	RETN 0

}}

void function Magic61 () callsign 561 {
__asm{
	PUSH 0
	CALL FlyingSword
	RETN 0

}}

void function Magic62 () callsign 562 {
__asm{
	PUSH 0
	CALL Spear
	RETN 0

}}

void function Magic63 () callsign 563 {
__asm{
	PUSH 1
	CALL Heal
	RETN 0

}}

void function Magic64 () callsign 564 {
__asm{
	PUSH 1
	CALL RunningBow
	RETN 0

}}

void function Magic65 () callsign 565 {
__asm{
	PUSH 25
	PUSH 0
	CALL MoreSoldier
	RETN 0

}}

void function Magic66 () callsign 566 {
__asm{
	PUSH 0
	CALL BlackHole
	RETN 0

}}

void function Magic67 () callsign 567 {
__asm{
	PUSH 0
	CALL RushCart
	RETN 0

}}

void function Magic68 () callsign 568 {
__asm{
	PUSH 2
	PUSH 1
	PUSH 19002
	CALL EightWayFire
	RETN 0

}}

void function Magic69 () callsign 569 {
__asm{
	PUSH 1
	PUSH 0
	CALL FireRing
	RETN 0

}}

void function Magic70 () callsign 570 {
__asm{
	PUSH 1
	CALL FlyingSword
	RETN 0

}}

void function Magic71 () callsign 571 {
__asm{
	PUSH 0
	PUSH 1
	CALL FireRing
	RETN 0

}}

void function Magic72 () callsign 572 {
__asm{
	PUSH 33
	PUSH 0
	CALL ArrowSupport
	RETN 0

}}

void function Magic73 () callsign 573 {
__asm{
	PUSH 1
	CALL TaiChi
	RETN 0

}}

void function Magic74 () callsign 574 {
__asm{
	PUSH 1
	CALL FireCow
	RETN 0

}}

void function Magic75 () callsign 575 {
__asm{
	PUSH 1
	CALL ConvexStone
	RETN 0

}}

void function Magic76 () callsign 576 {
__asm{
	PUSH 1
	CALL RollDown
	RETN 0

}}

void function Magic77 () callsign 577 {
__asm{
	PUSH 1
	CALL HalfMoon
	RETN 0

}}

void function Magic78 () callsign 578 {
__asm{
	PUSH 1
	CALL FireWork
	RETN 0

}}

void function Magic79 () callsign 579 {
__asm{
	PUSH 1
	CALL Ice
	RETN 0

}}

void function Magic80 () callsign 580 {
__asm{
	PUSH 1
	CALL Tornado
	RETN 0

}}

void function Magic81 () callsign 581 {
__asm{
	PUSH 1
	CALL Slash
	RETN 0

}}

void function Magic82 () callsign 582 {
__asm{
	PUSH 1
	CALL Spear
	RETN 0

}}

void function Magic83 () callsign 583 {
__asm{
	PUSH 1
	PUSH 1
	PUSH 14
	CALL StoneEmitter
	RETN 0

}}

void function Magic84 () callsign 584 {
__asm{
	PUSH 42
	PUSH 0
	CALL MoreSoldier
	RETN 0

}}

void function Magic85 () callsign 585 {
__asm{
	CALL Frozen
	RETN 0

}}

void function Magic86 () callsign 586 {
__asm{
	PUSH 1
	CALL RushCart
	RETN 0

}}

void function Magic87 () callsign 587 {
__asm{
	PUSH 2
	CALL RunningBow
	RETN 0

}}

void function Magic88 () callsign 588 {
__asm{
	PUSH 2
	CALL Tornado
	RETN 0

}}

void function Magic89 () callsign 589 {
__asm{
	PUSH 1
	CALL BlackHole
	RETN 0

}}

void function Magic90 () callsign 590 {
__asm{
	PUSH 56
	PUSH 0
	CALL ArrowSupport
	RETN 0

}}

void function Magic91 () callsign 591 {
__asm{
	PUSH 1
	PUSH 1
	CALL FireRing
	RETN 0

}}

void function Magic92 () callsign 592 {
__asm{
	PUSH 0
	CALL HalfMoonNew
	RETN 0

}}

void function Magic93 () callsign 593 {
__asm{
	PUSH 2
	CALL ConvexStone
	RETN 0

}}

void function Magic94 () callsign 594 {
__asm{
	PUSH 0
	CALL Pa
	RETN 0

}}

void function Magic95 () callsign 595 {
__asm{
	PUSH 2
	CALL FlyingSword
	RETN 0

}}

void function Magic96 () callsign 596 {
__asm{
	PUSH 2
	CALL FireCow
	RETN 0

}}

void function Magic97 () callsign 597 {
__asm{
	PUSH 2
	CALL RollDown
	RETN 0

}}

void function Magic98 () callsign 598 {
__asm{
	PUSH 1
	CALL Duplicator
	RETN 0

}}

void function Magic99 () callsign 599 {
__asm{
	PUSH 2
	CALL FireWork
	RETN 0

}}

void function Magic100 () callsign 600 {
__asm{
	PUSH 0
	CALL Wall
	RETN 0

}}

void function Magic101 () callsign 601 {
__asm{
	PUSH 2
	CALL Ice
	RETN 0

}}

void function Magic102 () callsign 602 {
__asm{
	PUSH 2
	CALL HalfMoon
	RETN 0

}}

void function Magic103 () callsign 603 {
__asm{
	PUSH 2
	CALL Spear
	RETN 0

}}

void function Magic104 () callsign 604 {
__asm{
	PUSH 2
	PUSH 1
	PUSH 20
	CALL StoneEmitter
	RETN 0

}}

void function Magic105 () callsign 605 {
__asm{
	CALL DemonDancing
	RETN 0

}}

void function Magic106 () callsign 606 {
__asm{
	CALL TwisterSword
	RETN 0

}}

void function Magic107 () callsign 607 {
__asm{
	PUSH 0
	CALL FirePillar
	RETN 0

}}

void function Magic108 () callsign 608 {
__asm{
	PUSH 1
	CALL Wall
	RETN 0

}}

void function Magic109 () callsign 609 {
__asm{
	PUSH 1
	CALL HalfMoonNew
	RETN 0

}}

void function Magic110 () callsign 610 {
__asm{
	CALL FinalX2
	RETN 0

}}

void function Magic200 () callsign 700 {
__asm{
	PUSH 200
	CALL XMoreSoldier
	RETN 0
}}
